This is a simple demo of the SIO code. 

The serial interface used is the remote control port, see http://nil.rpc1.org/psp/remote.html
for how to build the interface. You should setup your local terminal software to 4800 baud
8N1 to communicate.

Note this comes with no warranty, if it blows up your psp it is not my resposibility. 
