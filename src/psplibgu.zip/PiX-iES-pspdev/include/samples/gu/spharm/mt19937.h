#ifndef __MT19937_H
#define __MT19937_H

#ifdef __cplusplus
extern "C" {
#endif

void sgenrand(unsigned long seed);
float genrand();


#ifdef __cplusplus
}
#endif

#endif
