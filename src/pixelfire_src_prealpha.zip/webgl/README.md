# PixelFire - WebGL (Experimental)
3D Video Codec for playing back pre-rendered Voxel Animations in the Web Browser with Volumetric Shaders (WIP)

![screenshot](https://github.com/TheMindVirus/PixelFire/blob/webgl/volumetric.png)
![screenshot](https://github.com/TheMindVirus/PixelFire/blob/webgl/pixelfiremoddev.png)

## Issues
```
* Too Many Issues to State, Barely Functional
```

## Future Work
```
* Wait for new standard release of WebGL 1 compliant with OpenGL ES 2.0 with Extensions
```
### *Not many experiments start off with the words, "I've just set fire to a turd, now to record it."*
</br>

![screenshot](https://github.com/TheMindVirus/PixelFire/blob/main/screenshot4.png)
![screenshot](https://github.com/TheMindVirus/PixelFire/blob/main/screenshot5.png)
