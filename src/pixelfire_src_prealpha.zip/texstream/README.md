# PixelFire
3D Texture Streaming for Generating Live Voxel Animations in Unity with Volumetric Shaders

![screenshot](https://github.com/TheMindVirus/PixelFire/blob/texstream/screenshot.png)