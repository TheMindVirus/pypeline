using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

//Unity Scriptable Render Pipeline 2021
//https://docs.unity3d.com/Manual/srp-creating-render-pipeline-asset-and-render-pipeline-instance.html

[CreateAssetMenu(menuName = "Rendering/Scriptable Render Pipeline Asset")]
public class ScriptableRenderPipelineAsset : RenderPipelineAsset
{
    public string tag;
    public Color colour;
    //Insert Custom Sender Properties Here
    public bool attach;
    public bool detach;

    protected override RenderPipeline CreatePipeline() { return new ScriptableRenderPipeline(this); }

    protected override void OnValidate()
    {
        if (attach)
        {
            attach = false;
            Debug.Log("Attaching SRP " + tag);
            GraphicsSettings.defaultRenderPipeline = this;
            QualitySettings.renderPipeline = this;
        }
        if (detach)
        {
            detach = false;
            Debug.Log("Detaching SRP " + tag);
            GraphicsSettings.defaultRenderPipeline = null;
            QualitySettings.renderPipeline = null;
        }
    }
}