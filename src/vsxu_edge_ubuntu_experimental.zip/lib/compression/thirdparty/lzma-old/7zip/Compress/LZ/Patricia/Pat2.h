// Pat2.h

#ifndef __PAT2__H
#define __PAT2__H

#undef PAT_CLSID
#define PAT_CLSID CLSID_CMatchFinderPat2

#undef PAT_NAMESPACE
#define PAT_NAMESPACE NPat2

#define __AUTO_REMOVE
#define __NODE_2_BITS

#include "Pat.h"
#include "PatMain.h"

#undef __AUTO_REMOVE
#undef  __NODE_2_BITS

#endif

