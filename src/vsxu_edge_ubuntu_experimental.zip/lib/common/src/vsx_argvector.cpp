#include <vsx_argvector.h>

vsx_argvector vsx_argvector::instance;
