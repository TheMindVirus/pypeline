#pragma once

#include <inttypes.h>

class vsx_input_event_text
{
public:
  wchar_t character_wide = 0;
  char character = 0;
};
