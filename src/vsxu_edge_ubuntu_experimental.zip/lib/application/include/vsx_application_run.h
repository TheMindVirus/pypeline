#pragma once

class vsx_application_run
{
public:
  static void run();
};
