#include <vsx_gl_global.h>
#include <vsx_application_run.h>
#include "vsx_application_sdl.h"

void vsx_application_run::run()
{
  vsx_application_sdl app;
  app.run();
}
