using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;

namespace Framefield.Core.ID3bf75bab_354b_467a_9e8f_7f13c2da145c
{
    public class Class_Read_Value : OperatorPart.Function, Framefield.Core.OperatorPartTraits.IVariableAccessor, Framefield.Core.OperatorPartTraits.ITimeAccessor
    {
        public string VariableName {
            get {
                return OperatorPartUtilities.GetInputTextValue(OperatorPart.Connections[0]);
            }
        }

        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            var Name = (string) inputs[0].Eval(context).Text;
            var value = 0.0f;
            if (context.Variables.TryGetValue(Name, out value))
                context.Value = value;
            return context;
        }
    }
}

