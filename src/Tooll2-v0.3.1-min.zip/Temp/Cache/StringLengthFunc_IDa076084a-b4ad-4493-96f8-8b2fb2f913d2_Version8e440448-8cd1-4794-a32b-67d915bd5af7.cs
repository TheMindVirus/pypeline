using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;

namespace Framefield.Core.IDa076084a_b4ad_4493_96f8_8b2fb2f913d2
{
    public class Class_StringLength : OperatorPart.Function, Framefield.Core.OperatorPartTraits.ITimeAccessor
    {
        //>>> _outputids
        private enum OutputId
        {
            Width = 0
        }
        //<<< _outputids
        
        //>>> _inputids
        private enum InputId
        {
            Text = 0
        }
        //<<< _inputids
        
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) 
        {
            //>>> _params
            var Text = inputs[(int)InputId.Text].Eval(context).Text;
            //<<< _params
            
            if(Text == null)
                context.Value = -1;
                
            context.Value = (int)Text.Length;    
            return context;
        }
    }
}


