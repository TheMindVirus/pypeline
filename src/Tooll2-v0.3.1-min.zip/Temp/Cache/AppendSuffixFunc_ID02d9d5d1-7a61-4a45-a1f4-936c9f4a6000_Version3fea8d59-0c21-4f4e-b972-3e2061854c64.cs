//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using


namespace Framefield.Core.ID02d9d5d1_7a61_4a45_a1f4_936c9f4a6000
{
    public class Class_AppendString : OperatorPart.Function
    {
        //>>> _inputids
        private enum InputId
        {
            String = 0,
            Suffix = 1
        }
        //<<< _inputids


        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            //>>> _params
            var String = inputs[(int)InputId.String].Eval(context).Text;
            var Suffix = inputs[(int)InputId.Suffix].Eval(context).Text;
            //<<< _params            
            
            context.Text = String + Suffix;            
            return context;
        }
    }
}

