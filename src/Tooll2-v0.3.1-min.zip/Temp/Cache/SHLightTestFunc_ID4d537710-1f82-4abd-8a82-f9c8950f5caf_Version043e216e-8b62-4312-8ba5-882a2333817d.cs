#define LOGGING
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using SharpDX;
using SharpDX.Direct3D11;
using Framefield.Core.Rendering;
using Buffer = SharpDX.Direct3D11.Buffer;


namespace Framefield.Core.ID4d537710_1f82_4abd_8a82_f9c8950f5caf
{
    public class Class_SHLightTest : FXSourceCodeFunction, IFXSceneSourceCode
    {

        class Renderer : BaseRenderer
        {
        }

        public override void Dispose() 
        {
            Utilities.DisposeObj(ref _renderer);
            base.Dispose();
        }

        //>>> _inputids
        private enum InputId
        {
            Code = 0,
            Scene = 1,
            CubeMap = 2
        }
        //<<< _inputids

        bool _firstEval = true;
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            //>>> _params
            var Code = inputs[(int)InputId.Code].Eval(context).Text;
            var Scene = inputs[(int)InputId.Scene];
            var CubeMap = inputs[(int)InputId.CubeMap].Eval(context).Image; // Needs to be checked for null!
            //<<< _params
            if (_firstEval) {
                for (int i = 0; i < NumCodes(); ++i)
                    Compile(i);
                _firstEval = false;
                Changed = true;
            }

            using (var CubeMapView = new ShaderResourceView(context.D3DDevice, CubeMap))
            {
                _effect.GetVariableByName("CubeMap").AsShaderResource().SetResource(CubeMapView);

                if (Changed)
                {
                    var colors = Texture2D.SHProjectCubeMap(context.D3DDevice.ImmediateContext, CubeMap, 4);
                    float[] r = new float[9];
                    float[] g = new float[9];
                    float[] b = new float[9];

                    const float one_over_pi = 1.0f / MathUtil.Pi;
                    for (int i = 0; i < 9; ++i)
                    {
                        r[i] = colors[i].Red * one_over_pi;
                        g[i] = colors[i].Green * one_over_pi;
                        b[i] = colors[i].Blue * one_over_pi;
                    }
                    

                    _matR = CreateLightMatrix(r);
                    _matG = CreateLightMatrix(g);
                    _matB = CreateLightMatrix(b);
                    Changed = false;

                    #region logging
                    #if LOGGING
                    for (int i = 0; i < colors.Length; ++i)
                    {
                        Logger.Info(this,"{0}    {1}     {2}", colors[i].Red, colors[i].Green, colors[i].Blue);
                    }
                    Logger.Info("");
                    for (int i = 0; i < 9; ++i)
                    {
                        Logger.Info(this,"{0}    {1}     {2}", r[i], g[i], b[i]);
                    }
                    Logger.Info(this,"{0}", _matR);
                    #endif
                    #endregion
                }
                
                _effect.GetVariableByName("matR").AsMatrix().SetMatrix(_matR);
                _effect.GetVariableByName("matG").AsMatrix().SetMatrix(_matG);
                _effect.GetVariableByName("matB").AsMatrix().SetMatrix(_matB);

                // setup
                var prevEffect = context.Effect;
                var prevRenderer = context.Renderer;
                context.Effect = _effect;
                context.Renderer = _renderer;
     
                Scene.Eval(context);
                
                // restore
                context.Renderer = prevRenderer;
                context.Effect = prevEffect;
            }
            return context;
        }

        private Matrix CreateLightMatrix(float[] lightCoefs)
        {
            if (lightCoefs.Length < 9)
                return Matrix.Identity;
            var c1 = 0.429043f; 
            var c2 = 0.511664f;
            var c3 = 0.743125f;
            var c4 = 0.886227f;
            var c5 = 0.247708f;

            var L00 = lightCoefs[0];
            var L1_1 = lightCoefs[1];
            var L10 = lightCoefs[2];
            var L11 = lightCoefs[3];
            var L2_2 = lightCoefs[4];
            var L2_1 = lightCoefs[5];
            var L20 = lightCoefs[6];
            var L21 = lightCoefs[7];
            var L22 = lightCoefs[8];

            Matrix m = new Matrix(c1*L22,  c1*L2_2, c1*L21,  c2*L11,
                                  c1*L2_2, -c1*L22, c1*L2_1, c2*L1_1,
                                  c1*L21,  c1*L2_1, c3*L20,  c2*L10,
                                  c2*L11,  c2*L1_1, c2*L10,  c4*L00-c5*L20);
            return m;            
        }

        private Renderer _renderer = new Renderer();
        Matrix _matR, _matG, _matB;
    }
}


