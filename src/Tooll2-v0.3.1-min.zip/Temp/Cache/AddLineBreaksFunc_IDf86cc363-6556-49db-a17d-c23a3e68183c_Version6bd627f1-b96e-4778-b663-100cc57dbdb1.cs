using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;


namespace Framefield.Core.IDf86cc363_6556_49db_a17d_c23a3e68183c
{
    public class Class_AddLineBreaks : OperatorPart.Function
    {
        //>>> _inputids
        private enum InputId
        {
            Text = 0,
            Search = 1,
            Replace = 2
        }
        //<<< _inputids



        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            //>>> _params
            var Text = inputs[(int)InputId.Text].Eval(context).Text;
            var Search = inputs[(int)InputId.Search].Eval(context).Text;
            var Replace = inputs[(int)InputId.Replace].Eval(context).Text;
            //<<< _params
            
            if(Replace.Length == 0)
                Replace= "\n";
            
            if(Search.Length > 0)            
                context.Text= Text.Replace( Search, Replace);
            else
                context.Text= Text;
                
            
            return context;
        }
    }
}

