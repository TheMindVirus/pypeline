using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;

namespace Framefield.Core.IDca9a3a0e_c1c7_42b6_a0e5_cdb4c61d0b18
{
    public class Class_Group : OperatorPart.Function
    {
        // >>> _inputids
        private enum InputId
        {
            Scenes = 0
        }
        // <<< _inputids

        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) 
        {
            // >>> _params
            var Scenes = inputs[(int)InputId.Scenes];
            // <<< _params

            foreach (var input in Scenes.Connections)
            {
                input.Eval(context);
            }

            return context;
        }
    }
}

