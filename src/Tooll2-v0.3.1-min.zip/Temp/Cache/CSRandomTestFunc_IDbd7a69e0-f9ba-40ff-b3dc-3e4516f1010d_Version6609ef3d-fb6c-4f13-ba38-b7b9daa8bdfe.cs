//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using

using System.Runtime.InteropServices;
using Framefield.Core.Rendering;
using SharpDX.DXGI;
using SharpDX.D3DCompiler;
using Buffer = SharpDX.Direct3D11.Buffer;
using System.CodeDom.Compiler;

namespace Framefield.Core.IDbd7a69e0_f9ba_40ff_b3dc_3e4516f1010d
{
    public class Class_CSRandomTest : FXSourceCodeFunction
    {
        [StructLayout(LayoutKind.Explicit, Size = 16)]
        public struct ConstBufferLayout
        {
            [FieldOffset(0)] 
            public uint seed;
        }
        
        //>>> _inputids
        private enum InputId
        {
            Code = 0,
            Seed = 1
        }
        //<<< _inputids

        public void Dispose()
        {
            Utilities.DisposeObj(ref _uaTexture);
            Utilities.DisposeObj(ref _uaTextureUAV);
            Utilities.DisposeObj(ref _cs);
            DisposeTextures();
            base.Dispose();
        }
        
        private void DisposeTextures()
        {
            for (int i = 0; i < 2; ++i)
            {
                Utilities.DisposeObj(ref _stateTexture[i]);
                Utilities.DisposeObj(ref _stateUAV[i]);
                Utilities.DisposeObj(ref _stateSRV[i]);
            }
        }
        

        protected bool BuildRenderTarget(OperatorPartContext context)
        {
            if (_uaTexture != null)
            {
                return false;
            }

            var uavDesc = new Texture2DDescription
                                  {
                                      BindFlags = BindFlags.ShaderResource | BindFlags.UnorderedAccess,
                                      Format = Format.R8G8B8A8_UNorm,
                                      Width = 1024,
                                      Height = 1024,
                                      MipLevels = 1,
                                      SampleDescription = new SampleDescription(1, 0),
                                      Usage = ResourceUsage.Default,
                                      OptionFlags = ResourceOptionFlags.None,
                                      CpuAccessFlags = CpuAccessFlags.None,
                                      ArraySize = 1
                                  };
            Utilities.DisposeObj(ref _uaTexture);
            Utilities.DisposeObj(ref _uaTextureUAV);
            _uaTexture = new Texture2D(context.D3DDevice, uavDesc);
            _uaTextureUAV = new UnorderedAccessView(context.D3DDevice, _uaTexture);

            uavDesc.Format = Format.R32G32B32A32_UInt;
            DisposeTextures();
            for (int i = 0; i < 2; ++i)
            {
                _stateTexture[i] = new Texture2D(context.D3DDevice, uavDesc);
                _stateUAV[i] = new UnorderedAccessView(context.D3DDevice, _stateTexture[i]);
                _stateSRV[i] = new ShaderResourceView(context.D3DDevice, _stateTexture[i]);
            }
            
            uavDesc.BindFlags = BindFlags.None;
            uavDesc.CpuAccessFlags = CpuAccessFlags.Write;
            uavDesc.Usage = ResourceUsage.Staging;
            var textureWithCPUAccess = new Texture2D(context.D3DDevice, uavDesc);

            DataStream seedStream = null;
            var dataBox = context.D3DDevice.ImmediateContext.MapSubresource(textureWithCPUAccess, 0, 0, MapMode.Write, SharpDX.Direct3D11.MapFlags.None, out seedStream);
            seedStream.Position = 0;

            int width = uavDesc.Width;
            int height = uavDesc.Height;
            uint seed = 0;
            for (int y = 0; y < height; ++y)
            {
                for (int x = 0; x < width; ++x)
                {
                    for (int i = 0; i < 4; ++i)
                    {
                        uint random = (uint) _randomGenerator.Next(0, 255);
                        seedStream.Write(random);
                    }
                }
                seedStream.Position += dataBox.RowPitch - width*16;
            }
            context.D3DDevice.ImmediateContext.UnmapSubresource(textureWithCPUAccess, 0);
            context.D3DDevice.ImmediateContext.CopyResource(textureWithCPUAccess, _stateTexture[0]); 
            Utilities.DisposeObj(ref seedStream);
            Utilities.DisposeObj(ref textureWithCPUAccess);

            return true;
        }

        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) 
        {
            if (Changed)
            {
                //>>> _params
                var Code = inputs[(int)InputId.Code].Eval(context).Text;
                var Seed = inputs[(int)InputId.Seed].Eval(context).Value;
                //<<< _params
                _code = Code;
                _seed = (uint) Seed;
            }

            if (_cs == null)
            {
                Utilities.DisposeObj(ref _cs);
                var errors = new CompilerErrorCollection();
                try
                {
                    using (var bytecode = ShaderBytecode.Compile(GetCode(0), "CS", "cs_5_0", ShaderFlags.Debug))
                        _cs = new ComputeShader(D3DDevice.Device, bytecode);
                }
                catch (SharpDX.CompilationException ex)
                {
                    errors = ErrorsFromString(ex.Message);
                    Logger.Error(this,"Fx compile error: {0}", ex.Message);
                }
            }

            BuildRenderTarget(context);

            var mc = new ConstBufferLayout();
            mc.seed = 13454043;

            BaseRenderer.SetupConstBufferForCS(context, mc, ref _constBuffer, 0);

            var deviceContext = context.D3DDevice.ImmediateContext;
            deviceContext.ComputeShader.Set(_cs);
            deviceContext.ComputeShader.SetShaderResource(0, _stateSRV[_stateIndex]);
            _stateIndex = (_stateIndex + 1) % 2;
            deviceContext.ComputeShader.SetUnorderedAccessView(0, _uaTextureUAV);
            deviceContext.ComputeShader.SetUnorderedAccessView(1, _stateUAV[_stateIndex]);
            deviceContext.Dispatch(4*16, 4*16, 1);
            deviceContext.ComputeShader.SetUnorderedAccessView(0, null);
            deviceContext.ComputeShader.SetUnorderedAccessView(1, null);
            deviceContext.ComputeShader.SetShaderResource(0, null);
            //Logger.Info(this,"dispatched");

            context.Image = _uaTexture;

            return context;
        }

        private string _code;
        private uint _seed;
        private Random _randomGenerator = new Random(123456);
        private int _stateIndex;
        private Texture2D[] _stateTexture = new Texture2D[2];
        private UnorderedAccessView[] _stateUAV = new UnorderedAccessView[2];
        private ShaderResourceView[] _stateSRV = new ShaderResourceView[2];

        private Buffer _constBuffer;
        private Texture2D _uaTexture;
        private UnorderedAccessView _uaTextureUAV;
        private ComputeShader _cs;
    }
}

