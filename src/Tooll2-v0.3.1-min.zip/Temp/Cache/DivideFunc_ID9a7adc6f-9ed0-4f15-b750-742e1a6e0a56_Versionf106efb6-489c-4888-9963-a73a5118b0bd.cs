using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;

namespace Framefield.Core.ID9a7adc6f_9ed0_4f15_b750_742e1a6e0a56
{
    public class Class_Divide : OperatorPart.Function
    {
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            var Value1 = (float) inputs[0].Eval(context).Value;
            var Value2 = (float) inputs[1].Eval(context).Value;
            //!!automatic generated code ends here
            if (Value2 != 0) {
                context.Value= Value1/Value2;
            }
            else {
                context.Value= 0.0f;
            }
            
            //!!automatic generated code starts here
            return context;
        }
    }
}

