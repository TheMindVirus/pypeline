using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using BulletSharp;

namespace Framefield.Core.IDea0b34ca_ffce_4d93_bbe5_c812957288b9
{

    public class Class_BulletSharpBasicDemo : OperatorPart.Function
    {
        // Physics
        public override void Dispose()
        {
            if (_world != null)
            {
                //remove/dispose constraints
                int i;
                for (i = _world.NumConstraints - 1; i >= 0; i--)
                {
                    TypedConstraint constraint = _world.GetConstraint(i);
                    _world.RemoveConstraint(constraint);
                    constraint.Dispose();
                }

                //remove the rigidbodies from the dynamics world and delete them
                for (i = _world.NumCollisionObjects - 1; i >= 0; i--)
                {
                    CollisionObject obj = _world.CollisionObjectArray[i];
                    RigidBody body = obj as RigidBody;
                    if (body != null && body.MotionState != null)
                    {
                        body.MotionState.Dispose();
                    }
                    _world.RemoveCollisionObject(obj);
                    obj.Dispose();
                }

                //delete collision shapes
                foreach (CollisionShape shape in CollisionShapes)
                    shape.Dispose();
                CollisionShapes.Clear();

                _world.Dispose();
                Broadphase.Dispose();
                Dispatcher.Dispose();
                CollisionConf.Dispose();
            }

            if (Broadphase != null)
            {
                Broadphase.Dispose();
            }
            if (Dispatcher != null)
            {
                Dispatcher.Dispose();
            }
            if (CollisionConf != null)
            {
                CollisionConf.Dispose();
            }
        }
        
        DynamicsWorld _world;
        public DynamicsWorld World
        {
            get { return _world; }
            protected set { _world = value; }
        }

        public virtual RigidBody LocalCreateRigidBody(float mass, Matrix startTransform, CollisionShape shape)
        {
            //rigidbody is dynamic if and only if mass is non zero, otherwise static
            bool isDynamic = (mass != 0.0f);

            Vector3 localInertia = Vector3.Zero;
            if (isDynamic)
                shape.CalculateLocalInertia(mass, out localInertia);

            //using motionstate is recommended, it provides interpolation capabilities, and only synchronizes 'active' objects
            DefaultMotionState myMotionState = new DefaultMotionState(startTransform);

            RigidBodyConstructionInfo rbInfo = new RigidBodyConstructionInfo(mass, myMotionState, shape, localInertia);
            RigidBody body = new RigidBody(rbInfo);
            rbInfo.Dispose();

            _world.AddRigidBody(body);

            return body;
        }

        // create 125 (5x5x5) dynamic objects
        const int ArraySizeX = 5, ArraySizeY = 5, ArraySizeZ = 5;

        // scaling of the objects (0.1 = 20 centimeter boxes )
        const float StartPosX = -5;
        const float StartPosY = -5;
        const float StartPosZ = -3;
    
        protected CollisionConfiguration CollisionConf;
        protected CollisionDispatcher Dispatcher;
        protected BroadphaseInterface Broadphase;
        protected ConstraintSolver Solver;
        public List<CollisionShape> CollisionShapes { get; private set; }
    
        void InitializePhysics()
        {
            // collision configuration contains default setup for memory, collision setup
            CollisionConf = new DefaultCollisionConfiguration();
            Dispatcher = new CollisionDispatcher(CollisionConf);

            Broadphase = new DbvtBroadphase();

            World = new DiscreteDynamicsWorld(Dispatcher, Broadphase, null, CollisionConf);
            World.Gravity = new Vector3(0, -10, 0);

            // create the ground
            BoxShape groundShape = new BoxShape(50, 1, 50);
            //groundShape.InitializePolyhedralFeatures();
            //CollisionShape groundShape = new StaticPlaneShape(new Vector3(0,1,0), 50);

            CollisionShapes = new List<CollisionShape>();
            CollisionShapes.Add(groundShape);
            CollisionObject ground = LocalCreateRigidBody(0, Matrix.Identity, groundShape);
            ground.UserObject = "Ground";

            // create a few dynamic rigidbodies
            const float mass = 1.0f;

            BoxShape colShape = new BoxShape(1);
            CollisionShapes.Add(colShape);
            Vector3 localInertia = colShape.CalculateLocalInertia(mass);

            const float start_x = StartPosX - ArraySizeX / 2;
            const float start_y = StartPosY;
            const float start_z = StartPosZ - ArraySizeZ / 2;

            RigidBodyConstructionInfo rbInfo = new RigidBodyConstructionInfo(mass, null, colShape, localInertia);

            int k, i, j;
            for (k = 0; k < ArraySizeY; k++)
            {
                for (i = 0; i < ArraySizeX; i++)
                {
                    for (j = 0; j < ArraySizeZ; j++)
                    {
                        Matrix startTransform = Matrix.Translation(2 * i + start_x, 2 * k + start_y, 2 * j + start_z );

                        // using motionstate is recommended, it provides interpolation capabilities
                        // and only synchronizes 'active' objects
                        rbInfo.MotionState = new DefaultMotionState(startTransform);
                        RigidBody body = new RigidBody(rbInfo);

                        // make it drop from a height
                        body.Translate(new Vector3(0, 20, 0));

                        World.AddRigidBody(body);
                    }
                }
            }

            rbInfo.Dispose();
        }

        // Frame counting
        public class Clock
        {
            #region Public Interface
    
            /// <summary>
            /// Initializes a new instance of the <see cref="Clock"/> class.
            /// </summary>
            public Clock()
            {
                frequency = Stopwatch.Frequency;
            }
    
            public void Start()
            {
                count = Stopwatch.GetTimestamp();
                isRunning = true;
            }
    
            /// <summary>
            /// Updates the clock.
            /// </summary>
            /// <returns>The time, in seconds, that elapsed since the previous update.</returns>
            public float Update()
            {
                if (isRunning)
                {
                    long last = count;
                    count = Stopwatch.GetTimestamp();
                    return (float)(count - last) / frequency;
                }
    
                return 0.0f;
            }
    
            #endregion
            #region Implementation Detail
    
            private bool isRunning;
            private readonly long frequency;
            private long count;
    
            #endregion
        }
        
        Clock clock = new Clock();
        float frameAccumulator;
        int frameCount;

        float _lastTime;
        float _frameDelta;
        public float FrameDelta
        {
            get { return _frameDelta; }
        }
        public float FramesPerSecond { get; private set; }

        public virtual void OnUpdate(float time)
        {
            _frameDelta = time - _lastTime;
            _lastTime = time;
            frameAccumulator += _frameDelta;
            ++frameCount;
            if (frameAccumulator >= 1.0f)
            {
                FramesPerSecond = frameCount / frameAccumulator;

                frameAccumulator = 0.0f;
                frameCount = 0;
            }
Logger.Info(this, "framedelta: {0}", _frameDelta);
            _world.StepSimulation(_frameDelta);

//            if (_freelook.Update(_frameDelta))
//                _graphics.UpdateView();
//_world.
//            _input.ClearKeyCache();
        }
    
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx)
        {

            if (!_initialized)
            {
                InitializePhysics();
                UpdateMesh(context);
                _initialized = true;
            }

            var collidingObjects = World.CollisionObjectArray;
            int i;

            if (context.Time < 1.0f || (context.Time > 7.0f && context.Time < 7.5f) )
            {
                i = collidingObjects.Count - 1;
                for (; i > 0; i--)
                {
                    CollisionObject colObj = collidingObjects[i];
                    var body = colObj as RigidBody;
                    if (body == null)
                        continue;
                    body.ApplyCentralForce(new Vector3(5,0,0));
                }
            }

            OnUpdate(context.Time);

            Matrix transform = Matrix.Identity;
            i = collidingObjects.Count - 1;
            for (; i >= 0; i--)
            {
                CollisionObject colObj = collidingObjects[i];
                colObj.GetWorldTransform(out transform);

                context.ObjectTWorld = transform;
                context.Renderer.SetupEffect(context);
                context.Renderer.Render(_mesh, context);
            }

            return context;
        }

        bool _initialized;
        
        
        private void UpdateMesh(OperatorPartContext context)
        {
            if (_mesh != null && !Changed) 
                return;
            Color4 Color = new Color4(1,0,0,1);
            Vector3 Tesselate = new Vector3(2,2,2);
            Vector3 Size = new Vector3(2,2,2);


            //>>> Function
            var inputElements = new []
                                    {
                                        new InputElement("POSITION", 0, SharpDX.DXGI.Format.R32G32B32A32_Float, 0, 0),
                                        new InputElement("NORMAL", 0, SharpDX.DXGI.Format.R32G32B32_Float, 16, 0),
                                        new InputElement("COLOR", 0, SharpDX.DXGI.Format.R32G32B32A32_Float, 28, 0),
                                        new InputElement("TEXCOORD", 0, SharpDX.DXGI.Format.R32G32_Float, 44, 0),
                                        new InputElement("TANGENT", 0, SharpDX.DXGI.Format.R32G32B32_Float, 52, 0),
                                        new InputElement("BINORMAL", 0, SharpDX.DXGI.Format.R32G32B32_Float, 64, 0)
                                    };

            int tessX = (int) Tesselate.X;
            int tessY = (int) Tesselate.Y;
            int tessZ = (int) Tesselate.Z;
            int numQuads = (tessY - 1)*(tessX - 1)*2 + (tessY - 1)*(tessZ - 1)*2 + (tessZ - 1)*(tessX - 1)*2;

            const int attributesSize = 76;
            int numTriangles = numQuads*2;
            int streamSize = numTriangles*3*attributesSize;

            if (_mesh == null || streamSize != _mesh.NumTriangles*3*_mesh.AttributesSize)
            {
                Utilities.DisposeObj(ref _mesh);
                using (var stream = new SharpDX.DataStream(streamSize, true, true))
                {
                    var vertices = new SharpDX.Direct3D11.Buffer(context.D3DDevice, stream, new BufferDescription
                                                                                                 {
                                                                                                     BindFlags = BindFlags.VertexBuffer,
                                                                                                     CpuAccessFlags = CpuAccessFlags.Write,
                                                                                                     OptionFlags = ResourceOptionFlags.None,
                                                                                                     SizeInBytes = streamSize,
                                                                                                     Usage = ResourceUsage.Dynamic
                                                                                                 });
                    _mesh = new Mesh
                                {
                                    InputElements = inputElements,
                                    Vertices = vertices,
                                    NumTriangles = numTriangles,
                                    AttributesSize = attributesSize
                                };
                }
            }
            SharpDX.DataStream vertexStream;
            DataBox box = context.D3DDevice.ImmediateContext.MapSubresource(_mesh.Vertices, MapMode.WriteDiscard, MapFlags.None, out vertexStream);
            using (vertexStream)
            {
                vertexStream.Position = 0;

                Vector3 start = Size*-0.5f;
                Vector3 end = start*-1.0f;

                float uPart = 0.25f;
                float uPart2 = 0.5f;
                float uPart3 = 0.75f;
                float vPart = 0.33333f;

                // texture coord layout : 1 - front, 2 - right, 3 - back, 4 - left, 5 - top, 6 - bottom, X - not used
                // 
                //   v^
                //    |
                //    |5XXX
                //    |1234  <- Texture
                //    |6XXX
                //     ------> 
                //           u

                for (int y = 0; y < (tessY - 1); ++y)
                {
                    float normalizedBottom = (float) y/(float) (tessY - 1);
                    float bottom = start.Y + (Size.Y*normalizedBottom);
                    float normalizedTop = (float) (y + 1)/(float) (tessY - 1);
                    float top = start.Y + (Size.Y*normalizedTop);

                    float lowerV = vPart + normalizedBottom*vPart;
                    float upperV = vPart + normalizedTop*vPart;

                    for (int x = 0; x < (tessX - 1); ++x)
                    {
                        float normalizedLeft = (float) x/(float) (tessX - 1);
                        float left = start.X + (Size.X*normalizedLeft);
                        float normalizedRight = (float) (x + 1)/(float) (tessX - 1);
                        float right = start.X + (Size.X*normalizedRight);
                        // front
                        float leftU = normalizedLeft*uPart;
                        float rightU = normalizedRight*uPart;
                        addQuad(vertexStream, Color,
                                new Vector3(left, bottom, end.Z), new Vector2(leftU, lowerV),
                                new Vector3(right, bottom, end.Z), new Vector2(rightU, lowerV),
                                new Vector3(right, top, end.Z), new Vector2(rightU, upperV),
                                new Vector3(left, top, end.Z), new Vector2(leftU, upperV));

                        // back
                        rightU = uPart3 - normalizedLeft*uPart;
                        leftU = uPart3 - normalizedRight*uPart;
                        addQuad(vertexStream, Color,
                                new Vector3(right, bottom, start.Z), new Vector2(leftU, lowerV),
                                new Vector3(left, bottom, start.Z), new Vector2(rightU, lowerV),
                                new Vector3(left, top, start.Z), new Vector2(rightU, upperV),
                                new Vector3(right, top, start.Z), new Vector2(leftU, upperV));
                    }

                    for (int z = 0; z < (tessZ - 1); ++z)
                    {
                        float normalizedBack = (float) (z)/(float) (tessZ - 1);
                        float back = start.Z + (Size.Z*normalizedBack);
                        float normalizedFront = (float) (z + 1)/(float) (tessZ - 1);
                        float front = start.Z + (Size.Z*normalizedFront);

                        // left side
                        float leftU = uPart3 + normalizedBack*uPart;
                        float rightU = uPart3 + normalizedFront*uPart;
                        addQuad(vertexStream, Color,
                                new Vector3(start.X, bottom, front), new Vector2(rightU, lowerV),
                                new Vector3(start.X, top, front), new Vector2(rightU, upperV),
                                new Vector3(start.X, top, back), new Vector2(leftU, upperV),
                                new Vector3(start.X, bottom, back), new Vector2(leftU, lowerV));

                        // right side
                        leftU = uPart2 - normalizedFront*uPart;
                        rightU = uPart2 - normalizedBack*uPart;
                        addQuad(vertexStream, Color,
                                new Vector3(end.X, bottom, front), new Vector2(leftU, lowerV),
                                new Vector3(end.X, bottom, back), new Vector2(rightU, lowerV),
                                new Vector3(end.X, top, back), new Vector2(rightU, upperV),
                                new Vector3(end.X, top, front), new Vector2(leftU, upperV));
                    }
                }

                for (int z = 0; z < (tessZ - 1); ++z)
                {
                    float normalizedBack = (float) (z)/(float) (tessZ - 1);
                    float back = start.Z + (Size.Z*normalizedBack);
                    float normalizedFront = (float) (z + 1)/(float) (tessZ - 1);
                    float front = start.Z + (Size.Z*normalizedFront);

                    for (int x = 0; x < (tessX - 1); ++x)
                    {
                        float normalizedLeft = (float) (x)/(float) (tessX - 1);
                        float left = start.X + (Size.X*normalizedLeft);
                        float normalizedRight = (float) (x + 1)/(float) (tessX - 1);
                        float right = start.X + (Size.X*normalizedRight);
                        float leftU = normalizedLeft*uPart;
                        float rightU = normalizedRight*uPart;

                        // bottom
                        float lowerV = normalizedBack*vPart;
                        float upperV = normalizedFront*vPart;
                        addQuad(vertexStream, Color,
                                new Vector3(right, start.Y, front), new Vector2(rightU, upperV),
                                new Vector3(left, start.Y, front), new Vector2(leftU, upperV),
                                new Vector3(left, start.Y, back), new Vector2(leftU, lowerV),
                                new Vector3(right, start.Y, back), new Vector2(rightU, lowerV));

                        // top
                        upperV = 1.0f - normalizedBack*vPart;
                        lowerV = 1.0f - normalizedFront*vPart;
                        addQuad(vertexStream, Color,
                                new Vector3(left, end.Y, front), new Vector2(leftU, lowerV),
                                new Vector3(right, end.Y, front), new Vector2(rightU, lowerV),
                                new Vector3(right, end.Y, back), new Vector2(rightU, upperV),
                                new Vector3(left, end.Y, back), new Vector2(leftU, upperV));
                    }
                }

                context.D3DDevice.ImmediateContext.UnmapSubresource(_mesh.Vertices, 0);
            }
            //<<< Function

            Changed = false;
        }

        private void addQuad(SharpDX.DataStream stream, Color4 color,
                             Vector3 p0, Vector2 tx0,
                             Vector3 p1, Vector2 tx1,
                             Vector3 p2, Vector2 tx2,
                             Vector3 p3, Vector2 tx3) {
            var tangent = new Vector3(1.0f, 0.0f, 0.0f);
            var binormal = new Vector3(0.0f, -1.0f, 0.0f);

            //triangle 0, 1, 2
            var normal = Vector3.Cross(p1 - p0, p2 - p0);
            normal.Normalize();

            stream.Write(new Vector4(p0.X, p0.Y, p0.Z, 1));
            stream.Write(normal);
            stream.Write(color);
            stream.Write(tx0);
            stream.Write(tangent);
            stream.Write(binormal);

            stream.Write(new Vector4(p1.X, p1.Y, p1.Z, 1));
            stream.Write(normal);
            stream.Write(color);
            stream.Write(tx1);
            stream.Write(tangent);
            stream.Write(binormal);

            stream.Write(new Vector4(p2.X, p2.Y, p2.Z, 1));
            stream.Write(normal);
            stream.Write(color);
            stream.Write(tx2);
            stream.Write(tangent);
            stream.Write(binormal);

            //triangle 0, 2, 3
            normal = Vector3.Cross(p2 - p0, p3 - p0);
            normal.Normalize();

            stream.Write(new Vector4(p0.X, p0.Y, p0.Z, 1));
            stream.Write(normal);
            stream.Write(color);
            stream.Write(tx0);
            stream.Write(tangent);
            stream.Write(binormal);

            stream.Write(new Vector4(p2.X, p2.Y, p2.Z, 1));
            stream.Write(normal);
            stream.Write(color);
            stream.Write(tx2);
            stream.Write(tangent);
            stream.Write(binormal);

            stream.Write(new Vector4(p3.X, p3.Y, p3.Z, 1));
            stream.Write(normal);
            stream.Write(color);
            stream.Write(tx3);
            stream.Write(tangent);
            stream.Write(binormal);
        }

        private Mesh _mesh;
        
    }
}
