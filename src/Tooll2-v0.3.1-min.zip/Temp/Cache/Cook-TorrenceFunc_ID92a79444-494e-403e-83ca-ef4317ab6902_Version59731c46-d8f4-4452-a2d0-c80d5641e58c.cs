//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using
using Framefield.Core.Rendering;

namespace Framefield.Core.ID92a79444_494e_403e_83ca_ef4317ab6902
{
    public class Class_Cook_Torrence : FXSourceCodeFunction
    {
        //>>> _inputids
        private enum InputId
        {
            Code = 0,
            Scene = 1,
            Roughness = 2,
            RefractiveIndex = 3,
            CubeMap = 4
        }
        //<<< _inputids

        #region Renderer
        public class Renderer : BaseRenderer
        {
            public override void SetupEffect(OperatorPartContext context)
            {
                base.SetupEffect(context);
                try
                {
                    SetupMaterialConstBuffer(context);
                    SetupFogSettingsConstBuffer(context);
                    SetupPointLightsConstBuffer(context);
                    var roughnessVariable = context.Effect.GetVariableByName("Roughness").AsScalar();
                    if (roughnessVariable != null)
                    {
                        roughnessVariable.Set(Roughness);
                    }
                    var f0Variable = context.Effect.GetVariableByName("F0").AsScalar();
                    if (f0Variable != null)
                    {
                        f0Variable.Set(F0);
                    }
                    using (var CubeMapView = new ShaderResourceView(context.D3DDevice, CubeMap))
                    {
                        var cubeMapVariable = context.Effect.GetVariableByName("CubeMap").AsShaderResource();
                        if (cubeMapVariable != null)
                        {
                            cubeMapVariable.SetResource(CubeMapView);
                        }
                    }
                }
                catch (Exception e)
                {
                    Logger.Error(ParentFunc, "Error building constant buffer: {0} - Source: {1}", e.Message, e.Source);
                }
            }
            public OperatorPart.Function ParentFunc {get;set;}
            public float Roughness { get; set; }
            public float F0 { get; set; }
            public Texture2D CubeMap { get; set; }
        }
        #endregion

        public Class_Cook_Torrence()
        {
            _renderer = new Renderer(){ParentFunc = this};
        }

        public override void Dispose()
        {
            Utilities.DisposeObj(ref _renderer);
            base.Dispose();
        }

        bool _firstEval = true;
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx)
        {
            //>>> _params
            var Code = inputs[(int)InputId.Code].Eval(context).Text;
            var Scene = inputs[(int)InputId.Scene];
            var Roughness = inputs[(int)InputId.Roughness].Eval(context).Value;
            var RefractiveIndex = inputs[(int)InputId.RefractiveIndex].Eval(context).Value;
            var CubeMap = inputs[(int)InputId.CubeMap].Eval(context).Image; // Needs to be checked for null!
            //<<< _params

            _renderer.Roughness = Roughness;
            float f = (1.0f - RefractiveIndex)/(1.0f + RefractiveIndex);
            _renderer.F0 = f*f;
            //Logger.Info("F0: {0}", _renderer.F0);
            _renderer.CubeMap = CubeMap;
            
            if (_firstEval)
            {
                for (int i = 0; i < NumCodes(); ++i)
                    Compile(i);
                _firstEval = false;
                Changed = true;
            }

            var prevEffect = context.Effect;
            var prevRenderer = context.Renderer;

            context.Effect = _effect;
            context.Renderer = _renderer;

            Scene.Eval(context);

            context.Effect = prevEffect;
            context.Renderer = prevRenderer;            

            return context;
        }

        Renderer _renderer;
    }
}


