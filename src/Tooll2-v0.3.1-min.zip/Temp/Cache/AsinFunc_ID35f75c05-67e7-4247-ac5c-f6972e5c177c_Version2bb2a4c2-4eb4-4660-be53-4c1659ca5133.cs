using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;

namespace Framefield.Core.ID35f75c05_67e7_4247_ac5c_f6972e5c177c
{
    public class Class_aSin : OperatorPart.Function
    {
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            var Value = (float) inputs[0].Eval(context).Value;
            //!!automatic generated code ends here
            context.Value= (float) Math.Asin(Value);
            //!!automatic generated code starts here
            return context;
        }
    }
}

