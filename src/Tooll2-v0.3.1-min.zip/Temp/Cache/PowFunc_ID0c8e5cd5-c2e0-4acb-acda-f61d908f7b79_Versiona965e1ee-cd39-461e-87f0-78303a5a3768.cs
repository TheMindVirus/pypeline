using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;

namespace Framefield.Core.ID0c8e5cd5_c2e0_4acb_acda_f61d908f7b79
{
    public class Class_Pow : OperatorPart.Function
    {
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            var Value = (float) inputs[0].Eval(context).Value;
            var Exp = (float) inputs[1].Eval(context).Value;
            //!!automatic generated code ends here
            if (Value <= 0) {
                context.Value = 0.0f;
            }
            else {
                context.Value= (float) Math.Pow(Value, Exp);
            }
            //!!automatic generated code starts here
            return context;
        }
    }
}

