using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;

namespace Framefield.Core.ID434538b1_896b_49fc_8498_e083c3d71127
{
    public class Class_Length : OperatorPart.Function
    {
        //>>> _inputids
        private enum InputId
        {
            VecX = 0,
            VecY = 1
        }
        //<<< _inputids
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) 
        {
            //>>> _params
            var VecX = inputs[(int)InputId.VecX].Eval(context).Value;
            var VecY = inputs[(int)InputId.VecY].Eval(context).Value;
            var Vec = new Vector2(VecX, VecY);
            //<<< _params
            
            context.Value = Vec.Length();
            
            return context;
        }
    }
}

