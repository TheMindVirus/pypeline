using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;

namespace Framefield.Core.ID099f5274_8f99_4cdd_9ef3_6fb64b23d01b
{
    public class Class_Ceiling : OperatorPart.Function
    {
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {

            // params >>> 
            var Value = (float) inputs[0].Eval(context).Value;
            // <<< params

            
            // Function >>> 
            context.Value = (float) Math.Ceiling(Value);
            // <<< Function
            return context;
        }
    }
}