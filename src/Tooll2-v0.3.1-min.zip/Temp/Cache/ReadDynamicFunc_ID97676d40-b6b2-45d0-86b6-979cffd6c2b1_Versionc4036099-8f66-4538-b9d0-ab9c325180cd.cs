using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;

namespace Framefield.Core.ID97676d40_b6b2_45d0_86b6_979cffd6c2b1
{
    public class Class_ReadDynamic : OperatorPart.Function
    {
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            dynamic obj = inputs[0].Eval(context).Dynamic;

            Logger.Info(this,"Title {0}", obj.Title);
            foreach (var item in obj.Items) {
                Logger.Info(this,"{0}", item);
            }

            return context;
        }
    }
}

