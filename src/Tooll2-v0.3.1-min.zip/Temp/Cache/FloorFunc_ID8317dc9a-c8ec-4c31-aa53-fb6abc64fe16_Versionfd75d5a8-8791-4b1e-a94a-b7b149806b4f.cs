using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;

namespace Framefield.Core.ID8317dc9a_c8ec_4c31_aa53_fb6abc64fe16
{
    public class Class_Floor : OperatorPart.Function
    {
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {

            // params >>> 
            var Value = (float) inputs[0].Eval(context).Value;
            // <<< params

            
            // Function >>> 
            context.Value = (float) Math.Floor(Value);
            // <<< Function
            return context;
        }
    }
}