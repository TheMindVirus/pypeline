//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using
namespace Framefield.Core.ID45339799_acdb_4529_803e_a628ce6b6266
{

    public class Class_Multiply : OperatorPart.Function
    {
        //>>> _inputids
        private enum InputId
        {
            Trigger = 0,
            Text = 1
        }
        //<<< _inputids
        
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            //>>> _params
            var Trigger = inputs[(int)InputId.Trigger].Eval(context).Value;
            var Text = inputs[(int)InputId.Text].Eval(context).Text;
            //<<< _params
            
            if( Trigger != 0) {
                _frozen = Text;
            }
            context.Text = _frozen;
            
            return context;
        }
        private String _frozen="";
    }
}

