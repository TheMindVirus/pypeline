//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using

using System.Runtime.InteropServices;
using Framefield.Core.Rendering;
using SharpDX.DXGI;
using SharpDX.D3DCompiler;
using Buffer = SharpDX.Direct3D11.Buffer;
using System.CodeDom.Compiler;

namespace Framefield.Core.ID9923d2fd_0625_4501_9026_388e17ffcbcb
{

    public class Class_RaytracerCSTest : FXSourceCodeFunction, Framefield.Core.OperatorPartTraits.ICameraProvider
    {

        //>>> _inputids
        private enum InputId
        {
            Code = 0,
            CameraPosX = 1,
            CameraPosY = 2,
            CameraPosZ = 3,
            PointLight = 4,
            PointLightPositionX = 5,
            PointLightPositionY = 6,
            PointLightPositionZ = 7,
            PointLightColorR = 8,
            PointLightColorG = 9,
            PointLightColorB = 10,
            PointLightColorA = 11,
            TargetX = 12,
            TargetY = 13,
            TargetZ = 14,
            UpX = 15,
            UpY = 16,
            UpZ = 17,
            AreaLightPositionX = 18,
            AreaLightPositionY = 19,
            AreaLightPositionZ = 20,
            SamplesX = 21,
            SamplesY = 22
        }
        //<<< _inputids

        public void Dispose()
        {
            DisposeTextures();
            Utilities.DisposeObj(ref _cs);
            Utilities.DisposeObj(ref _constbuffer);
            base.Dispose();
        }

        private void DisposeTextures()
        {
            Utilities.DisposeObj(ref _targetTexture);
            Utilities.DisposeObj(ref _textureUAV);
            Utilities.DisposeObj(ref _shadow);
            Utilities.DisposeObj(ref _shadowUAV);
            Utilities.DisposeObj(ref _shadowSRV);
        }


        [StructLayout(LayoutKind.Explicit, Size = 336)]
        public struct ConstBufferLayout
        {
            [FieldOffset(0)] 
            public Vector4 SphereColor;
            [FieldOffset(16)]
            public float Radius;
            [FieldOffset(20)]
            public Vector3 Center;

            [FieldOffset(32)]
            public Vector3 CameraPosition;
            [FieldOffset(48)]
            public Vector3 GazeDirection;
            [FieldOffset(64)]
            public Vector3 UpVector;
            [FieldOffset(76)]
            public float Angle;

            [FieldOffset(80)]
            public float Width;
            [FieldOffset(84)]
            public float Height;

            [FieldOffset(96)]
            public Vector3 PlanePoint;
            [FieldOffset(112)]
            public Vector3 PlaneNormal;
            [FieldOffset(128)]
            public Vector4 PlaneColor;

            [FieldOffset(144)]
            public Vector3 boxLBF;
            [FieldOffset(160)]
            public Vector3 boxRUN;
            [FieldOffset(176)]
            public Vector4 boxColor;

            [FieldOffset(192)]
            public Vector3 pointA;
            [FieldOffset(208)]
            public Vector3 pointB;
            [FieldOffset(224)]
            public Vector3 pointC;
            [FieldOffset(240)]
            public Vector4 triangleColor;

            [FieldOffset(256)] 
            public bool pLightOn;
            [FieldOffset(260)]
            public Vector3 pLightPosition;
            [FieldOffset(272)]
            public Vector4 pLightColor;

            [FieldOffset(288)]
            public Vector3 areaLightPos;
            [FieldOffset(300)]
            public bool areaLightOn;
            [FieldOffset(304)]
            public uint samplesX;
            [FieldOffset(308)]
            public uint samplesY;

            [FieldOffset(312)]
            public uint frameCount;
        }
        
        private void SetupConstBuffer(OperatorPartContext context)
        {
            var mc = new ConstBufferLayout();
            
            mc.SphereColor = new Vector4(1,0,1,1);
            mc.Radius = 2.0f;
            mc.Center = new Vector3(4,2,2);

            mc.CameraPosition = _cameraPos;
            mc.GazeDirection = _target - _cameraPos;
            mc.UpVector = _up;
            mc.Angle = (float)Math.PI/4.0f;

            mc.Width = _width;
            mc.Height = _height;

            mc.PlanePoint = new Vector3(0, 0, 0);
            mc.PlaneNormal = new Vector3(0, 1, 0);
            mc.PlaneColor = new Vector4(1, 1, 0, 1);

            mc.boxLBF = new Vector3(0,0,0);
            mc.boxRUN = new Vector3(2,2,2);
            mc.boxColor = new Vector4(0,0,1,1);

            mc.pointA = new Vector3(-3.5f,1,1);
            mc.pointB = new Vector3(-1.5f,1,0);
            mc.pointC = new Vector3(-2.5f, 1, 2);
            mc.triangleColor = new Vector4(0,1,1,1);

            mc.pLightOn = _pointLight;
            mc.pLightPosition = _pointLightPosition;
            mc.pLightColor = _pointLightColor;

            mc.areaLightPos = _areaLightPosition;
            mc.areaLightOn = true;
            mc.samplesX = _samplesX;
            mc.samplesY = _samplesY;

            mc.frameCount = ++_frameCount;

            BaseRenderer.SetupConstBufferForCS(context, mc, ref _constbuffer, 0);
        }

        protected bool BuildRenderTarget(OperatorPartContext context)
        {
            if (_targetTexture != null && _targetTexture.Description.Width == _width && _targetTexture.Description.Height == _height)//|| _uaTexture.Description.Width != _width)
            {
                return false;
            }

            var uavDesc = new Texture2DDescription
                                  {
                                      BindFlags = BindFlags.ShaderResource | BindFlags.UnorderedAccess,
                                      Format = Format.R8G8B8A8_UNorm,
                                      Width = (int)_width,
                                      Height = (int)_height,
                                      MipLevels = 1,
                                      SampleDescription = new SampleDescription(1, 0),
                                      Usage = ResourceUsage.Default,
                                      OptionFlags = ResourceOptionFlags.None,
                                      CpuAccessFlags = CpuAccessFlags.None,
                                      ArraySize = 1
                                  };
            var shadowDesc = new Texture2DDescription
                                {
                                    BindFlags = BindFlags.ShaderResource | BindFlags.UnorderedAccess,
                                    Format = Format.R32_Float,
                                    Width = (int)_width,
                                    Height = (int)_height,
                                    MipLevels = 1,
                                    SampleDescription = new SampleDescription(1, 0),
                                    Usage = ResourceUsage.Default,
                                    OptionFlags = ResourceOptionFlags.None,
                                    CpuAccessFlags = CpuAccessFlags.None,
                                    ArraySize = 1
                                };
            DisposeTextures();
            _targetTexture = new Texture2D(context.D3DDevice, uavDesc);
            _textureUAV = new UnorderedAccessView(context.D3DDevice, _targetTexture);
            _shadow = new Texture2D(context.D3DDevice, shadowDesc);
            _shadowUAV = new UnorderedAccessView(context.D3DDevice, _shadow);
            _shadowSRV = new ShaderResourceView(context.D3DDevice, _shadow);
            context.D3DDevice.ImmediateContext.ClearUnorderedAccessView(_shadowUAV, new Int4(0, 0, 0, 1));
            Logger.Error(this,"texture");

            return true;
        }

        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) 
        {
            //>>> _params
            var Code = inputs[(int)InputId.Code].Eval(context).Text;
            var CameraPosX = inputs[(int)InputId.CameraPosX].Eval(context).Value;
            var CameraPosY = inputs[(int)InputId.CameraPosY].Eval(context).Value;
            var CameraPosZ = inputs[(int)InputId.CameraPosZ].Eval(context).Value;
            var CameraPos = new Vector3(CameraPosX, CameraPosY, CameraPosZ);
            var PointLight = (int) inputs[(int)InputId.PointLight].Eval(context).Value;
            var PointLightPositionX = inputs[(int)InputId.PointLightPositionX].Eval(context).Value;
            var PointLightPositionY = inputs[(int)InputId.PointLightPositionY].Eval(context).Value;
            var PointLightPositionZ = inputs[(int)InputId.PointLightPositionZ].Eval(context).Value;
            var PointLightPosition = new Vector3(PointLightPositionX, PointLightPositionY, PointLightPositionZ);
            var PointLightColorR = inputs[(int)InputId.PointLightColorR].Eval(context).Value;
            var PointLightColorG = inputs[(int)InputId.PointLightColorG].Eval(context).Value;
            var PointLightColorB = inputs[(int)InputId.PointLightColorB].Eval(context).Value;
            var PointLightColorA = inputs[(int)InputId.PointLightColorA].Eval(context).Value;
            var PointLightColor = new Color4(PointLightColorR, PointLightColorG, PointLightColorB, PointLightColorA);
            var TargetX = inputs[(int)InputId.TargetX].Eval(context).Value;
            var TargetY = inputs[(int)InputId.TargetY].Eval(context).Value;
            var TargetZ = inputs[(int)InputId.TargetZ].Eval(context).Value;
            var Target = new Vector3(TargetX, TargetY, TargetZ);
            var UpX = inputs[(int)InputId.UpX].Eval(context).Value;
            var UpY = inputs[(int)InputId.UpY].Eval(context).Value;
            var UpZ = inputs[(int)InputId.UpZ].Eval(context).Value;
            var Up = new Vector3(UpX, UpY, UpZ);
            var AreaLightPositionX = inputs[(int)InputId.AreaLightPositionX].Eval(context).Value;
            var AreaLightPositionY = inputs[(int)InputId.AreaLightPositionY].Eval(context).Value;
            var AreaLightPositionZ = inputs[(int)InputId.AreaLightPositionZ].Eval(context).Value;
            var AreaLightPosition = new Vector3(AreaLightPositionX, AreaLightPositionY, AreaLightPositionZ);
            var SamplesX = inputs[(int)InputId.SamplesX].Eval(context).Value;
            var SamplesY = inputs[(int)InputId.SamplesY].Eval(context).Value;
            var Samples = new Vector2(SamplesX, SamplesY);
            //<<< _params
            
            if (_shadow != null && (_width != context.Viewport.Width || _height != context.Viewport.Height || _cameraPos != CameraPos ||
                _up != Up || _target != Target))
            {
                _frameCount = 0;
                context.D3DDevice.ImmediateContext.ClearUnorderedAccessView(_shadowUAV, new Int4(0, 0, 0, 1));
            }
            _width = context.Viewport.Width;
            _height = context.Viewport.Height;
            _cameraPos = CameraPos;
            _up = Up;
            _target = Target;
            var AspectRatio = _width / _height;
            var ClipX = 0.1f;
            var ClipY = 100000;
            _worldToCamera = CalcWorldToCamera(_cameraPos, _target, (float)_roll, PositionOffset, RotateOffset);
            _pointLight = PointLight == 1;
            _pointLightPosition = PointLightPosition;
            _pointLightColor = new Vector4(PointLightColorR, PointLightColorG, PointLightColorB, 1.0f);
            _areaLightPosition = AreaLightPosition;
            _samplesX = (uint)SamplesX;
            _samplesY = (uint)SamplesY;
            
            var prevTransform = context.WorldToCamera;
            context.WorldToCamera = _worldToCamera;

            _cameraToView = Matrix.PerspectiveFovLH(0, AspectRatio, ClipX, ClipY);
            var prevCamProj = context.CameraProjection;
            context.CameraProjection = _cameraToView;
            
            if (_cs == null)
            {
                Utilities.DisposeObj(ref _cs);
                var errors = new CompilerErrorCollection();
                try
                {
                    using (var bytecode = ShaderBytecode.Compile(GetCode(0), "CS", "cs_5_0", ShaderFlags.Debug))
                        _cs = new ComputeShader(D3DDevice.Device, bytecode);
                    //using (var bytecode = ShaderBytecode.CompileFromFile(@"C:\Users\tim\dev\raytracerTest.hlsl", "CS", "cs_5_0", ShaderFlags.Debug))
                    //    _cs = new ComputeShader(D3DDevice.Device, bytecode);
                    //Logger.Error(this,"dispatched");
                }
                catch (SharpDX.CompilationException ex)
                {
                    errors = ErrorsFromString(ex.Message);
                    Logger.Error(this,"Fx compile error: {0}", ex.Message);
                }
            }

            BuildRenderTarget(context);
            SetupConstBuffer(context);
           
            var deviceContext = context.D3DDevice.ImmediateContext;
            
            deviceContext.ComputeShader.Set(_cs);
            deviceContext.ComputeShader.SetUnorderedAccessView(0, _textureUAV);
            deviceContext.ComputeShader.SetUnorderedAccessView(1, _shadowUAV);
            _shadowFlag = _shadowFlag == 0 ? 1 : 0;
            deviceContext.ComputeShader.SetShaderResource(0, _shadowSRV);
            deviceContext.Dispatch((int)_width/20,(int)_height/20, 1);
            deviceContext.ComputeShader.SetUnorderedAccessView(0, null);
            deviceContext.ComputeShader.SetUnorderedAccessView(1, null);
            deviceContext.ComputeShader.SetShaderResource(0, null);
            //Logger.Error(this,"dispatched");
            
            context.Image = _targetTexture;
            //context.Image = _shadow[0];

            return context;
        }

        public Vector3 GetLastPosition()
        {
            return _cameraPos;
        }

        public void SetPosition(double time, Vector3 pos)
        {
            Animation.SetOperatorPartValue(OperatorPart.Parent.Inputs[(int)InputId.CameraPosX], time, pos.X);
            Animation.SetOperatorPartValue(OperatorPart.Parent.Inputs[(int)InputId.CameraPosY], time, pos.Y);
            Animation.SetOperatorPartValue(OperatorPart.Parent.Inputs[(int)InputId.CameraPosZ], time, pos.Z);
        }

        public Vector3 GetLastTarget()
        {
            return _target;
        }

        public void SetTarget(double time, Vector3 target)
        {
            Animation.SetOperatorPartValue(OperatorPart.Parent.Inputs[(int)InputId.TargetX], time, target.X);
            Animation.SetOperatorPartValue(OperatorPart.Parent.Inputs[(int)InputId.TargetY], time, target.Y);
            Animation.SetOperatorPartValue(OperatorPart.Parent.Inputs[(int)InputId.TargetZ], time, target.Z);
        }

        public double GetLastRoll()
        {
            return _roll;
        }

        public void SetRoll(double time, double roll)
        {
            Animation.SetOperatorPartValue(OperatorPart.Parent.Inputs[14], time, (float)roll);
        }

        public double CalculateFOV(OperatorPartContext context)
        {
            var invalidator = new OperatorPart.InvalidateTimeAccessors();
            OperatorPart.Connections[13].TraverseWithFunction(null, invalidator);
            var fov = OperatorPart.Connections[13].Eval(context).Value;
            return fov;
        }

        public double GetLastFOV()
        {
            return _fov;
        }

        public Matrix CalculateWorldToCamera(OperatorPartContext context)
        {
            var invalidator = new OperatorPart.InvalidateTimeAccessors();
            OperatorPart.Connections[1].TraverseWithFunction(null, invalidator);
            OperatorPart.Connections[2].TraverseWithFunction(null, invalidator);
            OperatorPart.Connections[3].TraverseWithFunction(null, invalidator);
            OperatorPart.Connections[4].TraverseWithFunction(null, invalidator);
            OperatorPart.Connections[5].TraverseWithFunction(null, invalidator);
            OperatorPart.Connections[6].TraverseWithFunction(null, invalidator);
            OperatorPart.Connections[7].TraverseWithFunction(null, invalidator);
            OperatorPart.Connections[8].TraverseWithFunction(null, invalidator);
            OperatorPart.Connections[9].TraverseWithFunction(null, invalidator);
            OperatorPart.Connections[14].TraverseWithFunction(null, invalidator);

            var x = OperatorPart.Connections[(int)InputId.CameraPosX].Eval(context).Value;
            var y = OperatorPart.Connections[(int)InputId.CameraPosY].Eval(context).Value;
            var z = OperatorPart.Connections[(int)InputId.CameraPosZ].Eval(context).Value;
            var position = new Vector3(x, y, z);

            x = PositionOffset.X;
            y = PositionOffset.Y;
            z = PositionOffset.Z;
            var positionOffset = new Vector3(x, y, z);

            x = OperatorPart.Connections[(int)InputId.TargetX].Eval(context).Value;
            y = OperatorPart.Connections[(int)InputId.TargetY].Eval(context).Value;
            z = OperatorPart.Connections[(int)InputId.TargetZ].Eval(context).Value;
            var target = new Vector3(x, y, z);

            x = RotateOffset.X;
            y = RotateOffset.Y;
            z = RotateOffset.Z;
            var rotateOffset = new Vector3(x, y, z);

            var roll = (float)Utilities.DegreeToRad(OperatorPart.Connections[14].Eval(context).Value);

            return CalcWorldToCamera(position, target, roll, positionOffset, rotateOffset);
        }

        Matrix CalcWorldToCamera(Vector3 position, Vector3 target, float roll, Vector3 positionOffset, Vector3 rotateOffset)
        {
            var worldToCamera = Matrix.LookAtLH(position, target, new Vector3(0, 1, 0));
            var rollRotation = Matrix.RotationAxis(new Vector3(0, 0, 1), -(float)roll);
            var additionalTranslation = Matrix.Translation(positionOffset);
            var additionalRotation = Matrix.RotationYawPitchRoll((float)Utilities.DegreeToRad(rotateOffset.Y),
                                                                 (float)Utilities.DegreeToRad(rotateOffset.X),
                                                                 (float)Utilities.DegreeToRad(rotateOffset.Z));

            return worldToCamera * rollRotation * additionalTranslation * additionalRotation;
        }

        public Matrix GetLastWorldToCamera()
        {
            return _worldToCamera;
        }

        public Matrix CalculateCameraToView(OperatorPartContext context)
        {
            var invalidator = new OperatorPart.InvalidateTimeAccessors();
            OperatorPart.Connections[10].TraverseWithFunction(null, invalidator);
            OperatorPart.Connections[11].TraverseWithFunction(null, invalidator);
            OperatorPart.Connections[12].TraverseWithFunction(null, invalidator);
            OperatorPart.Connections[13].TraverseWithFunction(null, invalidator);

            var aspectRatio = OperatorPart.Connections[10].Eval(context).Value;
            var clipNear = OperatorPart.Connections[11].Eval(context).Value;
            var clipFar = OperatorPart.Connections[12].Eval(context).Value;
            var fov = (float)Utilities.DegreeToRad(OperatorPart.Connections[13].Eval(context).Value);

            if (aspectRatio < 0)
            {
                if (!context.Variables.TryGetValue("AspectRatio", out aspectRatio))
                {
                    aspectRatio = (float)context.Viewport.Width / context.Viewport.Height;
                }
            }
            return Matrix.PerspectiveFovLH(fov, aspectRatio, clipNear, clipFar);
        }

        public Matrix GetLastCameraToView()
        {
            return _cameraToView;
        }

        private Texture2D _targetTexture;
        private UnorderedAccessView _textureUAV;
        private Texture2D _shadow;
        private ShaderResourceView _shadowSRV;
        private UnorderedAccessView _shadowUAV;
        private int _shadowFlag = 0;
        private ComputeShader _cs;
        private Buffer _constbuffer;
        private float _width = 640;
        private float _height = 480;
        private Vector3 _cameraPos;
        private Vector3 _target;
        private double _roll;
        private double _fov;
        private Matrix _worldToCamera;
        private Matrix _cameraToView;
        private bool _pointLight;
        private Vector3 _pointLightPosition;
        private Vector4 _pointLightColor;
        private Vector3 _up;
        private Vector3 PositionOffset = new Vector3(1,1,1);
        private Vector3 RotateOffset = new Vector3(1,1,1);
        private Vector3 _areaLightPosition;
        private uint _samplesX;
        private uint _samplesY;
        private uint _frameCount = 0;
    }
}

