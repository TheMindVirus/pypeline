//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using

namespace Framefield.Core.IDfad4d473_cbd7_4284_9ccd_365849e3ae05
{
    public class Class_FilmicToneMapper : FXImageFunction
    {
        protected override bool NeedsDepth { get { return false; } }

        //>>> _inputids
        private enum InputId
        {
            Code = 0,
            Image = 1,
            A = 2,
            B = 3,
            C = 4,
            D = 5,
            E = 6,
            F = 7,
            W = 8
        }
        //<<< _inputids

        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx)
        {
            return PrepareAndEvalOnChange(context, () =>
            {
                //>>> __params
                var Code = inputs[(int)InputId.Code].Eval(context).Text;
                var Image = inputs[(int)InputId.Image].Eval(context).Image;
                var A = inputs[(int)InputId.A].Eval(context).Value;
                var B = inputs[(int)InputId.B].Eval(context).Value;
                var C = inputs[(int)InputId.C].Eval(context).Value;
                var D = inputs[(int)InputId.D].Eval(context).Value;
                var E = inputs[(int)InputId.E].Eval(context).Value;
                var F = inputs[(int)InputId.F].Eval(context).Value;
                var W = inputs[(int)InputId.W].Eval(context).Value;
                //<<< __params

                ClearRenderTarget(context, new Color4(0, 0, 0, 1));

                //>>> _setup
                using (var ImageView = new ShaderResourceView(context.D3DDevice, Image))
                {
                    _effect.GetVariableByName("RenderTargetSize").AsVector().Set(new Vector2(_usedViewport.Width, _usedViewport.Height));
                    _effect.GetVariableByName("Image").AsShaderResource().SetResource(ImageView);
                    _effect.GetVariableByName("A").AsScalar().Set(A);
                    _effect.GetVariableByName("B").AsScalar().Set(B);
                    _effect.GetVariableByName("C").AsScalar().Set(C);
                    _effect.GetVariableByName("D").AsScalar().Set(D);
                    _effect.GetVariableByName("E").AsScalar().Set(E);
                    _effect.GetVariableByName("F").AsScalar().Set(F);
                    _effect.GetVariableByName("W").AsScalar().Set(W);
                    //<<< _setup

                    var prevBlendState = context.BlendState;
                    context.BlendState = OperatorPartContext.DefaultRenderer.DisabledBlendState;

                    Render(context);

                    context.BlendState = prevBlendState;
                    //>>> _cleanup
                    }
                //<<< _cleanup
            });
        }
    }
}

