//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using

namespace Framefield.Core.ID6bacb69d_7e54_4ca4_b101_2f9a3b83bb73
{
    public class Class_Add : OperatorPart.Function
    {
       //>>> _inputids
       private enum InputId
       {
           Value1 = 0,
           Value2 = 1,
           Blend = 2
       }
       //<<< _inputids
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
        //>>> _params
        var Value1 = (float) inputs[(int)InputId.Value1].Eval(context).Value;
        var Value2 = (float) inputs[(int)InputId.Value2].Eval(context).Value;
        var Blend = (float) inputs[(int)InputId.Blend].Eval(context).Value;
        //<<< _params
            
            context.Value=  (1-Blend)*Value1 + Blend*Value2;
            
            return context;
        }
    }
}

