using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;

namespace Framefield.Core.ID75c97a25_aa0d_4438_b350_1174ad6b9cca
{
    public class Class_PrintToConsole : OperatorPart.Function
    {
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            var Input = inputs[0];
            var Text = inputs[1].Eval(context).Text;

            Logger.Info(this,"{0}", Text);
            Input.Eval(context);

            return context;
        }
    }
}

