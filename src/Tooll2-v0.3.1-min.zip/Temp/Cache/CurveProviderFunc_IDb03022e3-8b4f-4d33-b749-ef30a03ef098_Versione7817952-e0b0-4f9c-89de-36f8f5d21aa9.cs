//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using

using System.IO;
using System.Text.RegularExpressions;
using Un4seen.Bass;
using Framefield.Core.Inputs;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace Framefield.Core.IDb03022e3_8b4f_4d33_b749_ef30a03ef098
{
    public class CurveProvider : SupplierAssembly
    {
    }
    
    public interface ICurveProvider {
        Vector4 SampleAt(double u);        
        List<Vector4> GetPoints();
        /*
        public class CurveProvider
        {
            public CurveProvider()
            {
                Logger.Info("CurveProvider()");
            }
            

            public static Model FromContext(OperatorPartContext context)
            {
                object model;
                context.Objects.TryGetValue(ID, out model);
                return model as Model;
            }
            

            //---- Members & Constants -----------------------------------------------


            public static readonly string ID = "CurveSuppier";
        }
        */


    }
}