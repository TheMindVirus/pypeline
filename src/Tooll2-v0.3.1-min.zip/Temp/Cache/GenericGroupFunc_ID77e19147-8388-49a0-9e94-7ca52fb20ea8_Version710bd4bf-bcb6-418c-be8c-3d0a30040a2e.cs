using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;

namespace Framefield.Core.ID77e19147_8388_49a0_9e94_7ca52fb20ea8
{
    public class Class_GenericGroup : OperatorPart.Function
    {
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            var Inputs = inputs[0];
            //!!automatic generated code ends here
            foreach (var input in inputs[0].Connections) {
                input.Eval(context);
            }
            //!!automatic generated code starts here
            return context;
        }
    }
}

