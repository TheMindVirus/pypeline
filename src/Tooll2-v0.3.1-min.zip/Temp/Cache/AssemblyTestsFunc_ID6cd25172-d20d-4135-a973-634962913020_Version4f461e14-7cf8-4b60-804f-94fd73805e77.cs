//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
using Framefield.Core.IDa0163af1_931f_4f37_9806_bb0a331db5cf; // SupplierAssemblyFunc
//<<< _using
using System.IO;


namespace Framefield.Core.ID6cd25172_d20d_4135_a973_634962913020
{
    public class Class_AssemblyTests : OperatorPart.Function
    {
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {

            var t = new Test04();
            t.Name = "horst";

            return context;
        }
    }
}

