//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using

using System.Runtime.InteropServices;
using Framefield.Core.Rendering;
using SharpDX.DXGI;
using SharpDX.D3DCompiler;
using SharpDX.Direct3D;
using Buffer = SharpDX.Direct3D11.Buffer;
using System.CodeDom.Compiler;
using System.Diagnostics;


namespace Framefield.Core.IDb749e8e4_c126_4b4e_a140_eefddceb9e5b
{
    public class Class_CSSurfacePaintCanvas : FXSourceCodeFunction
    {
        public override void Dispose()
        {
            Utilities.DisposeObj(ref _histoTexture);
            Utilities.DisposeObj(ref _finalTexture);
            Utilities.DisposeObj(ref _previousPickPositions);
            Utilities.DisposeObj(ref _csPaint);
            Utilities.DisposeObj(ref _csConvert);
        }

        //>>> _inputids
        private enum InputId
        {
            Code = 0,
            Image = 1,
            PickPositions = 2,
            ClearTrigger = 3,
            Player1PosX = 4,
            Player1PosY = 5,
            Player2PosX = 6,
            Player2PosY = 7,
            CarPartsMap = 8
        }
        //<<< _inputids

        protected bool BuildRenderTarget(OperatorPartContext context)
        {
            if (_histoTexture != null)
            {
                return false;
            }

            var uavHistoDesc = new Texture2DDescription
                                  {
                                      BindFlags = BindFlags.ShaderResource | BindFlags.UnorderedAccess,
                                      Format = Format.R32_UInt,//
                                      Width = 2048,
                                      Height = 2048,
                                      MipLevels = 1,
                                      SampleDescription = new SampleDescription(1, 0),
                                      Usage = ResourceUsage.Default,
                                      OptionFlags = ResourceOptionFlags.None,
                                      CpuAccessFlags = CpuAccessFlags.None,
                                      ArraySize = 1
                                  };
            Utilities.DisposeObj(ref _histoTexture);
            _histoTexture = new Texture2D(context.D3DDevice, uavHistoDesc);

            var uavFinalDesc = new Texture2DDescription
                                  {
                                      BindFlags = BindFlags.ShaderResource | BindFlags.UnorderedAccess,
                                      Format = Format.R8G8B8A8_UNorm,
                                      Width = 2048,
                                      Height = 2048,
                                      MipLevels = 1,
                                      SampleDescription = new SampleDescription(1, 0),
                                      Usage = ResourceUsage.Default,
                                      OptionFlags = ResourceOptionFlags.None,
                                      CpuAccessFlags = CpuAccessFlags.None,
                                      ArraySize = 1
                                  };
            Utilities.DisposeObj(ref _finalTexture);
            _finalTexture = new Texture2D(context.D3DDevice, uavFinalDesc);

            return true;
        }


        private Stopwatch _stopwatch = new Stopwatch();
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) 
        {
            //>>> _params
            var Code = inputs[(int)InputId.Code].Eval(context).Text;
            var Image = inputs[(int)InputId.Image].Eval(context).Image; // Needs to be checked for null!
            var PickPositions = inputs[(int)InputId.PickPositions].Eval(context).Image; // Needs to be checked for null!
            var ClearTrigger = inputs[(int)InputId.ClearTrigger].Eval(context).Value;
            var Player1PosX = inputs[(int)InputId.Player1PosX].Eval(context).Value;
            var Player1PosY = inputs[(int)InputId.Player1PosY].Eval(context).Value;
            var Player1Pos = new Vector2(Player1PosX, Player1PosY);
            var Player2PosX = inputs[(int)InputId.Player2PosX].Eval(context).Value;
            var Player2PosY = inputs[(int)InputId.Player2PosY].Eval(context).Value;
            var Player2Pos = new Vector2(Player2PosX, Player2PosY);
            var CarPartsMap = inputs[(int)InputId.CarPartsMap].Eval(context).Image; // Needs to be checked for null!
            //<<< _params

            if (_csPaint == null)
            {
                Utilities.DisposeObj(ref _csPaint);
                Utilities.DisposeObj(ref _csConvert);
                var errors = new CompilerErrorCollection();
                try
                {
                    using (var bytecode = ShaderBytecode.Compile(GetCode(0), "CSPaint", "cs_5_0", ShaderFlags.Debug))
                        _csPaint = new ComputeShader(D3DDevice.Device, bytecode);
                    using (var bytecode = ShaderBytecode.Compile(GetCode(0), "CSConvert", "cs_5_0", ShaderFlags.Debug))
                        _csConvert = new ComputeShader(D3DDevice.Device, bytecode);
                }
                catch (CompilationException ex)
                {
                    errors = ErrorsFromString(ex.Message);
                    Logger.Error(this,"Fx compile error: {0}", ex.Message);
                }
            }

            BuildRenderTarget(context);

            //_effect.GetVariableByName("RenderTargetSize").AsVector().Set(new Vector2(_usedViewport.Width, _usedViewport.Height));
            _stopwatch.Restart();

            int carPartId = -1;
            int playerId = -1;
            // check if there is a car part to paint, currently only one is handled per frame
            dynamic carParts = context.Objects.ContainsKey("CarParts") ? context.Objects["CarParts"] : null;
            if (carParts != null)
            {
                int idx = 0;
                foreach (var carPart in carParts)
                {
                    if (carPart.OwnedBy == -1)
                    {
                        if (carPart.PixelsPlayer1 > carPart.NumPixels/2)
                        {
                            Logger.Info(this,"PLAYER 1 OWNED PART {0}. Part had {1} pixels and player {2}", idx, carPart.NumPixels, carPart.PixelsPlayer1);
                            carPart.OwnedBy = 0;
                            carPart.ConquerTime = context.Time;
                            carPart.ConquerPosition = new Vector3(Player1Pos, 0);
                            carPartId = idx;
                            playerId = 0;
                            Changed = true;
                            break;
                        }
                        else if (carPart.PixelsPlayer2 > carPart.NumPixels/2)
                        {
                            Logger.Info(this,"PLAYER 2 OWNED PART {0}. Part had {1} pixels and player {2}", idx, carPart.NumPixels, carPart.PixelsPlayer2);
                            carPart.OwnedBy = 1;
                            carPart.ConquerTime = context.Time;
                            carPart.ConquerPosition = new Vector3(Player2Pos, 0);
                            carPartId = idx;
                            playerId = 1;
                            Changed = true;
                            break;
                        }
                    }
                    ++idx;
                }
            }

            if (Changed)// && carPartId != -1)
            {
                var deviceContext = context.D3DDevice.ImmediateContext;
    
                if (_previousPickPositions == null)
                {
                    var imageDesc = new Texture2DDescription
                    {
                        BindFlags = PickPositions.Description.BindFlags,
                        Format = PickPositions.Description.Format,
                        Width = PickPositions.Description.Width,
                        Height = PickPositions.Description.Height,
                        MipLevels = PickPositions.Description.MipLevels,
                        SampleDescription = new SampleDescription(1, 0),
                        Usage = ResourceUsage.Default,
                        OptionFlags = ResourceOptionFlags.None,
                        CpuAccessFlags = CpuAccessFlags.None,
                        ArraySize = 1
                    };
    
                    _previousPickPositions = new Texture2D(D3DDevice.Device, imageDesc);
                    context.D3DDevice.ImmediateContext.CopyResource(PickPositions, _previousPickPositions);
                    return context;
                }
                
                // setup parameters
                using (var data = new DataStream(Marshal.SizeOf(typeof(Int4)), true, true))
                {
                    data.Write(new Int4(carPartId, playerId, 0, 0));
                    data.Position = 0;
    
                    if (_parameterBuffer == null)
                    {
                        var bufferDesc = new BufferDescription { Usage = ResourceUsage.Default, SizeInBytes = Marshal.SizeOf(typeof(Int4)), BindFlags = BindFlags.ConstantBuffer };
                        _parameterBuffer = new Buffer(context.D3DDevice, data, bufferDesc);
                    }
                    else
                    {
                        context.D3DDevice.ImmediateContext.UpdateSubresource(new DataBox(data.DataPointer, 0, 0), _parameterBuffer);
                    }
                }
    
                using (var imageView = new ShaderResourceView(context.D3DDevice, Image))
                using (var srvPickPositions = new ShaderResourceView(context.D3DDevice, PickPositions))
                using (var srvPreviousPickPositionsView = new ShaderResourceView(context.D3DDevice, _previousPickPositions))
                using (var srvCarPartsMap = new ShaderResourceView(context.D3DDevice, CarPartsMap))
                using (var uav = new UnorderedAccessView(context.D3DDevice, _histoTexture))
                {
                    if (ClearTrigger > 0.5)
                    {
                        deviceContext.ClearUnorderedAccessView(uav, new Int4());
                    }
                    deviceContext.ComputeShader.Set(_csPaint);
                    deviceContext.ComputeShader.SetUnorderedAccessView(0, uav);
                    deviceContext.ComputeShader.SetShaderResource(0, imageView);
                    deviceContext.ComputeShader.SetShaderResource(1, srvPickPositions);
                    deviceContext.ComputeShader.SetShaderResource(2, srvPreviousPickPositionsView);
                    deviceContext.ComputeShader.SetShaderResource(3, srvCarPartsMap);
                    deviceContext.ComputeShader.SetConstantBuffer(0, _parameterBuffer);
                    deviceContext.Dispatch(64, 64, 1);
                    deviceContext.ComputeShader.SetUnorderedAccessView(0, null);
                    deviceContext.ComputeShader.SetShaderResource(0, null);
                    deviceContext.ComputeShader.SetShaderResource(1, null);
                    deviceContext.ComputeShader.SetShaderResource(2, null);
                    deviceContext.ComputeShader.SetShaderResource(3, null);
                    deviceContext.ComputeShader.SetConstantBuffer(0, null);
                }
    
                // convert to color texture!
                using (var inputView = new ShaderResourceView(context.D3DDevice, _histoTexture))
                using (var uav = new UnorderedAccessView(context.D3DDevice, _finalTexture))
                {
                    deviceContext.ComputeShader.Set(_csConvert);
                    deviceContext.ComputeShader.SetShaderResource(4, inputView);
                    deviceContext.ComputeShader.SetUnorderedAccessView(1, uav);
                    deviceContext.Dispatch(64, 64, 1);
                    deviceContext.ComputeShader.SetUnorderedAccessView(1, null);
                    deviceContext.ComputeShader.SetShaderResource(4, null);
                }
    
                context.D3DDevice.ImmediateContext.CopyResource(PickPositions, _previousPickPositions);
    
                _stopwatch.Stop();
                //Logger.Info(this,"istoupdate took: {0}ms", _stopwatch.ElapsedMilliseconds);
                Changed = false;
            }
            
            context.Image = _finalTexture;

            return context;
        }

        private Texture2D _histoTexture;
        private Texture2D _finalTexture;
        private Texture2D _previousPickPositions;
        private ComputeShader _csPaint;
        private ComputeShader _csConvert;
        private Buffer _parameterBuffer;
    }
}

