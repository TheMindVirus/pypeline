using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;


namespace Framefield.Core.ID20d6660e_29f1_4ba6_ba8a_da6709ab087c
{
    public class Class_SamplerState : OperatorPart.Function
    {
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            var SceneInput = inputs[0];

            bool changed = false;
            for (int i = 1; i <= 10; ++i) 
                changed |= inputs[i].Func.Changed;

            if (changed) {
/*
                var FillMode = inputs[1].Eval(context).Value;
                var CullMode = inputs[2].Eval(context).Value;
                var FrontCounterClockwise = inputs[3].Eval(context).Value;
                var DepthBias = inputs[4].Eval(context).Value;
                var DepthBiasClamp = inputs[5].Eval(context).Value;
                var SlopeScaledDepthBias = inputs[6].Eval(context).Value;
                var DepthClipEnable = inputs[7].Eval(context).Value;
                var ScissorEnable = inputs[8].Eval(context).Value;
                var MultisampleEnable = inputs[9].Eval(context).Value;
                var AntialiasedLineEnable = inputs[10].Eval(context).Value;

                var rasterizerDescription = new RasterizerStateDescription();
                rasterizerDescription.FillMode = (FillMode) FillMode;
                rasterizerDescription.CullMode = (CullMode) CullMode;
                rasterizerDescription.IsFrontCounterclockwise = FrontCounterClockwise == 1.0 ? true : false;
                rasterizerDescription.DepthBias = (int) DepthBias;
                rasterizerDescription.DepthBiasClamp = DepthBiasClamp;
                rasterizerDescription.SlopeScaledDepthBias = SlopeScaledDepthBias;
                rasterizerDescription.IsDepthClipEnabled = DepthClipEnable == 1.0 ? true : false;
                rasterizerDescription.IsScissorEnabled = ScissorEnable == 1.0 ? true : false;
                rasterizerDescription.IsMultisampleEnabled = MultisampleEnable == 1.0 ? true : false;
                rasterizerDescription.IsAntialiasedLineEnabled = AntialiasedLineEnable == 1.0 ? true : false;

                if (m_RasterizerState != null) {
                    m_RasterizerState.Dispose();
                    m_RasterizerState = null;
                }
                m_RasterizerState = RasterizerState.FromDescription(context.D3DDevice, rasterizerDescription);
*/
            }

//            var prevRasterizerState = context.RasterizerState;
//            context.RasterizerState = m_RasterizerState;
            SceneInput.Eval(context);
//            context.RasterizerState = prevRasterizerState;

            return context;
        }
//        private SamplerState m_SamplerState = null;
    }
}

