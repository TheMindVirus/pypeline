using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using SharpDX;
using SharpDX.Direct3D11;
using Framefield.Core.Rendering;
using Buffer = SharpDX.Direct3D11.Buffer;

namespace Framefield.Core.ID73dd290b_c523_471e_9355_92397333b10c
{
    public class Class_SHLightTestRef : FXSourceCodeFunction, IFXSceneSourceCode
    {

        class Renderer : BaseRenderer
        {
        }

        public override void Dispose() {
            Utilities.DisposeObj(ref _renderer);
            base.Dispose();
        }

        //>>> _inputids
        private enum InputId
        {
            Code = 0,
            Scene = 1,
            CubeMap = 2,
            ColorScaleX = 3,
            ColorScaleY = 4,
            ColorScaleZ = 5
        }
        //<<< _inputids

        bool _firstEval = true;
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            //>>> _params
            var Code = inputs[(int)InputId.Code].Eval(context).Text;
            var Scene = inputs[(int)InputId.Scene];
            var CubeMap = inputs[(int)InputId.CubeMap].Eval(context).Image; // Needs to be checked for null!
            var ColorScaleX = inputs[(int)InputId.ColorScaleX].Eval(context).Value;
            var ColorScaleY = inputs[(int)InputId.ColorScaleY].Eval(context).Value;
            var ColorScaleZ = inputs[(int)InputId.ColorScaleZ].Eval(context).Value;
            var ColorScale = new Vector3(ColorScaleX, ColorScaleY, ColorScaleZ);
            //<<< _params
            if (_firstEval) {
                for (int i = 0; i < NumCodes(); ++i)
                    Compile(i);
                _firstEval = false;
                Changed = true;
            }

            using (var CubeMapView = new ShaderResourceView(context.D3DDevice, CubeMap))
            {
                _effect.GetVariableByName("CubeMap").AsShaderResource().SetResource(CubeMapView);

                if (Changed)
                {
                    var colors = Texture2D.SHProjectCubeMap(context.D3DDevice.ImmediateContext, CubeMap, 3);
//                    for (int i = 0; i < colors.Length; ++i)
//                    {
//                        Logger.Info(this,"{0}    {1}     {2}", colors[i].Red, colors[i].Green, colors[i].Blue);
//                    }
                    float[] r = new float[9];
                    float[] g = new float[9];
                    float[] b = new float[9];
                    float[] convolveCosineLobeBandFactor = new float[9]
                    {
                        MathUtil.Pi,
                        2.0f * MathUtil.Pi/3.0f, 2.0f * MathUtil.Pi/3.0f, 2.0f * MathUtil.Pi/3.0f,
                        MathUtil.Pi/4.0f, MathUtil.Pi/4.0f, MathUtil.Pi/4.0f, MathUtil.Pi/4.0f, MathUtil.Pi/4.0f
                    };
                    
                    for (int i = 0; i < 9; ++i)
                    {
                        r[i] = colors[i].Red * convolveCosineLobeBandFactor[i] / MathUtil.Pi / 10.0f;
                        g[i] = colors[i].Green * convolveCosineLobeBandFactor[i] / MathUtil.Pi/ 10.0f;
                        b[i] = colors[i].Blue * convolveCosineLobeBandFactor[i] / MathUtil.Pi/ 10.0f;
                    }
                    for (int i = 0; i < colors.Length; ++i)
                    {
                        Logger.Info(this,"{0}    {1}     {2}", r[i], g[i], b[i]);
                    }
                    
                    //float[] L_r = new float[9];
                    //float[] L_g = new float[9];
                    //float[] L_b = new float[9];
                    
                    
                    
                    /*
                    float scale = 0.5f;
                    for (int i = 0; i < colors.Length; ++i)
                    {
                        r[i] = colors[i].Red * ColorScaleX;
                        g[i] = colors[i].Green * ColorScaleX;
                        b[i] = colors[i].Blue * ColorScaleX;
                    }
                    */
                    
                    // grace cathedral
                    r[0] = 0.79f;
                    r[1] = 0.39f;
                    r[2] = -0.34f;
                    r[3] = -0.29f;
                    r[4] = -0.11f;
                    r[5] = -0.26f;
                    r[6] = -0.16f;
                    r[7] = 0.56f;
                    r[8] = 0.21f;
                    
                    g[0] = 0.44f;
                    g[1] = 0.35f;
                    g[2] = -0.18f;
                    g[3] = -0.06f;
                    g[4] = -0.05f;
                    g[5] = -0.22f;
                    g[6] = -0.09f;
                    g[7] = 0.21f;
                    g[8] = -0.05f;
                    
                    b[0] = 0.54f;
                    b[1] = 0.60f;
                    b[2] = -0.27f;
                    b[3] = 0.01f;
                    b[4] = -0.12f;
                    b[5] = -0.47f;
                    b[6] = -0.15f;
                    b[7] = 0.14f;
                    b[8] = -0.30f;

/*
                    // st peters basilica
                    r[0] = 0.36f;
                    r[1] = 0.18f;
                    r[2] = -0.02f;
                    r[3] = 0.03f;
                    r[4] = 0.02f;
                    r[5] = -0.05f;
                    r[6] = -0.09f;
                    r[7] = 0.01f;
                    r[8] = -0.08f;
                    
                    g[0] = 0.26f;
                    g[1] = 0.14f;
                    g[2] = -0.01f;
                    g[3] = 0.02f;
                    g[4] = 0.01f;
                    g[5] = -0.03f;
                    g[6] = -0.08f;
                    g[7] = 0.00f;
                    g[8] = -0.06f;
                    
                    b[0] = 0.23f;
                    b[1] = 0.13f;
                    b[2] = -0.00f;
                    b[3] = 0.01f;
                    b[4] = 0.00f;
                    b[5] = -0.01f;
                    b[6] = -0.07f;
                    b[7] = 0.00f;
                    b[8] = 0.00f;
*/
                    _matR = CreateLightMatrix(r);
                    Logger.Info(this,"{0}", _matR);
                    _matG = CreateLightMatrix(g);
                    _matB = CreateLightMatrix(b);
                    Changed = false;
                }
                _effect.GetVariableByName("matR").AsMatrix().SetMatrix(_matR);
                _effect.GetVariableByName("matG").AsMatrix().SetMatrix(_matG);
                _effect.GetVariableByName("matB").AsMatrix().SetMatrix(_matB);
//                Logger.Info(this,"l: {0}", colors.Length);
//                string s = String.Empty;
//                Logger.Info(this,"{0}", s);
                using (new PropertyStasher<OperatorPartContext>(context, "Effect", "Renderer")) {
                    context.Effect = _effect;
                    context.Renderer = _renderer;
         
                    Scene.Eval(context);
                }
            }
            return context;
        }

        private Matrix CreateLightMatrix(float[] lightCoefs)
        {
            if (lightCoefs.Length < 9)
                return Matrix.Identity;
            var c1 = 0.429043f; 
            var c2 = 0.511664f;
            var c3 = 0.743125f;
            var c4 = 0.886227f;
            var c5 = 0.247708f;

            var L00 = lightCoefs[0];
            var L1_1 = lightCoefs[1];
            var L10 = lightCoefs[2];
            var L11 = lightCoefs[3];
            var L2_2 = lightCoefs[4];
            var L2_1 = lightCoefs[5];
            var L20 = lightCoefs[6];
            var L21 = lightCoefs[7];
            var L22 = lightCoefs[8];

            Matrix m = new Matrix(c1*L22,  c1*L2_2, c1*L21,  c2*L11,
                                  c1*L2_2, -c1*L22, c1*L2_1, c2*L1_1,
                                  c1*L21,  c1*L2_1, c3*L20,  c2*L10,
                                  c2*L11,  c2*L1_1, c2*L10,  c4*L00-c5*L20);
            return m;            
        }

        private Renderer _renderer = new Renderer();
        Matrix _matR, _matG, _matB;
    }
}


