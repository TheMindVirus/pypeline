using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;


namespace Framefield.Core.IDb1f7a9a9_f309_48dc_89ee_b11932cd4053
{
    public class Class_ReadDynamic : OperatorPart.Function
    {
        //>>> _inputids
        private enum InputId
        {
            StringList = 0
        }
        //<<< _inputids



        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            dynamic StringList = inputs[(int)InputId.StringList].Eval(context).Dynamic;
            if(StringList == null) {
                Logger.Info(this,"Can't convert incoming structure to Dynamic");
                context.Value= -1;
                return context;
            }
            
            context.Value= StringList.Count;            
            return context;
        }
    }
}

