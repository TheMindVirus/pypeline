//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using

using System.Runtime.InteropServices;
using Framefield.Core.Rendering;
using SharpDX.DXGI;
using SharpDX.D3DCompiler;
using Buffer = SharpDX.Direct3D11.Buffer;
using System.CodeDom.Compiler;


namespace Framefield.Core.IDc2e6515f_88f5_49e0_8aef_7573c48a6bd3
{
    public class Class_CSSimple : FXSourceCodeFunction
    {
        [StructLayout(LayoutKind.Explicit, Size = 144)]
        public struct ConstBufferLayout
        {
            [FieldOffset(0)] 
            public Color4 Color;
        }
        
        //>>> _inputids
        private enum InputId
        {
            Code = 0
        }
        //<<< _inputids

        public void Dispose()
        {
            Utilities.DisposeObj(ref _uaTexture);
            Utilities.DisposeObj(ref _uaTextureUAV);
            Utilities.DisposeObj(ref _cs);
            base.Dispose();
        }

        protected bool BuildRenderTarget(OperatorPartContext context)
        {
            if (_uaTexture != null)
            {
                return false;
            }

            var uavDesc = new Texture2DDescription
                                  {
                                      BindFlags = BindFlags.ShaderResource | BindFlags.UnorderedAccess,
                                      Format = Format.R8G8B8A8_UNorm,
                                      Width = 256,
                                      Height = 256,
                                      MipLevels = 1,
                                      SampleDescription = new SampleDescription(1, 0),
                                      Usage = ResourceUsage.Default,
                                      OptionFlags = ResourceOptionFlags.None,
                                      CpuAccessFlags = CpuAccessFlags.None,
                                      ArraySize = 1
                                  };
            Utilities.DisposeObj(ref _uaTexture);
            Utilities.DisposeObj(ref _uaTextureUAV);
            _uaTexture = new Texture2D(context.D3DDevice, uavDesc);
            _uaTextureUAV = new UnorderedAccessView(context.D3DDevice, _uaTexture);
            Logger.Error(this,"texture");

            return true;
        }


        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) 
        {
            //>>> _params
            var Code = inputs[(int)InputId.Code].Eval(context).Text;
            //<<< _params

            if (_cs == null)
            {
                Utilities.DisposeObj(ref _cs);
                var errors = new CompilerErrorCollection();
                try
                {
                    using (var bytecode = ShaderBytecode.Compile(GetCode(0), "CS", "cs_5_0", ShaderFlags.Debug))
                        _cs = new ComputeShader(D3DDevice.Device, bytecode);
                }
                catch (SharpDX.CompilationException ex)
                {
                    errors = ErrorsFromString(ex.Message);
                    Logger.Error(this,"Fx compile error: {0}", ex.Message);
                }
            }

            BuildRenderTarget(context);

            var mc = new ConstBufferLayout();
            mc.Color = new Color4(1, 0, 1, 1);

            BaseRenderer.SetupConstBufferForCS(context, mc, ref _constBuffer, 0);

            var deviceContext = context.D3DDevice.ImmediateContext;
            deviceContext.ComputeShader.Set(_cs);
            deviceContext.ComputeShader.SetUnorderedAccessView(0, _uaTextureUAV);
            deviceContext.Dispatch(16, 16, 1);
            deviceContext.ComputeShader.SetUnorderedAccessView(0, null);
            Logger.Error(this,"dispatched");

            context.Image = _uaTexture;

            return context;
        }

        private Buffer _constBuffer;
        private Texture2D _uaTexture;
        private UnorderedAccessView _uaTextureUAV;
        private ComputeShader _cs;
    }
}

