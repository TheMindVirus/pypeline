using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using System.Windows.Forms;

namespace Framefield.Core.IDd76a5747_c4c7_4784_9427_3bad7b5b261b
{
    public class Class_CapsLockedPressed : OperatorPart.Function, Framefield.Core.OperatorPartTraits.ITimeAccessor
    {
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            context.Value = Control.IsKeyLocked(Keys.CapsLock) ? 1f : 0f;
            return context;
        }
    }
}


