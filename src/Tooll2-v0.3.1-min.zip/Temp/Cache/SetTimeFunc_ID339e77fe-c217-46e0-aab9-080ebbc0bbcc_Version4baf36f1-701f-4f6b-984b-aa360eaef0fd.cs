//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using

namespace Framefield.Core.ID339e77fe_c217_46e0_aab9_080ebbc0bbcc
{
    public class Class_SetTime : OperatorPart.Function
    {
        //>>> _inputids
        private enum InputId
        {
            Input = 0,
            Time = 1
        }
        //<<< _inputids

        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            //>>> _params 
            var Input = inputs[(int)InputId.Input];
            var Time = inputs[(int)InputId.Time].Eval(context).Value;
            //<<< _params 

            var oldTime = context.Time;
            context.Time = Time;

            //var invalidator = new OperatorPart.InvalidateTimeAccessors();
            //Input.TraverseWithFunction(invalidator, null);
            Input.Eval(context);

            context.Time = oldTime;
            return context;
        }

    }
}


