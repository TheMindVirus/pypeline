//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using

namespace Framefield.Core.ID2d6a5c43_f771_4911_b3dd_4d8c54bc6619
{
    public class Class_CurrentUserName : OperatorPart.Function
    {
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx)
        {
            string name = string.Empty;
            try
            {
                name = Environment.UserName;
            }
            catch
            {
            }
            if (String.IsNullOrEmpty(name))
                name = "you";
            context.Text = name;
            return context;
        }
    }
}

