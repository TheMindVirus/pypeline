//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using

using BulletSharp;
using BulletSharp.SoftBody;

namespace Framefield.Core.ID7ea0037c_42ee_44ab_b4b5_432eee9fc2e9
{

    public class Class_BulletRope : OperatorPart.Function, Framefield.Core.OperatorPartTraits.ITimeAccessor
    {
        //>>> _inputids
        private enum InputId
        {
            BoxScene = 0,
            RopeScene = 1,
            ResetTrigger = 2,
            DetachTrigger = 3,
            RopeFixX = 4,
            RopeFixY = 5,
            RopeFixZ = 6,
            WindX = 7,
            WindY = 8,
            WindZ = 9,
            RopeOffset = 10
        }
        //<<< _inputids
        //>>> _outputids
        private enum OutputId
        {
            Scene = 0,
            IsWorldStable = 1,
            TopHeight = 2
        }
        //<<< _outputids


        public Class_BulletRope()
        {
            CreateEmptyWorld();
        }

        public override void Dispose()
        {
            CleanupWorld();
            base.Dispose();
        }

        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx)
        {
            switch (outputIdx)
            {
                case (int)OutputId.Scene:
                {
                    context = UpdatePhysicsAndScene(context, inputs);

                    _isWorldStable = false;
                    _maxTowerHeight = -1;
                    AnalyseWorld(out _isWorldStable, out _maxTowerHeight);
                    break;
                }
                case (int)OutputId.IsWorldStable: 
                {
                    context.Value = _isWorldStable ? 1.0f : 0.0f;
                    break;
                }
                case (int)OutputId.TopHeight:
                {
                    context.Value = _maxTowerHeight;
                    break;
                }
            }
            return context;
        }

        public OperatorPartContext UpdatePhysicsAndScene(OperatorPartContext context, List<OperatorPart> inputs)
        {
            //>>> _params
            var BoxScene = inputs[(int)InputId.BoxScene];
            var RopeScene = inputs[(int)InputId.RopeScene];
            var ResetTrigger = inputs[(int)InputId.ResetTrigger].Eval(context).Value;
            var DetachTrigger = inputs[(int)InputId.DetachTrigger].Eval(context).Value;
            var RopeFixX = inputs[(int)InputId.RopeFixX].Eval(context).Value;
            var RopeFixY = inputs[(int)InputId.RopeFixY].Eval(context).Value;
            var RopeFixZ = inputs[(int)InputId.RopeFixZ].Eval(context).Value;
            var RopeFix = new Vector3(RopeFixX, RopeFixY, RopeFixZ);
            var WindX = inputs[(int)InputId.WindX].Eval(context).Value;
            var WindY = inputs[(int)InputId.WindY].Eval(context).Value;
            var WindZ = inputs[(int)InputId.WindZ].Eval(context).Value;
            var Wind = new Vector3(WindX, WindY, WindZ);
            var RopeOffset = inputs[(int)InputId.RopeOffset].Eval(context).Value;
            //<<< _params

            bool resetTriggered = _oldResetTrigger < 0.5 && ResetTrigger > 0.5;
            _oldResetTrigger = ResetTrigger;
            if (resetTriggered)
            {
                CleanupWorld();
                CreateEmptyWorld();
            }

            if (_world.NumCollisionObjects == 0)
            {
                AddSceneToWorld(RopeFix, RopeOffset);
                _lastTime = context.Time; 
            }

            ChangedRopeFixation(RopeFix, RopeOffset);

            bool detachFlankUp = _oldDetachTrigger < 0.5 && DetachTrigger > 0.5;
            bool detachFlankDown = _oldDetachTrigger > 0.5 && DetachTrigger < 0.5;
            _oldDetachTrigger = DetachTrigger;
            if (detachFlankUp)
            {
                if (_rope != null)
                {
                    //detach box
                    _rope.Anchors.Clear();
                    if (_attachedBody != null)
                    {
                        //enable free moving/rotating
                        _attachedBody.LinearFactor = new Vector3(1, 1, 1);
                        _attachedBody.AngularFactor = new Vector3(1, 1, 1);
                        _attachedBody = null;
                    }
                }
            }
            if (detachFlankDown)
            {
                if (_rope != null)
                {
                    //create and attach new box
                    _attachedBody = CreateAndAppendBoxToRope(_rope, _boxCollisionShape);
                    _world.AddRigidBody(_attachedBody);
                }
            }

            if (_rope != null)//_attachedBody != null)
            {
                //_attachedBody.ApplyForce(Wind, Vector3.Zero);
                foreach (Node node in _rope.Nodes)
                {
                    node.Force += Wind;
                }
            }


            _softBodyWorldInfo.SparseSdf.GarbageCollect();

            float frameDelta = context.Time - _lastTime;
            _lastTime = context.Time;
            _world.StepSimulation(frameDelta, 1000, 0.02f);

            foreach (CollisionObject colObj in _world.CollisionObjectArray)
            {
                if (colObj is RigidBody && colObj != _ground)
                {
                    var prevTransform = context.ObjectTWorld;
                    context.ObjectTWorld = colObj.WorldTransform * prevTransform;
                    BoxScene.Eval(context);
                    context.ObjectTWorld = prevTransform;
                }
            }

            foreach (SoftBody softBody in _world.SoftBodyArray)
            {
                Matrix transform = Matrix.Identity;
                Matrix rotation = Matrix.Identity;
                Vector3 xAxis, yAxis, zAxis, perpDir, from, to;
                for (int i = 0; i < softBody.Links.Count; ++i)
                {
                    NodePtrArray nodes = softBody.Links[i].Nodes;
                    from = nodes[0].X;
                    to = nodes[1].X;

                    var prevTransform = context.ObjectTWorld;
        
                    yAxis = to - from; //dont normalize, because we want scaling along y
                    perpDir = Vector3.Cross(Vector3.UnitZ, yAxis);
                    perpDir.Normalize();
                    zAxis = Vector3.Cross(yAxis, perpDir);
                    zAxis.Normalize();
                    xAxis = Vector3.Cross(yAxis, zAxis);
                    xAxis.Normalize();

                    rotation = Matrix.Identity;
                    if ((i & 1) != 0)
                        rotation = Matrix.RotationAxis(Vector3.UnitY, (float)Math.PI/2);

                    transform.Up = yAxis;
                    transform.Backward = zAxis;
                    transform.Right = xAxis;
                    transform.TranslationVector = (from + to)*0.5f;

                    context.ObjectTWorld = rotation * transform * prevTransform;
                    RopeScene.Eval(context);

                    context.ObjectTWorld = prevTransform;

                    bool linkToFixedNode = nodes[0].InverseMass < 0.001f || nodes[1].InverseMass < 0.001f;
                    if (linkToFixedNode)
                        break;
                }
            }
            return context;
        }

        void AnalyseWorld(out bool isWorldStable, out float maxTowerHeight)
        {
            int numReleasedCubes = 0; //except the attached one
            int numSleepingReleasedCubes = 0; //except the attached one
            foreach (CollisionObject colObj in _world.CollisionObjectArray)
            {
                RigidBody body = colObj as RigidBody;
                if (body != null && body != _ground && body != _attachedBody)
                    ++numReleasedCubes;
                if (body != null && body != _ground && body != _attachedBody && body.WantsSleeping)
                    ++numSleepingReleasedCubes;
            }
            int numCubesTouchingGround = 0;
            int numSleepingCubesTouchingGround = 0;
            if (_groundSensor != null)
            {
                numCubesTouchingGround = _groundSensor.NumOverlappingObjects - 1; //substract ground body
                for (int i = 0; i < _groundSensor.NumOverlappingObjects; ++i)
                {
                    RigidBody body = _groundSensor.GetOverlappingObject(i) as RigidBody;
                    if (body != null && body != _ground && body != _attachedBody && body.WantsSleeping)
                        ++numSleepingCubesTouchingGround;
                }
            }

            isWorldStable = numReleasedCubes == numSleepingReleasedCubes;
            bool areTowersStable = numCubesTouchingGround == numSleepingCubesTouchingGround;

            maxTowerHeight = -1;
            if (isWorldStable)
            {
                foreach (CollisionObject colObj in _world.CollisionObjectArray)
                {
                    RigidBody body = colObj as RigidBody;
                    if (body != null && body != _ground && body != _attachedBody)
                    {
                        float height = (float)Math.Round(body.WorldTransform.TranslationVector.Y + _cubeEdgeLength*0.5f);
                        if (maxTowerHeight < height)
                            maxTowerHeight = height;
                    }
                }
            }
        }

        void CreateEmptyWorld()
        {
            _collisionConf = new SoftBodyRigidBodyCollisionConfiguration();
            _dispatcher = new CollisionDispatcher(_collisionConf);

            const int maxProxies = 32766;
            _broadphase = new AxisSweep3(new Vector3(-1000, -1000, -1000),
                                         new Vector3(1000, 1000, 1000), maxProxies);
            _broadphase.OverlappingPairCache.SetInternalGhostPairCallback(new GhostPairCallback());

            _solver = new SequentialImpulseConstraintSolver();

            _softBodyWorldInfo = new SoftBodyWorldInfo
            {
                AirDensity = 1.2f,
                WaterDensity = 0,
                WaterOffset = 0,
                WaterNormal = Vector3.Zero,
                Gravity = new Vector3(0, -10, 0),
                Dispatcher = _dispatcher,
                Broadphase = _broadphase
            };
            _softBodyWorldInfo.SparseSdf.Initialize();
            _softBodyWorldInfo.SparseSdf.Reset();

            _world = new SoftRigidDynamicsWorld(_dispatcher, _broadphase, _solver, _collisionConf);
            _world.Gravity = new Vector3(0, -10, 0);
            _world.DispatchInfo.EnableSpu = true;

            _collisionShapes = new List<CollisionShape>();
        }

        void CleanupWorld()
        {
            _ground = null;
            _groundSensor = null;
            _attachedBody = null;
            _rope = null;

            if (_world == null)
            {
                for (int i = 0; i < _world.NumConstraints; ++i)
                {
                    TypedConstraint constraint = _world.GetConstraint(i);
                    _world.RemoveConstraint(constraint);
                    constraint.Dispose();
                }
    
                for (int i = 0; i < _world.NumCollisionObjects; ++i)
                {
                    CollisionObject obj = _world.CollisionObjectArray[i];
                    RigidBody body = obj as RigidBody;
                    if (body != null && body.MotionState != null)
                    {
                        body.MotionState.Dispose();
                    }
                    _world.RemoveCollisionObject(obj);
                    obj.Dispose();
                }
                _world.Dispose();
            }

            foreach (CollisionShape shape in _collisionShapes)
                shape.Dispose();
            _collisionShapes.Clear();
            _boxCollisionShape = null;

            if (_broadphase != null)
                _broadphase.Dispose();
            if (_dispatcher != null)
                _dispatcher.Dispose();
            if (_collisionConf != null)
                _collisionConf.Dispose();
        }

        void AddSceneToWorld(Vector3 ropeFix, float ropeOffset)
        {
            CollisionShape groundShape = new StaticPlaneShape(new Vector3(0, 1, 0), 0);
            _collisionShapes.Add(groundShape);
            _boxCollisionShape = new BoxShape(_cubeEdgeLength*0.5f, _cubeEdgeLength*0.5f, _cubeEdgeLength*0.5f);
            _collisionShapes.Add(_boxCollisionShape); 
            BoxShape sensorShape = new BoxShape(100, 0.5f, 100);
            _collisionShapes.Add(sensorShape); 

            _groundSensor = new GhostObject();
            _groundSensor.WorldTransform = Matrix.Translation(0, 0, 0);
            _groundSensor.CollisionShape = sensorShape;
            _groundSensor.CollisionFlags |= CollisionFlags.NoContactResponse;
            _world.AddCollisionObject(_groundSensor, CollisionFilterGroups.SensorTrigger, CollisionFilterGroups.AllFilter & ~CollisionFilterGroups.SensorTrigger);

            _ground = CreateRigidBody(0.0f, Matrix.Identity, groundShape);
            _world.AddRigidBody(_ground);


            _softBodyWorldInfo.SparseSdf.RemoveReferences(null);
            Vector3 ropeEnd = ropeFix + Vector3.UnitY*_ropeLength*ropeOffset;
            Vector3 ropeStart = ropeEnd - Vector3.UnitY*_ropeLength;

            _rope = SoftBodyHelpers.CreateRope(_softBodyWorldInfo, ropeStart, ropeEnd, _ropeSegments - 1, 0);
            _rope.Cfg.PIterations = 10;
            _rope.Cfg.DIterations = 10;
            _rope.Cfg.VIterations = 10;
            _rope.Cfg.DP = 0.015f; //increase damping
            _rope.Cfg.DF = 0.9f; //increase friction
            _rope.Cfg.MT = 1.0f; //pose matching
            _rope.Cfg.Collisions = (FCollisions)0;//disable collision between others and itself
            //increase stiffness to reduce elasicity
            foreach (Node node in _rope.Nodes)
            {
                node.Material.Lst = 1.0f;
                node.Material.Ast = 1.0f;
                node.Material.Vst = 1.0f;
            }
            _world.AddSoftBody(_rope);

            _oldRopeFix = Vector3.Zero;
            _oldRopeOffset = -1;

            //important: this is needed to clear the internal flag m_bUpdateRtCst. if this is not done
            //modifications to node positions will change also the link length
            _rope.PredictMotion(0.0f);

            ChangedRopeFixation(ropeFix, ropeOffset);

            _attachedBody = CreateAndAppendBoxToRope(_rope, _boxCollisionShape);
            _world.AddRigidBody(_attachedBody);
            //_attachedBody.ApplyCentralImpulse(new Vector3(-50, 0, 0));

//return;
            const int ArraySizeX = 5, ArraySizeY = 5, ArraySizeZ = 5;
            for (int k = 0; k < ArraySizeY; k++)
            {
                for (int i = 0; i < ArraySizeX; i++)
                {
                    for (int j = 0; j < ArraySizeZ; j++)
                    {
                        Matrix startTransform = Matrix.Translation((i - 5)*_cubeEdgeLength, k*_cubeEdgeLength, (j - 2)*_cubeEdgeLength);
                        RigidBody b = CreateRigidBody(0.5f, startTransform, _boxCollisionShape);
                        b.Translate(new Vector3(0, _cubeEdgeLength*0.5f, 0));
                        _world.AddRigidBody(b);
                    }
                }
            }
        }

        void ChangedRopeFixation(Vector3 ropeFix, float ropeOffset)
        {
            if (_rope == null)
                return;

            if (_oldRopeFix == ropeFix && _oldRopeOffset == ropeOffset)
                return;

            _oldRopeFix = ropeFix;
            _oldRopeOffset = ropeOffset;

            int newFixedRopeNodeIdx = (int)Math.Round((1.0f - ropeOffset)*(_rope.Nodes.Count - 1));
            newFixedRopeNodeIdx = Utilities.Clamp(newFixedRopeNodeIdx, 0, _rope.Nodes.Count - 1);
            Vector3 nodePos = ropeFix + Vector3.UnitY*_ropeLength*ropeOffset;

            //important: avoid use SetMass, because modifications to node positions will then change also the link length
            for (int i = _rope.Nodes.Count - 1; i >= newFixedRopeNodeIdx; --i)
            {
                _rope.Nodes[i].InverseMass = 0;
                _rope.Nodes[i].Force = Vector3.Zero;
                _rope.Nodes[i].Velocity = Vector3.Zero;
                _rope.Nodes[i].Q = Vector3.Zero;
                _rope.Nodes[i].X = nodePos;
                nodePos -= Vector3.UnitY*_ropeLength/_ropeSegments;
            }
            for (int i = newFixedRopeNodeIdx - 1; i >= 0; --i)
            {
                _rope.Nodes[i].InverseMass = 1;
            }
        }
        
        RigidBody CreateAndAppendBoxToRope(SoftBody rope, CollisionShape colShape)
        {
            Link firstLink = rope.Links[0];
            NodePtrArray nodes = firstLink.Nodes;

            Vector3 from = nodes[0].X;
            Vector3 to = nodes[1].X;

            Vector3 yAxis = to - from;
            yAxis.Normalize();
            Vector3 perpDir = Vector3.Cross(Vector3.UnitZ, yAxis);
            perpDir.Normalize();
            Vector3 zAxis = Vector3.Cross(yAxis, perpDir);
            zAxis.Normalize();
            Vector3 xAxis = Vector3.Cross(yAxis, zAxis);
            xAxis.Normalize();

            Matrix transform = Matrix.Identity;
            transform.Up = yAxis;
            transform.Backward = zAxis;
            transform.Right = xAxis;
            transform.TranslationVector = from - yAxis*_cubeEdgeLength*0.5f;

            RigidBody body = CreateRigidBody(2, transform, colShape);
            rope.AppendAnchor(0, body, true);
            rope.AppendAnchor(1, body, true);
            //restrict moving/rotating
            body.LinearFactor = new Vector3(1, 1, 0);
            body.AngularFactor = new Vector3(0, 0, 1);
            Vector3 temp = body.LinearFactor; temp = body.AngularFactor; //strange: without his line we get an access violation
            return body;
        }

        RigidBody CreateRigidBody(float mass, Matrix startTransform, CollisionShape shape)
        {
            //rigidbody is dynamic if and only if mass is non zero, otherwise static
            bool isDynamic = (mass != 0.0f);

            Vector3 localInertia = Vector3.Zero;
            if (isDynamic)
                shape.CalculateLocalInertia(mass, out localInertia);

            //using motionstate is recommended, it provides interpolation capabilities, and only synchronizes 'active' objects
            DefaultMotionState myMotionState = new DefaultMotionState(startTransform);

            RigidBodyConstructionInfo rbInfo = new RigidBodyConstructionInfo(mass, myMotionState, shape, localInertia);
            rbInfo.Friction = 0.9f;
            RigidBody body = new RigidBody(rbInfo);
            rbInfo.Dispose();

            return body;
        }

        const float _cubeEdgeLength = 1.0f;
        const int _ropeSegments = 20;
        const float _ropeLength = 10.0f;

        SoftBodyRigidBodyCollisionConfiguration _collisionConf;
        CollisionDispatcher _dispatcher;
        AxisSweep3 _broadphase;
        SequentialImpulseConstraintSolver _solver;
        SoftBodyWorldInfo _softBodyWorldInfo;
        SoftRigidDynamicsWorld _world;
        List<CollisionShape> _collisionShapes;

        RigidBody _ground;
        GhostObject _groundSensor;
        RigidBody _attachedBody;
        BoxShape _boxCollisionShape;
        SoftBody _rope;
        Vector3 _oldRopeFix = Vector3.Zero;
        float _oldRopeOffset;
        bool _isWorldStable;
        float _maxTowerHeight = -1;

        float _oldResetTrigger;
        float _oldDetachTrigger;
        float _lastTime;
    }

}
