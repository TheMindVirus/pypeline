//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using
using Framefield.Core.OperatorPartTraits;
using Framefield.Core.Rendering;
using Buffer = SharpDX.Direct3D11.Buffer;
using SharpDX.Direct3D;

namespace Framefield.Core.ID4e7433d0_0c65_4344_8b42_87dc2ef48c64
{
    public class Class_SplineDistort5 : FXSourceCodeFunction, IFXSceneSourceCode, IMeshSupplier
    {
        //>>> _inputids
        private enum InputId
        {
            Code = 0,
            Scene = 1,
            Shift = 2,
            SpinPeriod = 3,
            SpinPhase = 4,
            SpinRibbonOffset = 5,
            RibbonShift = 6,
            PeriodAX = 7,
            PeriodAY = 8,
            PeriodAZ = 9,
            AmplitudeAX = 10,
            AmplitudeAY = 11,
            AmplitudeAZ = 12,
            PhaseAX = 13,
            PhaseAY = 14,
            PhaseAZ = 15,
            PeriodBX = 16,
            PeriodBY = 17,
            PeriodBZ = 18,
            AmplitudeBX = 19,
            AmplitudeBY = 20,
            AmplitudeBZ = 21,
            PhaseBX = 22,
            PhaseBY = 23,
            PhaseBZ = 24,
            SinSplitA = 25,
            SinSplitB = 26
        }
        //<<< _inputids

        public Class_SplineDistort5()
        {
            _meshCollector = new MeshCollector(this);
        }

        public override void Dispose() 
        {
            Utilities.DisposeObj(ref _mesh);
            base.Dispose();
        }

        public void AddMeshesTo(ICollection<Mesh> meshes)
        {
            UpdateMesh(new OperatorPartContext(), OperatorPart.Connections);
            if (_mesh != null)
                meshes.Add(_mesh);
        }

        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx)
        {
            try
            {
                UpdateMesh(context, inputs);

                if (_mesh.Vertices != null)
                {
                    // render stream output to screen or whatever target is set
                    context.Renderer.SetupEffect(context);
                    context.Renderer.Render(_mesh, context);
                }
            }
            catch (Exception exception)
            {
                Logger.Error(this, "Load Effect error: {0}", exception.Message);
            }

            return context;
        }

        bool _firstEval = true;
        private void UpdateMesh(OperatorPartContext context, List<OperatorPart> inputs)
        {
            if (_firstEval)
            {
                for (int i = 0; i < NumCodes(); ++i)
                    Compile(i);
                _firstEval = false;
                Changed = true;
            }

            if (!Changed && _mesh.Vertices != null)
                return;

            //>>> _params
            var Code = inputs[(int)InputId.Code].Eval(context).Text;
            var Scene = inputs[(int)InputId.Scene];
            var Shift = inputs[(int)InputId.Shift].Eval(context).Value;
            var SpinPeriod = inputs[(int)InputId.SpinPeriod].Eval(context).Value;
            var SpinPhase = inputs[(int)InputId.SpinPhase].Eval(context).Value;
            var SpinRibbonOffset = inputs[(int)InputId.SpinRibbonOffset].Eval(context).Value;
            var Spin = new Vector3(SpinPeriod, SpinPhase, SpinRibbonOffset);
            var RibbonShift = inputs[(int)InputId.RibbonShift].Eval(context).Value;
            var PeriodAX = inputs[(int)InputId.PeriodAX].Eval(context).Value;
            var PeriodAY = inputs[(int)InputId.PeriodAY].Eval(context).Value;
            var PeriodAZ = inputs[(int)InputId.PeriodAZ].Eval(context).Value;
            var PeriodA = new Vector3(PeriodAX, PeriodAY, PeriodAZ);
            var AmplitudeAX = inputs[(int)InputId.AmplitudeAX].Eval(context).Value;
            var AmplitudeAY = inputs[(int)InputId.AmplitudeAY].Eval(context).Value;
            var AmplitudeAZ = inputs[(int)InputId.AmplitudeAZ].Eval(context).Value;
            var AmplitudeA = new Vector3(AmplitudeAX, AmplitudeAY, AmplitudeAZ);
            var PhaseAX = inputs[(int)InputId.PhaseAX].Eval(context).Value;
            var PhaseAY = inputs[(int)InputId.PhaseAY].Eval(context).Value;
            var PhaseAZ = inputs[(int)InputId.PhaseAZ].Eval(context).Value;
            var PhaseA = new Vector3(PhaseAX, PhaseAY, PhaseAZ);
            var PeriodBX = inputs[(int)InputId.PeriodBX].Eval(context).Value;
            var PeriodBY = inputs[(int)InputId.PeriodBY].Eval(context).Value;
            var PeriodBZ = inputs[(int)InputId.PeriodBZ].Eval(context).Value;
            var PeriodB = new Vector3(PeriodBX, PeriodBY, PeriodBZ);
            var AmplitudeBX = inputs[(int)InputId.AmplitudeBX].Eval(context).Value;
            var AmplitudeBY = inputs[(int)InputId.AmplitudeBY].Eval(context).Value;
            var AmplitudeBZ = inputs[(int)InputId.AmplitudeBZ].Eval(context).Value;
            var AmplitudeB = new Vector3(AmplitudeBX, AmplitudeBY, AmplitudeBZ);
            var PhaseBX = inputs[(int)InputId.PhaseBX].Eval(context).Value;
            var PhaseBY = inputs[(int)InputId.PhaseBY].Eval(context).Value;
            var PhaseBZ = inputs[(int)InputId.PhaseBZ].Eval(context).Value;
            var PhaseB = new Vector3(PhaseBX, PhaseBY, PhaseBZ);
            var SinSplitA = inputs[(int)InputId.SinSplitA].Eval(context).Value;
            var SinSplitB = inputs[(int)InputId.SinSplitB].Eval(context).Value;
            var SinSplit = new Vector2(SinSplitA, SinSplitB);
            //<<< _params

            if (Scene.Func.Changed || _mesh.Vertices == null)
            {
                //Logger.Info(this, "collect meshes");
                _meshCollector.Collect(Scene);
                Scene.Func.Changed = false;
            }

            var inputMesh = _meshCollector.FirstMeshOrDefault;
            if (inputMesh == null)
                return;

            _mesh.AttributesSize = inputMesh.AttributesSize;
            _mesh.NumTriangles = inputMesh.NumTriangles;
            _mesh.InputElements = inputMesh.InputElements;
            if (_mesh.Vertices == null || _mesh.Vertices.Description.SizeInBytes != inputMesh.Vertices.Description.SizeInBytes)
            {
                if (_mesh.Vertices != null)
                    _mesh.Vertices.Dispose();

                _mesh.Vertices = new Buffer(D3DDevice.Device, new BufferDescription()
                                                                    {
                                                                        BindFlags = BindFlags.StreamOutput | BindFlags.VertexBuffer,
                                                                        CpuAccessFlags = CpuAccessFlags.None,
                                                                        OptionFlags = ResourceOptionFlags.None,
                                                                        SizeInBytes = _mesh.NumTriangles*inputMesh.AttributesSize*3,
                                                                        Usage = ResourceUsage.Default
                                                                    });
            }
            //var noiseTextureView = new ShaderResourceView(context.D3DDevice, RGBANoise);
            //_effect.GetVariableByName("RGBANoise").AsShaderResource().SetResource(noiseTextureView);
            _usedViewport= context.Viewport;
            
            //>>> _setup
            {
                _effect.GetVariableByName("RenderTargetSize").AsVector().Set(new Vector2(_usedViewport.Width, _usedViewport.Height));
                _effect.GetVariableByName("Shift").AsScalar().Set(Shift);
                _effect.GetVariableByName("Spin").AsVector().Set(new Vector3(SpinPeriod, SpinPhase, SpinRibbonOffset));
                _effect.GetVariableByName("RibbonShift").AsScalar().Set(RibbonShift);
                _effect.GetVariableByName("PeriodA").AsVector().Set(new Vector3(PeriodAX, PeriodAY, PeriodAZ));
                _effect.GetVariableByName("AmplitudeA").AsVector().Set(new Vector3(AmplitudeAX, AmplitudeAY, AmplitudeAZ));
                _effect.GetVariableByName("PhaseA").AsVector().Set(new Vector3(PhaseAX, PhaseAY, PhaseAZ));
                _effect.GetVariableByName("PeriodB").AsVector().Set(new Vector3(PeriodBX, PeriodBY, PeriodBZ));
                _effect.GetVariableByName("AmplitudeB").AsVector().Set(new Vector3(AmplitudeBX, AmplitudeBY, AmplitudeBZ));
                _effect.GetVariableByName("PhaseB").AsVector().Set(new Vector3(PhaseBX, PhaseBY, PhaseBZ));
                _effect.GetVariableByName("SinSplit").AsVector().Set(new Vector2(SinSplitA, SinSplitB));
            //<<< _setup
            }

            context.D3DDevice.ImmediateContext.StreamOutput.SetTargets(new [] { new StreamOutputBufferBinding(_mesh.Vertices, 0) });
            context.D3DDevice.ImmediateContext.OutputMerger.DepthStencilState = new DepthStencilState(context.D3DDevice,
                                                                                                        new DepthStencilStateDescription()
                                                                                                            {
                                                                                                                IsDepthEnabled = false,
                                                                                                                IsStencilEnabled = false
                                                                                                            });
            context.D3DDevice.ImmediateContext.InputAssembler.InputLayout = context.InputLayout;
            context.D3DDevice.ImmediateContext.InputAssembler.PrimitiveTopology = PrimitiveTopology.TriangleList;
            context.D3DDevice.ImmediateContext.InputAssembler.SetVertexBuffers(0, new VertexBufferBinding(inputMesh.Vertices, inputMesh.AttributesSize, 0));
            var technique = _effect.GetTechniqueByIndex(0);
            technique.GetPassByIndex(0).Apply(context.D3DDevice.ImmediateContext);
            context.D3DDevice.ImmediateContext.Draw(_mesh.NumTriangles*3, 0);
            context.D3DDevice.ImmediateContext.StreamOutput.SetTargets(new [] { new StreamOutputBufferBinding(null, 0) });

            Changed = false;
        }
        
        private SharpDX.ViewportF _usedViewport;

        private Mesh _mesh = new Mesh();
        private MeshCollector _meshCollector;
    }
}


