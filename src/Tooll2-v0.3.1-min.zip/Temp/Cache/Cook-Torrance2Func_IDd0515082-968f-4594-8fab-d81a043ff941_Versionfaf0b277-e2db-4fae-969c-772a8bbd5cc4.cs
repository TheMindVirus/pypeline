//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using
using Framefield.Core.Rendering;

namespace Framefield.Core.IDd0515082_968f_4594_8fab_d81a043ff941
{
    public class Class_Cook_Torrance2 : FXSourceCodeFunction
    {
        //>>> _inputids
        private enum InputId
        {
            Code = 0,
            Scene = 1,
            Roughness = 2,
            Metallic = 3,
            CubeMap = 4,
            F0R = 5,
            F0G = 6,
            F0B = 7,
            F0A = 8,
            AlbedoR = 9,
            AlbedoG = 10,
            AlbedoB = 11,
            AlbedoA = 12
        }
        //<<< _inputids

        #region Renderer
        public class Renderer : BaseRenderer
        {
            public override void SetupEffect(OperatorPartContext context)
            {
                base.SetupEffect(context);
                try
                {
                    SetupMaterialConstBuffer(context);
                    SetupFogSettingsConstBuffer(context);
                    SetupPointLightsConstBuffer(context);
                    var roughnessVariable = context.Effect.GetVariableByName("Roughness").AsScalar();
                    if (roughnessVariable != null)
                    {
                        roughnessVariable.Set(Roughness);
                    }

                    var metallicVariable = context.Effect.GetVariableByName("Metallic").AsScalar();
                    if (metallicVariable != null)
                    {
                        metallicVariable.Set(Metallic);
                    }

                    var f0Variable = context.Effect.GetVariableByName("F0_").AsVector();
                    if (f0Variable != null)
                    {
                        f0Variable.Set(F0);
                    }
                    var albedoVariable = context.Effect.GetVariableByName("Albedo").AsVector();
                    if (albedoVariable != null)
                    {
                        albedoVariable.Set(Albedo);
                    }
                    using (var CubeMapView = new ShaderResourceView(context.D3DDevice, CubeMap))
                    {
                        var cubeMapVariable = context.Effect.GetVariableByName("CubeMap").AsShaderResource();
                        if (cubeMapVariable != null)
                        {
                            cubeMapVariable.SetResource(CubeMapView);
                        }
                    }
                    using (var AlbedoView = new ShaderResourceView(context.D3DDevice, Albedo2))
                    {
                        var albedo2Variable = context.Effect.GetVariableByName("Albedo2").AsShaderResource();
                        if (albedo2Variable != null)
                        {
                            albedo2Variable.SetResource(AlbedoView);
                        }
                    }
                    using (var roughnessView = new ShaderResourceView(context.D3DDevice, Roughness2))
                    {
                        var roughness2Variable = context.Effect.GetVariableByName("Roughness2").AsShaderResource();
                        if (roughness2Variable != null)
                        {
                            roughness2Variable.SetResource(roughnessView);
                        }
                    }
                    using (var metalView = new ShaderResourceView(context.D3DDevice, Metal))
                    {
                        var metalVariable = context.Effect.GetVariableByName("Metal").AsShaderResource();
                        if (metalVariable != null)
                        {
                            metalVariable.SetResource(metalView);
                        }
                    }
                    using (var normalMapView = new ShaderResourceView(context.D3DDevice, NormalMap))
                    {
                        var normalMapVariable = context.Effect.GetVariableByName("NormalMap").AsShaderResource();
                        if (normalMapVariable != null)
                        {
                            normalMapVariable.SetResource(normalMapView);
                        }
                    }
                    using (var AOView = new ShaderResourceView(context.D3DDevice, AO))
                    {
                        var AOVariable = context.Effect.GetVariableByName("AO").AsShaderResource();
                        if (AOVariable != null)
                        {
                            AOVariable.SetResource(AOView);
                        }
                    }
                }
                catch (Exception e)
                {
                    Logger.Error(ParentFunc, "Error building constant buffer: {0} - Source: {1}", e.Message, e.Source);
                }
            }
            public OperatorPart.Function ParentFunc {get;set;}
            public float Roughness { get; set; }
            public float Metallic { get; set; }
            public Vector3 F0 { get; set; }
            public Vector3 Albedo { get; set; }
            public Texture2D CubeMap { get; set; }
            public Texture2D Albedo2 { get; set; }
            public Texture2D Roughness2 { get; set; }
            public Texture2D Metal { get; set; }
            public Texture2D NormalMap { get; set; }
            public Texture2D AO { get; set; }
        }
        #endregion

        public Class_Cook_Torrance2()
        {
            _renderer = new Renderer(){ParentFunc = this};
        }

        public override void Dispose()
        {
            Utilities.DisposeObj(ref _renderer);
            base.Dispose();
        }

        bool _firstEval = true;
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx)
        {
            //>>> _params
            var Code = inputs[(int)InputId.Code].Eval(context).Text;
            var Scene = inputs[(int)InputId.Scene];
            var Roughness = inputs[(int)InputId.Roughness].Eval(context).Value;
            var Metallic = inputs[(int)InputId.Metallic].Eval(context).Value;
            var CubeMap = inputs[(int)InputId.CubeMap].Eval(context).Image; // Needs to be checked for null!
            var F0R = inputs[(int)InputId.F0R].Eval(context).Value;
            var F0G = inputs[(int)InputId.F0G].Eval(context).Value;
            var F0B = inputs[(int)InputId.F0B].Eval(context).Value;
            var F0A = inputs[(int)InputId.F0A].Eval(context).Value;
            var F0 = new Color4(F0R, F0G, F0B, F0A);
            var AlbedoR = inputs[(int)InputId.AlbedoR].Eval(context).Value;
            var AlbedoG = inputs[(int)InputId.AlbedoG].Eval(context).Value;
            var AlbedoB = inputs[(int)InputId.AlbedoB].Eval(context).Value;
            var AlbedoA = inputs[(int)InputId.AlbedoA].Eval(context).Value;
            var Albedo = new Color4(AlbedoR, AlbedoG, AlbedoB, AlbedoA);
            //<<< _params

            IPbrMaterial material = context.Objects[OperatorPartContext.PBR_MATERIAL_ID] as IPbrMaterial;

            _renderer.Roughness = (float)Roughness;
            _renderer.F0 = new Vector3(F0R, F0G, F0B);
            _renderer.Albedo = new Vector3(AlbedoR, AlbedoG, AlbedoB);
            _renderer.Metallic = Metallic;//1.0f;//material.Metal;// Metallic;
            //Logger.Info("F0: {0}", _renderer.F0);
            _renderer.CubeMap = CubeMap;
            _renderer.Albedo2 = material.Albedo;
            _renderer.Roughness2 = material.Roughness;
            _renderer.Metal = material.Metal;
            _renderer.NormalMap = material.NormalMap;
            _renderer.AO = material.AO;
            
            if (_firstEval)
            {
                for (int i = 0; i < NumCodes(); ++i)
                    Compile(i);
                _firstEval = false;
                Changed = true;
            }

            var prevEffect = context.Effect;
            var prevRenderer = context.Renderer;

            context.Effect = _effect;
            context.Renderer = _renderer;

            Scene.Eval(context);

            context.Effect = prevEffect;
            context.Renderer = prevRenderer;            

            return context;
        }

        Renderer _renderer;
    }
}


