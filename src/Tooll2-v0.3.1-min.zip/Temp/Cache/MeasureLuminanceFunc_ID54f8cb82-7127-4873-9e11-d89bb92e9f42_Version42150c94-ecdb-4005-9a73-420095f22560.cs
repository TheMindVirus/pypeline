//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using
using Framefield.Core.Rendering;
using SharpDX.DXGI;
using SharpDX.D3DCompiler;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Buffer = SharpDX.Direct3D11.Buffer;
using MapFlags = SharpDX.Direct3D11.MapFlags;

namespace Framefield.Core.ID54f8cb82_7127_4873_9e11_d89bb92e9f42
{
    public class Class_MeasureLuminance : FXSourceCodeFunction
    {
        //structured buffer element type. size must be 16 byte aligned
        [StructLayout(LayoutKind.Explicit, Size = 16)]
        public struct ParameterConstBufferLayout
        {
            public ParameterConstBufferLayout(Int4 param)
            {
                Param = param;
            }
            [FieldOffset(0)]
            Int4 Param;
        }

        //>>> _inputids
        private enum InputId
        {
            Code = 0,
            ReduceToSingleCode = 1,
            Image = 2
        }
        //<<< _inputids

        public override void Dispose()
        {
//            Utilities.DisposeObj(ref _visuTexture);
//            Utilities.DisposeObj(ref _csVisu);
            base.Dispose();
        }

        public override int NumCodes()
        {
            return 2;
        }


        protected void SetupConstBuffer<TBufferLayout>(SharpDX.Direct3D11.Device d3dDevice, TBufferLayout parameterData, ref Buffer _constantBuffer) where TBufferLayout : struct
        {
            using (var data = new DataStream(Marshal.SizeOf(typeof(TBufferLayout)), true, true))
            {
                data.Write(parameterData);
                data.Position = 0;

                if (_constantBuffer == null)
                {
                    var bufferDesc = new BufferDescription
                                         {
                                             Usage = ResourceUsage.Default,
                                             SizeInBytes = Marshal.SizeOf(typeof(TBufferLayout)),
                                             BindFlags = BindFlags.ConstantBuffer
                                         };
                    _constantBuffer = new Buffer(d3dDevice, data, bufferDesc);
                }
                else
                {
                    d3dDevice.ImmediateContext.UpdateSubresource(new DataBox(data.DataPointer, 0, 0), _constantBuffer);
                }
            }
        }

        protected bool BuildRenderTarget(OperatorPartContext context, Texture2D inputImage)
        {
            // ReduceTo1DCS has threadgroup size of 8x8 threads
            _reduceTo1D = new Size2((int) Math.Ceiling(inputImage.Description.Width/8.0f),
                                    (int) Math.Ceiling(inputImage.Description.Height/8.0f));

            var reductionBufferDesc = new BufferDescription
                                          {
                                              BindFlags = BindFlags.ShaderResource | BindFlags.UnorderedAccess,
                                              CpuAccessFlags = CpuAccessFlags.None,
                                              OptionFlags = ResourceOptionFlags.BufferStructured,
                                              SizeInBytes = _reduceTo1D.Width*_reduceTo1D.Height*sizeof(float)*2,
                                              StructureByteStride = sizeof(float)*2,
                                              Usage = ResourceUsage.Default,
                                          };
            Utilities.DisposeObj(ref _reductionBuffer0);
            Utilities.DisposeObj(ref _reductionBuffer1);
            _reductionBuffer0 = new Buffer(context.D3DDevice, reductionBufferDesc);
            _reductionBuffer1 = new Buffer(context.D3DDevice, reductionBufferDesc);

            Utilities.DisposeObj(ref _reductionBuffer0UAV);
            Utilities.DisposeObj(ref _reductionBuffer1UAV);
            _reductionBuffer0UAV = new UnorderedAccessView(context.D3DDevice, _reductionBuffer0);
            _reductionBuffer1UAV = new UnorderedAccessView(context.D3DDevice, _reductionBuffer1);

            Utilities.DisposeObj(ref _reductionBuffer0SRV);
            Utilities.DisposeObj(ref _reductionBuffer1SRV);
            _reductionBuffer0SRV = new ShaderResourceView(context.D3DDevice, _reductionBuffer0);
            _reductionBuffer1SRV = new ShaderResourceView(context.D3DDevice, _reductionBuffer1);

            Utilities.DisposeObj(ref _cpuReadBuffer);
            var cpuReadBufferDesc = reductionBufferDesc;
            cpuReadBufferDesc.CpuAccessFlags = CpuAccessFlags.Read;
            cpuReadBufferDesc.Usage = ResourceUsage.Staging;
            cpuReadBufferDesc.BindFlags = BindFlags.None;
            cpuReadBufferDesc.OptionFlags = ResourceOptionFlags.None;
            _cpuReadBuffer = new Buffer(context.D3DDevice, cpuReadBufferDesc);

//
//            if (_histoTexture != null)
//            {
//                return false;
//            }
//
//            var uavHistoDesc = new Texture2DDescription
//                                  {
//                                      BindFlags = BindFlags.ShaderResource | BindFlags.UnorderedAccess,
//                                      Format = Format.R32_SInt,
//                                      Width = 256,
//                                      Height = 4,
//                                      MipLevels = 1,
//                                      SampleDescription = new SampleDescription(1, 0),
//                                      Usage = ResourceUsage.Default,
//                                      OptionFlags = ResourceOptionFlags.None,
//                                      CpuAccessFlags = CpuAccessFlags.None,
//                                      ArraySize = 1
//                                  };
//            Utilities.DisposeObj(ref _histoTexture);
//            _histoTexture = new Texture2D(context.D3DDevice, uavHistoDesc);
//
//            var uavVisuDesc = new Texture2DDescription
//                                  {
//                                      BindFlags = BindFlags.ShaderResource | BindFlags.UnorderedAccess,
//                                      Format = Format.R8G8B8A8_UNorm,
//                                      Width = inputImage.Description.Width,
//                                      Height = inputImage.Description.Height,
//                                      MipLevels = 1,
//                                      SampleDescription = new SampleDescription(1, 0),
//                                      Usage = ResourceUsage.Default,
//                                      OptionFlags = ResourceOptionFlags.None,
//                                      CpuAccessFlags = CpuAccessFlags.None,
//                                      ArraySize = 1
//                                  };
//            Utilities.DisposeObj(ref _visuTexture);
//            _visuTexture = new Texture2D(context.D3DDevice, uavVisuDesc);

            return true;
        }

        private void DoMeasureLuminance(OperatorPartContext context, Texture2D image)
        {
            // First CS pass, reduce the render target texture into a 1D buffer
            SetupConstBuffer(context.D3DDevice, new ParameterConstBufferLayout(new Int4(_reduceTo1D.Width, _reduceTo1D.Height, image.Description.Width, image.Description.Height)), ref _parameterConstBuffer);
            var deviceContext = context.D3DDevice.ImmediateContext;
            using (var imageView = new ShaderResourceView(context.D3DDevice, image))
            {
                deviceContext.ComputeShader.Set(_reduceTo1dCS);
                deviceContext.ComputeShader.SetUnorderedAccessView(0, _reductionBuffer0UAV);
                deviceContext.ComputeShader.SetShaderResource(0, imageView);
                deviceContext.ComputeShader.SetConstantBuffer(0, _parameterConstBuffer);
                deviceContext.Dispatch(_reduceTo1D.Width, _reduceTo1D.Height, 1);
                deviceContext.ComputeShader.SetUnorderedAccessView(0, null);
                deviceContext.ComputeShader.SetShaderResource(0, null);
            }

//        // Turn on this and set a breakpoint right after the call to Map to see what's written to g_pBufferReduction0
#if DEBUG_TRANSFER_TO_CPU
//        ID3D11Buffer* pDebugBuf = CreateAndCopyToDebugBuf( DXUTGetD3D11Device(), pd3dImmediateContext, g_pBufferReduction0 );
//        D3D11_MAPPED_SUBRESOURCE MappedResource;     
//        V( pd3dImmediateContext->Map( pDebugBuf, 0, D3D11_MAP_READ, 0, &MappedResource ) );
//        pd3dImmediateContext->Unmap( pDebugBuf, 0 );
//        SAFE_RELEASE( pDebugBuf );        
#endif

            // Reduce 1d to 1 value
            int sizeToReduce = _reduceTo1D.Width*_reduceTo1D.Height;
            int dispatchSize = (int)Math.Ceiling(sizeToReduce/128.0f);
            if (sizeToReduce > 1)
            {
                while (true)
                {
                    SetupConstBuffer(context.D3DDevice, new ParameterConstBufferLayout(new Int4(sizeToReduce, dispatchSize, 0, 0)), ref _parameterConstBuffer);
                    deviceContext.ComputeShader.Set(_reduceToValueCS);
                    deviceContext.ComputeShader.SetUnorderedAccessView(0, _reductionBuffer1UAV);
                    deviceContext.ComputeShader.SetShaderResource(0, _reductionBuffer0SRV);
                    deviceContext.ComputeShader.SetConstantBuffer(0, _parameterConstBuffer);
                    deviceContext.Dispatch(dispatchSize, 1, 1);
                    deviceContext.ComputeShader.SetUnorderedAccessView(0, null);
                    deviceContext.ComputeShader.SetShaderResource(0, null);

                    sizeToReduce = dispatchSize;
                    dispatchSize = (int)Math.Ceiling(dispatchSize/128.0f);

                    if (sizeToReduce == 1)
                        break;

                    Utilities.Swap(ref _reductionBuffer0, ref _reductionBuffer1);
                    Utilities.Swap(ref _reductionBuffer0UAV, ref _reductionBuffer1UAV);
                    Utilities.Swap(ref _reductionBuffer0SRV, ref _reductionBuffer1SRV);
                }
            }
            else
            {
                Utilities.Swap(ref _reductionBuffer0, ref _reductionBuffer1);
                Utilities.Swap(ref _reductionBuffer0UAV, ref _reductionBuffer1UAV);
                Utilities.Swap(ref _reductionBuffer0SRV, ref _reductionBuffer1SRV);
            }

//     pd3dImmediateContext->CopyResource( m_pGPUtoCPUBuf, m_pBufferReduction1 );
//     D3D11_MAPPED_SUBRESOURCE MappedResource;     
//     V( pd3dImmediateContext->Map( m_pGPUtoCPUBuf, 0, D3D11_MAP_READ, 0, &MappedResource ) );
//     float* data  = reinterpret_cast< float* >( MappedResource.pData );
//     m_fLogAvgLum = exp( ( data[ 0 ] / (nWidth*nHeight) ) );
//     m_fLumMax = data[ 1 ];
//     pd3dImmediateContext->Unmap( m_pGPUtoCPUBuf, 0 );

            deviceContext.CopyResource(_reductionBuffer0, _cpuReadBuffer);

            DataStream stream;
            deviceContext.MapSubresource(_cpuReadBuffer, MapMode.Read, MapFlags.None, out stream);
            var lnAverageLuminance = Math.Exp(stream.ReadFloat()/(image.Description.Width*image.Description.Height));
            var maxLuminance = stream.ReadFloat();
            deviceContext.UnmapSubresource(_cpuReadBuffer, 0);
            stream.Dispose();

            Logger.Info("MeasureLuminance - avg lum: {0}, max lum: {1}", lnAverageLuminance, maxLuminance);

            // Turn on this and set a breakpoint right after the call to Map to see what is in g_pBufferReduction1 and g_pBufferReduction0
//#if 0
//    ID3D11Buffer* pDebugBuf = CreateAndCopyToDebugBuf( DXUTGetD3D11Device(), pd3dImmediateContext, g_pBufferReduction1 );
//    D3D11_MAPPED_SUBRESOURCE MappedResource;     
//    V( pd3dImmediateContext->Map( pDebugBuf, 0, D3D11_MAP_READ, 0, &MappedResource ) );
//    pd3dImmediateContext->Unmap( pDebugBuf, 0 );
//    SAFE_RELEASE( pDebugBuf );
//
//    pDebugBuf = CreateAndCopyToDebugBuf( DXUTGetD3D11Device(), pd3dImmediateContext, g_pBufferReduction0 );    
//    V( pd3dImmediateContext->Map( pDebugBuf, 0, D3D11_MAP_READ, 0, &MappedResource ) );
//    pd3dImmediateContext->Unmap( pDebugBuf, 0 );
//    SAFE_RELEASE( pDebugBuf );
//#endif

        }

        private Stopwatch _stopwatch = new Stopwatch();

        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx)
        {
            //>>> _params
            var Code = inputs[(int)InputId.Code].Eval(context).Text;
            var ReduceToSingleCode = inputs[(int)InputId.ReduceToSingleCode].Eval(context).Text;
            var Image = inputs[(int)InputId.Image].Eval(context).Image; // Needs to be checked for null!
            //<<< _params

            if (_reduceTo1dCS == null)
            {
                Utilities.DisposeObj(ref _reduceTo1dCS);
                Utilities.DisposeObj(ref _reduceToValueCS);
//                Utilities.DisposeObj(ref _csVisu);
                var errors = new CompilerErrorCollection();
                try
                {
                    using (var bytecode = ShaderBytecode.Compile(GetCode(0), "CSReductTo1d", "cs_5_0", ShaderFlags.Debug))
                        _reduceTo1dCS = new ComputeShader(D3DDevice.Device, bytecode);
                    using (var bytecode = ShaderBytecode.Compile(GetCode(1), "CSReduceToSingle", "cs_5_0", ShaderFlags.Debug))
                        _reduceToValueCS = new ComputeShader(D3DDevice.Device, bytecode);
//                    using (var bytecode = ShaderBytecode.Compile(GetCode(2), "fx_5_0", ShaderFlags.Debug, EffectFlags.None, null, null))
//                        _effect = new Effect(D3DDevice.Device, bytecode);
                }
                catch (CompilationException ex)
                {
                    errors = ErrorsFromString(ex.Message);
                    Logger.Error(this, "Fx compile error: {0}", ex.Message);
                }
            }

            BuildRenderTarget(context, Image);

            //_effect.GetVariableByName("RenderTargetSize").AsVector().Set(new Vector2(_usedViewport.Width, _usedViewport.Height));
            _stopwatch.Restart();

            DoMeasureLuminance(context, Image);

//            using (var imageView = new ShaderResourceView(context.D3DDevice, _histoTexture))
//            using (var uav = new UnorderedAccessView(context.D3DDevice, _visuTexture))
//            {
//                deviceContext.ComputeShader.Set(_csVisu);
//                deviceContext.ComputeShader.SetUnorderedAccessView(1, uav);
//                deviceContext.ComputeShader.SetShaderResource(1, imageView);
//                deviceContext.Dispatch(32, 32, 1);
//            }

            _stopwatch.Stop();
            Logger.Info(this, "measure luminence took: {0}ms", _stopwatch.ElapsedMilliseconds);

//            context.Image = _visuTexture;

            return context;
        }

//        private Texture2D _histoTexture;
//        private Texture2D _visuTexture;

//        private ComputeShader _csHistoClear;
//        private ComputeShader _csHisto;
//        private ComputeShader _csVisu;

        private ComputeShader _reduceTo1dCS;
        private ComputeShader _reduceToValueCS;

        private Size2 _reduceTo1D;
        private Buffer _reductionBuffer0;
        private Buffer _reductionBuffer1;
        private UnorderedAccessView _reductionBuffer0UAV;
        private UnorderedAccessView _reductionBuffer1UAV;
        private ShaderResourceView _reductionBuffer0SRV;
        private ShaderResourceView _reductionBuffer1SRV;
        private Buffer _cpuReadBuffer;
        private Buffer _parameterConstBuffer;
    }
}