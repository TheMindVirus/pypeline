//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using

namespace Framefield.Core.ID70ea664b_8c6a_442b_908f_684ea3f1dc95
{
    public class Class_ColorGradePostSat : FXImageFunction
    {
        //>>> _inputids
        private enum InputId
        {
            Code = 0,
            Image = 1,
            GainR = 2,
            GainG = 3,
            GainB = 4,
            GainA = 5,
            GammaR = 6,
            GammaG = 7,
            GammaB = 8,
            GammaA = 9,
            LiftR = 10,
            LiftG = 11,
            LiftB = 12,
            LiftA = 13,
            PreSaturate = 14,
            PostSaturate = 15
        }
        //<<< _inputids

        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx)
        {
            return PrepareAndEvalOnChange(context, () =>
            {
                //>>> _params
                var Code = inputs[(int)InputId.Code].Eval(context).Text;
                var Image = inputs[(int)InputId.Image].Eval(context).Image; // Needs to be checked for null!
                var GainR = inputs[(int)InputId.GainR].Eval(context).Value;
                var GainG = inputs[(int)InputId.GainG].Eval(context).Value;
                var GainB = inputs[(int)InputId.GainB].Eval(context).Value;
                var GainA = inputs[(int)InputId.GainA].Eval(context).Value;
                var Gain = new Color4(GainR, GainG, GainB, GainA);
                var GammaR = inputs[(int)InputId.GammaR].Eval(context).Value;
                var GammaG = inputs[(int)InputId.GammaG].Eval(context).Value;
                var GammaB = inputs[(int)InputId.GammaB].Eval(context).Value;
                var GammaA = inputs[(int)InputId.GammaA].Eval(context).Value;
                var Gamma = new Color4(GammaR, GammaG, GammaB, GammaA);
                var LiftR = inputs[(int)InputId.LiftR].Eval(context).Value;
                var LiftG = inputs[(int)InputId.LiftG].Eval(context).Value;
                var LiftB = inputs[(int)InputId.LiftB].Eval(context).Value;
                var LiftA = inputs[(int)InputId.LiftA].Eval(context).Value;
                var Lift = new Color4(LiftR, LiftG, LiftB, LiftA);
                var PreSaturate = inputs[(int)InputId.PreSaturate].Eval(context).Value;
                var PostSaturate = inputs[(int)InputId.PostSaturate].Eval(context).Value;
                //<<< _params
                
                if (Image == null)
                    return;

                ClearRenderTarget(context, new SharpDX.Color4(0, 0, 0, 1));

                //>>> _setup
                using (var ImageView = new ShaderResourceView(context.D3DDevice, Image))
                {
                    _effect.GetVariableByName("RenderTargetSize").AsVector().Set(new Vector2(_usedViewport.Width, _usedViewport.Height));
                    _effect.GetVariableByName("Image").AsShaderResource().SetResource(ImageView);
                    _effect.GetVariableByName("Gain").AsVector().Set(new Vector4(GainR, GainG, GainB, GainA));
                    _effect.GetVariableByName("Gamma").AsVector().Set(new Vector4(GammaR, GammaG, GammaB, GammaA));
                    _effect.GetVariableByName("Lift").AsVector().Set(new Vector4(LiftR, LiftG, LiftB, LiftA));
                    _effect.GetVariableByName("PreSaturate").AsScalar().Set(PreSaturate);
                    _effect.GetVariableByName("PostSaturate").AsScalar().Set(PostSaturate);
                //<<< _setup

                var prevBlendState = context.BlendState;
                context.BlendState = OperatorPartContext.DefaultRenderer.DisabledBlendState;

                Render(context);

                context.BlendState = prevBlendState;

                //>>> _cleanup
                }
                //<<< _cleanup
            });
        }

    }
}
