//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using
using System.IO;

namespace Framefield.Core.ID1d789077_459a_4f61_9671_aada9264458a
{
    public class Class_LoadVolume : OperatorPart.Function
    {
        //>>> _inputids
        private enum InputId
        {
            ImagePath = 0
        }
        //<<< _inputids

        //>>> _outputids
        private enum OutputId
        {
            Image = 0
        }
        //<<< _outputids

        public override void Dispose()
        {
            Utilities.DisposeObj(ref _volume);
        }

        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) 
        {
            //>>> _params
            var ImagePath = inputs[(int)InputId.ImagePath].Eval(context).Text;
            //<<< _params

            if (ImagePath == _lastImage)
                Changed = false;

            _lastImage = ImagePath;

            if (Changed)
            {
                Dispose();
                if (File.Exists(ImagePath))
                {
                    _volume = SharpDX.Direct3D11.Resource.FromFile<Texture3D>(D3DDevice.Device, ImagePath);
                }
                else
                {
                    Logger.Error(this,"Imagefile not found '{0}'", ImagePath);
                }

                Changed = false;
            }

            if (_volume != null)
            {
                context.Volume = _volume;
            }

            return context;
        }

        Texture3D _volume;
        String _lastImage = String.Empty;
    }
}

