//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using
using SharpDX.Direct3D;
using SharpDX.DXGI;

namespace Framefield.Core.IDc74cf329_3707_4f66_b789_fecd156ebb6b
{
    public class Class_SSAOHemiSphere : FXImageFunction
    {
        //>>> _inputids
        private enum InputId
        {
            Code = 0,
            DepthImage = 1,
            Passes = 2,
            KernelSize = 3,
            Seed = 4,
            DepthClip = 5,
            NoiseImage = 6,
            Normals = 7
        }
        //<<< _inputids

        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            //>>> _params
            var Code = inputs[(int)InputId.Code].Eval(context).Text;
            var DepthImage = inputs[(int)InputId.DepthImage].Eval(context).Image; // Needs to be checked for null!
            var Passes = inputs[(int)InputId.Passes].Eval(context).Value;
            var KernelSize = inputs[(int)InputId.KernelSize].Eval(context).Value;
            var Seed = inputs[(int)InputId.Seed].Eval(context).Value;
            var DepthClip = inputs[(int)InputId.DepthClip].Eval(context).Value;
            var NoiseImage = inputs[(int)InputId.NoiseImage].Eval(context).Image; // Needs to be checked for null!
            var Normals = inputs[(int)InputId.Normals].Eval(context).Image; // Needs to be checked for null!
            //<<< _params

            return PrepareAndEvalOnChange(context, () => {
                ClearRenderTarget(context, new SharpDX.Color4(0, 0, 0, 1));

                var shaderDesc = new ShaderResourceViewDescription();
                shaderDesc.Format = Format.R32_Float;
                shaderDesc.Dimension = ShaderResourceViewDimension.Texture2D;
                shaderDesc.Texture2D.MipLevels = 1;
                using (var depthTexture = new ShaderResourceView(context.D3DDevice, DepthImage, shaderDesc))
                {
                    _effect.GetVariableByName("txDepth").AsShaderResource().SetResource(depthTexture); 

                    //>>> __setup
                    using (var NoiseImageView = new ShaderResourceView(context.D3DDevice, NoiseImage))
                    using (var NormalsView = new ShaderResourceView(context.D3DDevice, Normals))
                    {
                        _effect.GetVariableByName("RenderTargetSize").AsVector().Set(new Vector2(_usedViewport.Width, _usedViewport.Height));
                        _effect.GetVariableByName("Passes").AsScalar().Set(Passes);
                        _effect.GetVariableByName("KernelSize").AsScalar().Set(KernelSize);
                        _effect.GetVariableByName("Seed").AsScalar().Set(Seed);
                        _effect.GetVariableByName("DepthClip").AsScalar().Set(DepthClip);
                        _effect.GetVariableByName("NoiseImage").AsShaderResource().SetResource(NoiseImageView);
                        _effect.GetVariableByName("Normals").AsShaderResource().SetResource(NormalsView);
                    //<<< _setup

                    Render(context);

                    //>>> _cleanup
                    }
                    //<<< _cleanup
                }
            });
        }

    }
}

