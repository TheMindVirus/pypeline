using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;

namespace Framefield.Core.ID7d6cd829_8124_47da_aff4_560c161f766b
{
    public class Class_Multiply_Values : OperatorPart.Function
    {
        //>>> _inputids
        private enum InputId
        {
            Values = 0
        }
        //<<< _inputids
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) 
        {
            //>>> _params
            var Values = inputs[(int)InputId.Values].Eval(context).Value;
            //<<< _params
            
            float value = 1.0f;
            foreach (var input in inputs[0].Connections) {
                value *= input.Eval(context).Value;
            }
            context.Value = value;
            return context;
        }
    }
}

