//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using

namespace Framefield.Core.IDe05f9a6a_e4fe_4fe0_a034_f6f88c7b7c4d
{
    public class Class_Add : OperatorPart.Function
    {
        //>>> _inputids
        private enum InputId
        {
            Value1 = 0,
            Value2 = 1
        }
        //<<< _inputids
        
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) 
        {
            if (Changed)
            {
                //>>> _params
                var Value1 = inputs[(int)InputId.Value1].Eval(context).Value;
                var Value2 = inputs[(int)InputId.Value2].Eval(context).Value;
                //<<< _params
                _sum = Value1 + Value2;
                Changed = false;
            }
            
            context.Value = _sum;
            return context;
        }
        float _sum;
    }
}

