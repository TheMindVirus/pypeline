//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using

using System.Runtime.InteropServices;
using Framefield.Core.Rendering;
using SharpDX.D3DCompiler;
using SharpDX.Direct3D;
using SharpDX.DXGI;
using Buffer = SharpDX.Direct3D11.Buffer;
using System.CodeDom.Compiler;

namespace Framefield.Core.ID580e76dd_52bb_447a_8258_c1f0044c01e2
{
    public class Class_MeshSurfaceArea : FXSourceCodeFunction, Framefield.Core.OperatorPartTraits.ITimeAccessor
    {

        //>>> _inputids
        private enum InputId
        {
            Code = 0,
            Mesh = 1
        }
        //<<< _inputids

        public override void Dispose()
        {
            _inputMesh = null;
            Utilities.DisposeObj(ref _outputBuffer);
            Utilities.DisposeObj(ref _outputUAV);
            Utilities.DisposeObj(ref _vertexSRV);
            Utilities.DisposeObj(ref _csCalcArea);
            Utilities.DisposeObj(ref _sumRowCS);
            base.Dispose();
        }

        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) 
        {
            //>>> _params
            var Code = inputs[(int)InputId.Code].Eval(context).Text;
            var Mesh = inputs[(int)InputId.Mesh].Eval(context).Mesh;
            //<<< _params

            //if (_csCalcArea == null)
            {
                Utilities.DisposeObj(ref _csCalcArea);
                var errors = new CompilerErrorCollection();
                try
                {
                    using (var bytecode = ShaderBytecode.Compile(GetCode(0), "CS_CalcSurfaceAreaPerTriangle", "cs_5_0", ShaderFlags.Debug))
                        _csCalcArea = new ComputeShader(D3DDevice.Device, bytecode);
//                    using (var bytecode = ShaderBytecode.CompileFromFile("m2s.hlsl", "CS_CalcSurfaceAreaPerTriangle", "cs_5_0", ShaderFlags.Debug | ShaderFlags.SkipOptimization))
//                        _csCalcArea = new ComputeShader(D3DDevice.Device, bytecode);
//                    using (var bytecode = ShaderBytecode.CompileFromFile("m2s.hlsl", "CS_SumRow", "cs_5_0", ShaderFlags.Debug | ShaderFlags.SkipOptimization))
//                        _sumRowCS = new ComputeShader(D3DDevice.Device, bytecode);
                }
                catch (SharpDX.CompilationException ex)
                {
                    errors = ErrorsFromString(ex.Message);
                    Logger.Error(this,"Fx compile error: {0}", ex.Message);
                }
            }

            var numVerticesInMesh = Mesh.Vertices.Description.SizeInBytes/Mesh.AttributesSize;
            Logger.Info("num vertices: {0}, inputLayoutSize: {1}, num tringles: {2}", numVerticesInMesh, Mesh.AttributesSize, Mesh.NumTriangles);
//            if (_outputBuffer == null)
            {
                ShaderResourceView srv = null;
                var dummyTarget = new float[Mesh.NumTriangles];
                //new [] { 0.0f }
                BaseRenderer.SetupStructuredBuffer2(context.D3DDevice, dummyTarget, f => f, ref _outputBuffer, false, ref srv, true, ref _outputUAV);
            }

            if (_inputMesh != Mesh)
            {
                Utilities.DisposeObj(ref _vertexSRV);
                var bufferResource = new ShaderResourceViewDescription.ExtendedBufferResource()
                                         {
                                             ElementCount = Mesh.Vertices.Description.SizeInBytes/4,
                                             FirstElement = 0,
                                             Flags = ShaderResourceViewExtendedBufferFlags.Raw
                                         };
                var srvDesc = new ShaderResourceViewDescription()
                                  {
                                      Format = Format.R32_Typeless,
                                      Dimension = ShaderResourceViewDimension.ExtendedBuffer,
                                      BufferEx = bufferResource
                                  };
                _vertexSRV = new ShaderResourceView(context.D3DDevice, Mesh.Vertices, srvDesc);
            }

            var deviceContext = context.D3DDevice.ImmediateContext;


            deviceContext.ComputeShader.Set(_csCalcArea);
            deviceContext.ComputeShader.SetUnorderedAccessView(0, _outputUAV);
            deviceContext.ComputeShader.SetShaderResource(0, _vertexSRV);
            deviceContext.Dispatch(1, 1, 1);

            context.Value = 1.1231233f;

            return context;
        }

        private Buffer _outputBuffer;
        private UnorderedAccessView _outputUAV;
        private Mesh _inputMesh;
        private ShaderResourceView _vertexSRV;
        private ComputeShader _csCalcArea;
        private ComputeShader _sumRowCS;
    }
}

