//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using
using SharpDX.Direct3D;
using SharpDX.DXGI;

namespace Framefield.Core.IDdde2a36b_6c1a_4039_b187_5ba80c58ca31
{
    public class Class_SSAOCrytek : FXImageFunction
    {
        //>>> _inputids
        private enum InputId
        {
            Code = 0,
            DepthImage = 1,
            KernelScale = 2,
            KernelSize = 3,
            Seed = 4,
            DepthClip = 5,
            Image = 6
        }
        //<<< _inputids

        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            //>>> __params
            var Code = inputs[(int)InputId.Code].Eval(context).Text;
            var KernelScale = inputs[(int)InputId.KernelScale].Eval(context).Value;
            var KernelSize = inputs[(int)InputId.KernelSize].Eval(context).Value;
            var Seed = inputs[(int)InputId.Seed].Eval(context).Value;
            var DepthClip = inputs[(int)InputId.DepthClip].Eval(context).Value;
            var Image = inputs[(int)InputId.Image].Eval(context).Image; if (Image == null) return context;
            var DepthImage = inputs[(int)InputId.DepthImage].Eval(context).Image;
            //<<< _params

            return PrepareAndEvalOnChange(context, () => {
                ClearRenderTarget(context, new SharpDX.Color4(0, 0, 0, 1));

                var shaderDesc = new ShaderResourceViewDescription();
                shaderDesc.Format = Format.R32_Float;
                shaderDesc.Dimension = ShaderResourceViewDimension.Texture2D;
                shaderDesc.Texture2D.MipLevels = 1;
                using (var depthTexture = new ShaderResourceView(context.D3DDevice, context.DepthImage, shaderDesc)) 
                {
                    _effect.GetVariableByName("txDepth").AsShaderResource().SetResource(depthTexture); 
Logger.Info("dt: {0}",context.DepthImage != null);
                //>>> _setup
                using (var DepthImageView = new ShaderResourceView(context.D3DDevice, DepthImage))
                using (var ImageView = new ShaderResourceView(context.D3DDevice, Image))
                {
                    _effect.GetVariableByName("RenderTargetSize").AsVector().Set(new Vector2(_usedViewport.Width, _usedViewport.Height));
                    _effect.GetVariableByName("DepthImage").AsShaderResource().SetResource(DepthImageView);
                    _effect.GetVariableByName("KernelScale").AsScalar().Set(KernelScale);
                    _effect.GetVariableByName("KernelSize").AsScalar().Set(KernelSize);
                    _effect.GetVariableByName("Seed").AsScalar().Set(Seed);
                    _effect.GetVariableByName("DepthClip").AsScalar().Set(DepthClip);
                    _effect.GetVariableByName("Image").AsShaderResource().SetResource(ImageView);
                //<<< _setup

                Render(context);

                //>>> _cleanup
                }
                //<<< _cleanup
                }
            });
        }

    }
}

