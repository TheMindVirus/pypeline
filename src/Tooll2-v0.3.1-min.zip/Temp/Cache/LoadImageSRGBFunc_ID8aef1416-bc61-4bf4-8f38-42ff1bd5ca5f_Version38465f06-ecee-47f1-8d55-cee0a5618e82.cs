//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using
using System.IO;
using SharpDX.DXGI;

namespace Framefield.Core.ID8aef1416_bc61_4bf4_8f38_42ff1bd5ca5f
{
    public class Class_LoadImageLinear : OperatorPart.Function
    {
        //>>> _inputids
        private enum InputId
        {
            ImagePath = 0
        }
        //<<< _inputids

        //>>> _outputids
        private enum OutputId
        {
            Image = 0,
            SizeX = 1,
            SizeY = 2
        }
        //<<< _outputids

        public override void Dispose() {
            Utilities.DisposeObj(ref _image);
        }

        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) 
        {
            //>>> _params
            var ImagePath = inputs[(int)InputId.ImagePath].Eval(context).Text;
            //<<< _params

            if (ImagePath == _lastImage)
                Changed = false;

            _lastImage = ImagePath;

            if (Changed)
            {
                Dispose();
                if (File.Exists(ImagePath))
                {
//                    _image = SharpDX.Direct3D11.Resource.FromFile<Texture2D>(D3DDevice.Device, ImagePath);
_image = (Texture2D)Texture2D.FromFile(D3DDevice.Device, ImagePath, 
                                       new ImageLoadInformation
                                        {
                                            Format = Format.R8G8B8A8_UNorm_SRgb,
                                            Filter = FilterFlags.SRgbIn | FilterFlags.None,
                                            BindFlags = BindFlags.ShaderResource,
                                            CpuAccessFlags = CpuAccessFlags.None,
                                            Usage = ResourceUsage.Default
                                        });
                }
                else
                {
                    Logger.Error(this,"Imagefile not found '{0}'", ImagePath);
                }

                Changed = false;
            }

            if (_image != null)
            {
                switch ((OutputId)outputIdx)
                {
                    case OutputId.Image:
                        context.Image = _image;
                        break;
                    case OutputId.SizeX:
                        context.Value = _image.Description.Width;
                        break;
                    case OutputId.SizeY:
                        context.Value = _image.Description.Height;
                        break;
                }
            }
            else
            {
                switch (outputIdx)
                {
                    case (int)OutputId.Image:
                        context.Image = null;
                        break;
                    case (int)OutputId.SizeX:
                        context.Value = 0;
                        break;
                    case (int)OutputId.SizeY:
                        context.Value = 0;
                        break;
                }
            }

            return context;
        }

        Texture2D _image;
        String _lastImage = String.Empty;
    }
}

