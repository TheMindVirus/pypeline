using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;

namespace Framefield.Core.ID5fd85983_04a1_4efb_865d_34b48eb986e1
{
    public class Class_Max : OperatorPart.Function
    {
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            var Value1 = (float) inputs[0].Eval(context).Value;
            var Value2 = (float) inputs[1].Eval(context).Value;
            context.Value = Value1 > Value2 ? Value1 : Value2;
            
            return context;
        }
    }
}

