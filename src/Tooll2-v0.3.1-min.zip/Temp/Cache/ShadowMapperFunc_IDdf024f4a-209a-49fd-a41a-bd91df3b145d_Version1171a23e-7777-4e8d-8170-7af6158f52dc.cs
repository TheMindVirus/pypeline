//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using
using Framefield.Core.Rendering;
using SharpDX.DXGI;

namespace Framefield.Core.IDdf024f4a_209a_49fd_a41a_bd91df3b145d
{
    public sealed class Class_ShadowMapper : FXSourceCodeFunction
    {
        //>>> _inputids
        private enum InputId
        {
            Code = 0,
            Scene = 1
        }
        //<<< _inputids

        #region Renderer
//        public class Renderer : BaseRenderer
//        {
//            public override void SetupEffect(OperatorPartContext context)
//            {
//                base.SetupEffect(context);
//                try
//                {
//                    SetupMaterialConstBuffer(context);
//                    SetupFogSettingsConstBuffer(context);
//                    SetupPointLightsConstBuffer(context);
//                }
//                catch (Exception e)
//                {
//                    Logger.Error(ParentFunc, "Error building constant buffer: {0} - Source: {1}", e.Message, e.Source);
//                }
//            }
//
//            public OperatorPart.Function ParentFunc { get; set; }
//        }
        #endregion

        public Class_ShadowMapper()
        {
//            _renderer = new Renderer { ParentFunc = this };

        }

        public override void Dispose()
        {
//            Utilities.DisposeObj(ref _renderer);
            Utilities.DisposeObj(ref _renderTargetDepthView);
            Utilities.DisposeObj(ref _renderDepthResource);
            base.Dispose();
        }

        private bool BuildDepthTarget(int width, int height, SharpDX.Direct3D11.Device device)
        {
            var depthStencilResourceChanged = ResourceManager.ValidateDepthStencilResource(ref _renderDepthResource, OperatorPart, device, width, height);
            if (depthStencilResourceChanged)
            {
                Utilities.DisposeObj(ref _renderTargetDepthView);

                var depthViewDesc = new DepthStencilViewDescription { Format = Format.D32_Float, Dimension = DepthStencilViewDimension.Texture2D };
                _renderTargetDepthView = new DepthStencilView(device, _renderDepthResource.Texture, depthViewDesc);
            }

            return depthStencilResourceChanged;
        }

        private bool _firstEval = true;
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx)
        {
            //>>> _params
            var Code = inputs[(int)InputId.Code].Eval(context).Text;
            var Scene = inputs[(int)InputId.Scene];
            //<<< _params

            if (_firstEval)
            {
                for (int i = 0; i < NumCodes(); ++i)
                    Compile(i);
                _firstEval = false;
            }

            var width = (int) context.Viewport.Width;
            var height = (int) context.Viewport.Height;
            BuildDepthTarget(width, height, context.D3DDevice);
Logger.Info("Outputidx {0}", outputIdx);
            if (outputIdx == 0)
            {
                var prevEffect = context.Effect;
    //            var prevRenderer = context.Renderer;
                var prevRenderTarget = context.RenderTargetView;
                var prevDepthStencil = context.DepthStencilView;
    
                context.Effect = _effect;
    //            context.Renderer = _renderer;
                context.RenderTargetView = null;
                context.DepthStencilView = _renderTargetDepthView;
    
                Scene.Eval(context);
            Logger.Info("scene");

                context.DepthStencilView = prevDepthStencil;
                context.RenderTargetView = prevRenderTarget;
    //            context.Renderer = prevRenderer;
                context.Effect = prevEffect;
            }
            else if (outputIdx == 1)
            {
            Logger.Info("image");
                context.DepthImage = _renderDepthResource.Texture;
            }
            
            return context;
        }

//        Renderer _renderer;
        private Resource _renderDepthResource;
        private DepthStencilView _renderTargetDepthView;
    }
}


