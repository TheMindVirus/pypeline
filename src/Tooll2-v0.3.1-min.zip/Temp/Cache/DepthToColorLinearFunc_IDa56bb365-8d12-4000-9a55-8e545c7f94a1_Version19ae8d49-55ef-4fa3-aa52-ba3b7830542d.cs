//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using
using SharpDX.Direct3D;
using SharpDX.DXGI;

namespace Framefield.Core.IDa56bb365_8d12_4000_9a55_8e545c7f94a1
{
    public class Class_DepthToColorLinear : FXImageFunction
    {
        //>>> _inputids
        private enum InputId
        {
            Code = 0,
            Image = 1,
            RangeMin = 2,
            RangeMax = 3
        }
        //<<< _inputids

        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            //>>> params
            var Code = inputs[(int)InputId.Code].Eval(context).Text;
            var Image = inputs[(int)InputId.Image].Eval(context).Image;
            var RangeMin = inputs[(int)InputId.RangeMin].Eval(context).Value;
            var RangeMax = inputs[(int)InputId.RangeMax].Eval(context).Value;
            var Range = new Vector2(RangeMin, RangeMax);
            //<<< _params

            return PrepareAndEvalOnChange(context, () => {
                ClearRenderTarget(context, new SharpDX.Color4(0, 0, 0, 1));

                var shaderDesc = new ShaderResourceViewDescription();
                shaderDesc.Format = Format.R32_Float;
                shaderDesc.Dimension = ShaderResourceViewDimension.Texture2D;
                shaderDesc.Texture2D.MipLevels = 1;
                Logger.Info(this, "is null: {0}", context.Image != null);
                using (var depthTexture = new ShaderResourceView(context.D3DDevice, Image, shaderDesc))
                {
                    _effect.GetVariableByName("txDepth").AsShaderResource().SetResource(depthTexture); 

                    _effect.GetVariableByName("RenderTargetSize").AsVector().Set(new Vector2(_usedViewport.Width, _usedViewport.Height));
                    _effect.GetVariableByName("Range").AsVector().Set(new Vector2(RangeMin, RangeMax));
    
                    Render(context);
                }
            });
        }

    }
}

