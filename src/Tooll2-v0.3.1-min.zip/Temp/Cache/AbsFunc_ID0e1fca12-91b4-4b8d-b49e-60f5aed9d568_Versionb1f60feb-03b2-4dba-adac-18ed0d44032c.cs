//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using

namespace Framefield.Core.ID0e1fca12_91b4_4b8d_b49e_60f5aed9d568
{
    public class Class_Abs : OperatorPart.Function
    {
        //>>> _inputids
        private enum InputId
        {
            Value = 0
        }
        //<<< _inputids
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) 
        {
            //>>> _params
            var Value = inputs[(int)InputId.Value].Eval(context).Value;
            //<<< _params
            //>>> function
            context.Value= (float)Math.Abs(Value);
            
            //<<< function
            
            return context;
        }
    }
}

