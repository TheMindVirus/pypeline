//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using
using SharpDX.Direct3D;
using SharpDX.DXGI;

namespace Framefield.Core.ID0509eb05_3e61_42d1_8906_640be9a16238
{
    public class Class_CoC : FXImageFunction
    {
        protected override bool NeedsDepth { get { return false; } }
        protected override Format ColorBufferFormat { get { return Format.R8G8_UNorm; } }

        protected override Format GetColorBufferFormat(OperatorPartContext context)
        {
            return ColorBufferFormat;
        }

        //>>> _inputids
        private enum InputId
        {
            Code = 0,
            Image = 1,
            Camera = 2,
            FocusDistance = 3,
            FocusRange = 4,
            BlendRangeNear = 5,
            BlendRangeFar = 6
        }
        //<<< _inputids
/*
        protected override bool BuildRenderTarget(SharpDX.DXGI.Format imageBufferFormat)
        {
            var pass1ResourceChanged = ResourceManager.ValidateRenderTargetResource(ref _pass1RenderTargetResource, OperatorPart, D3DDevice.Device,
                                                                                    (int)_usedViewport.Width, (int)_usedViewport.Height);
            if (pass1ResourceChanged)
            {
                Utilities.DisposeObj(ref _pass1RenderTargetView);
                _pass1RenderTargetView = new RenderTargetView(D3DDevice.Device, _pass1RenderTargetResource.Texture);
            }

            return base.BuildRenderTarget(imageBufferFormat) || pass1ResourceChanged;
        }
*/
        public override void Dispose()
        {
//            ResourceManager.Dispose(_pass1RenderTargetResource);
//            Utilities.DisposeObj(ref _pass1RenderTargetView);
            base.Dispose();
        }

        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx)
        {
            return PrepareAndEvalOnChange(context, () =>
            {
                //>>> __params
                //<<< __params
                var Code = inputs[(int)InputId.Code].Eval(context).Text;
                var resultContextOfImageInput = inputs[(int)InputId.Image].Eval(context);
                var Image = resultContextOfImageInput.Image;
                var DepthImage = resultContextOfImageInput.DepthImage;
                var Camera = inputs[(int)InputId.Camera].Eval(context).Dynamic;
                var FocusDistance = inputs[(int)InputId.FocusDistance].Eval(context).Value;
                var FocusRange = inputs[(int)InputId.FocusRange].Eval(context).Value;
                var Focus = new Vector2(FocusDistance, FocusRange);
                var BlendRangeNear = inputs[(int)InputId.BlendRangeNear].Eval(context).Value;
                var BlendRangeFar = inputs[(int)InputId.BlendRangeFar].Eval(context).Value;
                var BlendRange = new Vector2(BlendRangeNear, BlendRangeFar);

                if (Image == null || DepthImage == null || Camera == null)
                {
                    Logger.Error(this, "color or depth image or camera is not available");
                    return;
                }

                Framefield.Core.OperatorPartTraits.ICameraProvider camProvider = Camera.This as Framefield.Core.OperatorPartTraits.ICameraProvider;
                if (camProvider == null)
                {
                    Logger.Error(this, "camera not defined");
                    return;
                }
Logger.Info(this, "type: {0}", _renderTargetResource.Texture.Description.Format);
                var D3DDevice = context.D3DDevice;
                var proj = Matrix.OrthoLH(1, 1, -100, 100);
                var worldToCamera = Matrix.LookAtLH(new Vector3(0, 0, -5), new Vector3(0, 0, 0), new Vector3(0, 1, 0));

                var shaderDesc = new ShaderResourceViewDescription();
                shaderDesc.Format = Format.R32_Float;
                shaderDesc.Dimension = ShaderResourceViewDimension.Texture2D;
                shaderDesc.Texture2D.MipLevels = 1;
                using (var depthTexture = new ShaderResourceView(D3DDevice, DepthImage, shaderDesc))
                using (var imageSRV = new ShaderResourceView(D3DDevice, Image))
                {
                    var viewToCamera = Matrix.Invert(camProvider.CalculateCameraToView(context));

                    _effect.GetVariableByName("viewToCamera").AsMatrix().SetMatrix(viewToCamera);
                    _effect.GetVariableByName("txDepth").AsShaderResource().SetResource(depthTexture); 
                    _effect.GetVariableByName("Image").AsShaderResource().SetResource(imageSRV); 
                    _effect.GetVariableByName("widthToHeight").AsScalar().Set((float)_usedViewport.Width/_usedViewport.Height);
                    SetVector2("Focus", Focus);
                    SetVector2("BlendRange", BlendRange);

                    //pass 2 (vertical)
                    D3DDevice.ImmediateContext.ClearRenderTargetView(_renderTargetView, new SharpDX.Color4(0, 0, 0, 1));

                    var pass2SubContext = new OperatorPartContext(context);
                    pass2SubContext.DepthStencilView = null;
                    pass2SubContext.RenderTargetView = _renderTargetView;
                    pass2SubContext.Effect = _effect;
                    pass2SubContext.InputLayout = context.Renderer.ScreenQuadInputLayout;
                    pass2SubContext.CameraProjection = proj;
                    pass2SubContext.WorldToCamera = worldToCamera;
//                    using (var textureView = new ShaderResourceView(D3DDevice, _pass1RenderTargetResource.Texture))
                    {
//                        pass2SubContext.Texture0 = textureView;
                        pass2SubContext.Renderer.SetupEffect(pass2SubContext);

//                        _effect.GetVariableByName("direction").AsVector().Set(new Vector2(0, 1));

                        pass2SubContext.Renderer.Render(pass2SubContext.Renderer._screenQuadMesh, pass2SubContext);
                    }
                }
            });
        }

//        Resource _pass1RenderTargetResource = null;
//        RenderTargetView _pass1RenderTargetView = null;
    }
}
