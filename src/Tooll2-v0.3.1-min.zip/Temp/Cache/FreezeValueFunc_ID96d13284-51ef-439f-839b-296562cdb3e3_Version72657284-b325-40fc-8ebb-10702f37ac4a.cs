//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using
namespace Framefield.Core.ID96d13284_51ef_439f_839b_296562cdb3e3
{

    public class Class_Multiply : OperatorPart.Function
    {
        //>>> _inputids
        private enum InputId
        {
            Value = 0,
            Trigger = 1
        }
        //<<< _inputids
        
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            //>>> _params
            var Value = inputs[(int)InputId.Value].Eval(context).Value;
            var Trigger = inputs[(int)InputId.Trigger].Eval(context).Value;
            //<<< _params
            
            if( Trigger != 0) {
                _frozenValue = Value;
            }
            context.Value = _frozenValue;
            
            return context;
        }
        private float _frozenValue=0;
    }
}

