//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using

namespace Framefield.Core.IDac72e5d2_8b31_4406_9216_598816c03008
{
    public class Class_CompareTexts : OperatorPart.Function
    {
        //>>> _inputids
        private enum InputId
        {
            TextA = 0,
            TextB = 1
        }
        //<<< _inputids
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            //>>> _params
            var TextA = inputs[(int)InputId.TextA].Eval(context).Text;
            var TextB = inputs[(int)InputId.TextB].Eval(context).Text;
            //<<< _params

            
            context.Value = TextA == TextB ? 1 : 0;
            return context;
        }
    }
}

