using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;

namespace Framefield.Core.ID4e20da39_dc5b_4f7f_a45b_55973e7e905c
{
    public class Class_Noise : OperatorPart.Function
    {
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            var Value = (float) inputs[0].Eval(context).Value;
            var Seed = (float) inputs[1].Eval(context).Value;
            //!!automatic generated code ends here
            int n = (int)Value + (int)Seed*137;
            n = (n << 13) ^ n;
            
            context.Value= (1.0f - ((n * (n * n * 15731 + 789221) + 1376312589) & 0x7fffffff) / 1073741824.0f);
            
            //!!automatic generated code starts here
            return context;
        }
    }
}
