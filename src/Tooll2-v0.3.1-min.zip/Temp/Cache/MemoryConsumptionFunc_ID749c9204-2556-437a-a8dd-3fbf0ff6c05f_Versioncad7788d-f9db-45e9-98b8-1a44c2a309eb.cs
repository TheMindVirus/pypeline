//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using
using Framefield.Core.Profiling;

namespace Framefield.Core.ID749c9204_2556_437a_a8dd_3fbf0ff6c05f
{
    public class Class_MemoryConsumption : OperatorPart.Function, Framefield.Core.OperatorPartTraits.ITimeAccessor
    {
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx)
        {
            if (TimeLogger.FrameCount > 0)
            {
                context.Value = (float)(TimeLogger.LastFrame.Value.PrivateMemory/(1 << 20));
            } 
            else
            {
                context.Value = 0;
            }
            return context;
        }
    }
}
