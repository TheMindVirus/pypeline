using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;

namespace Framefield.Core.ID83f03ecd_7a62_4ccd_95d4_57a9a16d532e
{
    public class Class_Or : OperatorPart.Function
    {
        //>>> _inputids
        private enum InputId
        {
            Values = 0
        }
        //<<< _inputids
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) 
        {
            //>>> _params
            var Values = inputs[(int)InputId.Values].Eval(context).Value;
            //<<< _params
            
            var anyActive = false;
            
            foreach (var input in inputs[0].Connections) {
                var value = input.Eval(context).Value;
                if(value > 0.5f) 
                    anyActive = true;
            }
            context.Value = anyActive ? 1 : 0;
            return context;
        }
    }
}

