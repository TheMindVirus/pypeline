using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;

namespace Framefield.Core.ID85aea967_8103_4c8d_bee4_94ddf7f8226e
{
    public class Class_Sqrt : OperatorPart.Function
    {
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            var Value = (float) inputs[0].Eval(context).Value;
            //!!automatic generated code ends here
            if (Value <= 0) { 
                context.Value = 0.0f;
            }
            else {
                context.Value= (float) Math.Sqrt(Value);
            }
            //!!automatic generated code starts here
            return context;
        }
    }
}

