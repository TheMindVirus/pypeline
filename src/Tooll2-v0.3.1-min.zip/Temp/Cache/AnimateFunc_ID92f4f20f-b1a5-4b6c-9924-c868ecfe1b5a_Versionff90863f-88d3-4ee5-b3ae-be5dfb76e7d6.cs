//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using
//using System.Math;

namespace Framefield.Core.ID92f4f20f_b1a5_4b6c_9924_c868ecfe1b5a
{
    public class Class_Ramp : OperatorPart.Function, Framefield.Core.OperatorPartTraits.ITimeAccessor
    {
        //>>> _inputids
        private enum InputId
        {
            Speed = 0,
            Offset = 1
        }
        //<<< _inputids
        
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) 
        {
            
            //>>> _params
            var Speed = inputs[(int)InputId.Speed].Eval(context).Value;
            var Offset = inputs[(int)InputId.Offset].Eval(context).Value;
            //<<< _params
            

            context.Value = context.Time * Speed + Offset;
            return context;
        }
    }
}


