//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using

namespace Framefield.Core.IDf7d14553_613a_41b8_b356_73b4c53ce39f
{
    public class Class_Modulo : OperatorPart.Function
    {
        //>>> _inputids
        private enum InputId
        {
            Value1 = 0,
            Value2 = 1
        }
        //<<< _inputids
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) 
        {
            //>>> _params
            var Value1 = inputs[(int)InputId.Value1].Eval(context).Value;
            var Value2 = inputs[(int)InputId.Value2].Eval(context).Value;
            //<<< _params
            //>>> function
            if (Value2 != 0) {
                context.Value= Value1 % Value2;
            }
            else {
                context.Value= 0.0f;
            }
            //<<< function
            
            return context;
        }
    }
}

