using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using System.Windows.Forms;

namespace Framefield.Core.ID9cb12ee2_d4fa_45ee_a089_294c22070ba0
{
    public class Class_ScrollLockedPressed : OperatorPart.Function, Framefield.Core.OperatorPartTraits.ITimeAccessor
    {
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx)
        {
            context.Value = Control.IsKeyLocked(Keys.Scroll) ? 1f : 0f;
            return context;
        }
    }
}


