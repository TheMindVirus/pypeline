//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using
using SharpDX.Direct3D;
using SharpDX.DXGI;

namespace Framefield.Core.ID96473961_b836_41fa_88c1_2224644f503f
{
    public class Class_BilateralBlurWithDepth : FXImageFunction
    {
        //>>> _inputids
        private enum InputId
        {
            Code = 0,
            Passes = 1,
            KernelSize = 2,
            Seed = 3,
            DepthClip = 4,
            Image = 5
        }
        //<<< _inputids

        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            //>>> __params
            var Code = inputs[(int)InputId.Code].Eval(context).Text;
            var Passes = inputs[(int)InputId.Passes].Eval(context).Value;
            var KernelSize = inputs[(int)InputId.KernelSize].Eval(context).Value;
            var Seed = inputs[(int)InputId.Seed].Eval(context).Value;
            var DepthClip = inputs[(int)InputId.DepthClip].Eval(context).Value;
            var Image = inputs[(int)InputId.Image].Eval(context).Image; if (Image == null) return context;
//            var DepthImage = inputs[(int)InputId.DepthImage].Eval(context).Image; if (DepthImage == null) return context;
            //<<< _params

            return PrepareAndEvalOnChange(context, () => {
                ClearRenderTarget(context, new SharpDX.Color4(0, 0, 0, 1));

                var shaderDesc = new ShaderResourceViewDescription();
                shaderDesc.Format = Format.R32_Float;
                shaderDesc.Dimension = ShaderResourceViewDimension.Texture2D;
                shaderDesc.Texture2D.MipLevels = 1;
                using (var depthTexture = new ShaderResourceView(context.D3DDevice, context.DepthImage, shaderDesc)) {
                    _effect.GetVariableByName("txDepth").AsShaderResource().SetResource(depthTexture); 

                //>>> __setup
//                using (var DepthImageView = new ShaderResourceView(context.D3DDevice, DepthImage))
                using (var ImageView = new ShaderResourceView(context.D3DDevice, Image))
                {
                    _effect.GetVariableByName("RenderTargetSize").AsVector().Set(new Vector2(_usedViewport.Width, _usedViewport.Height));
//                    _effect.GetVariableByName("DepthImage").AsShaderResource().SetResource(DepthImageView);
                    _effect.GetVariableByName("Passes").AsScalar().Set(Passes);
                    _effect.GetVariableByName("KernelSize").AsScalar().Set(KernelSize);
                    _effect.GetVariableByName("Seed").AsScalar().Set(Seed);
                    _effect.GetVariableByName("DepthClip").AsScalar().Set(DepthClip);
                    _effect.GetVariableByName("Image").AsShaderResource().SetResource(ImageView);
                //<<< _setup

                Render(context);

                //>>> _cleanup
                }
                //<<< _cleanup
                }
            });
        }

    }
}

