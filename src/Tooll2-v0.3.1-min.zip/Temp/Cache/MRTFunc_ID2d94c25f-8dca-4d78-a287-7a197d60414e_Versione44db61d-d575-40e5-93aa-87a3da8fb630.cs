using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.DXGI;

namespace Framefield.Core.ID2d94c25f_8dca_4d78_a287_7a197d60414e
{
    public class Class_MRT : OperatorPart.Function
    {
        // >>> _inputids
        private enum InputId
        {
            Scene = 0,
            SizeX = 1,
            SizeY = 2,
            ColorR = 3,
            ColorG = 4,
            ColorB = 5,
            ColorA = 6,
            ClearBackground = 7
        }
        // <<< _inputids
        
        //>>> _outputids
        private enum OutputId
        {
            Color = 0,
            Depth = 1,
            Normals = 2,
            Velocity = 3
        }
        //<<< _outputids

        public override void Dispose()
        {
            ResourceManager.Dispose(_renderTargetResource);
            Utilities.DisposeObj(ref _renderTargetView);
            ResourceManager.Dispose(_renderDepthResource);
            Utilities.DisposeObj(ref _renderTargetDepthView);
            ResourceManager.Dispose(_normalsResource);
            Utilities.DisposeObj(ref _normalsRTV);
            ResourceManager.Dispose(_velocityResource);
            Utilities.DisposeObj(ref _velocityRTV);
        }

        private bool BuildRenderTarget(int width, int height, SharpDX.Direct3D11.Device device)
        {
            var rtDesc = new Texture2DDescription
                            {
                                BindFlags = BindFlags.ShaderResource | BindFlags.RenderTarget,
                                Format = Format.R16G16B16A16_Float,
                                Width = width,
                                Height = height,
                                MipLevels = 1, //origImage.Description.MipLevels,
                                SampleDescription = new SampleDescription(1, 0),
                                Usage = ResourceUsage.Default,
                                OptionFlags = ResourceOptionFlags.None,
                                CpuAccessFlags = CpuAccessFlags.None,
                                ArraySize = 1
                            };
            
            var renderTargetResourceChanged = ResourceManager.ValidateResource(ref _renderTargetResource, OperatorPart, device, rtDesc);
            if (renderTargetResourceChanged)
            {
                Utilities.DisposeObj(ref _renderTargetView);
                _renderTargetView = new RenderTargetView(device, _renderTargetResource.Texture);
            }

            var depthStencilResourceChanged = ResourceManager.ValidateDepthStencilResource(ref _renderDepthResource, OperatorPart, device, width, height);
            if (depthStencilResourceChanged)
            {
                Utilities.DisposeObj(ref _renderTargetDepthView);

                var depthViewDesc = new DepthStencilViewDescription();
                depthViewDesc.Format = Format.D32_Float;
                depthViewDesc.Dimension = DepthStencilViewDimension.Texture2D;

                _renderTargetDepthView = new DepthStencilView(device, _renderDepthResource.Texture, depthViewDesc);
            }

            var normalsDesc = rtDesc;
            var normalsResourceChanged = ResourceManager.ValidateResource(ref _normalsResource, OperatorPart, device, normalsDesc);
            if (normalsResourceChanged)
            {
                Utilities.DisposeObj(ref _normalsRTV);
                _normalsRTV = new RenderTargetView(device, _normalsResource.Texture);
            }

            var velocityDesc = rtDesc;
            var velocityResourceChanged = ResourceManager.ValidateResource(ref _velocityResource, OperatorPart, device, velocityDesc);
            if (velocityResourceChanged)
            {
                Utilities.DisposeObj(ref _velocityRTV);
                _velocityRTV = new RenderTargetView(device, _velocityResource.Texture);
            }

            return renderTargetResourceChanged || depthStencilResourceChanged || normalsResourceChanged || velocityResourceChanged;
        }

        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx)
        {
            var Scene = inputs[0];

            int SizeX = (int) inputs[1].Eval(context).Value;
            int SizeY = (int) inputs[2].Eval(context).Value;
            float ColorR = inputs[3].Eval(context).Value;
            float ColorG = inputs[4].Eval(context).Value;
            float ColorB = inputs[5].Eval(context).Value;
            float ColorA = inputs[6].Eval(context).Value;
            bool ClearBackground = inputs[(int)InputId.ClearBackground].Eval(context).Value != 0;

            if (SizeX == 0 || SizeY == 0)
            {
                SizeX = (int) context.Viewport.Width;
                SizeY = (int) context.Viewport.Height;
            }

            Changed |= BuildRenderTarget(SizeX, SizeY, context.D3DDevice);

            if (Changed)
            {
                var subContext = new OperatorPartContext(context);
                var D3DDevice = context.D3DDevice;

                float aspect = (float) SizeX / (float) SizeY;
                subContext.CameraProjection = Matrix.PerspectiveFovLH(3.1415f / 4.0f, aspect, 0.01f, 1000);
                subContext.WorldToCamera = Matrix.LookAtLH(new Vector3(0, 0, -10), new Vector3(0, 0, 0), new Vector3(0, 1, 0));
                subContext.ObjectTWorld = Matrix.Identity;
                subContext.TextureMatrix = Matrix.Identity;
                subContext.Renderer = OperatorPartContext.DefaultRenderer;
                subContext.RenderTargetView = _renderTargetView;
                subContext.RenderTargetViews = new [] { _renderTargetView, _normalsRTV, _velocityRTV };
                subContext.DepthStencilView = _renderTargetDepthView;

                subContext.DepthStencilState = OperatorPartContext.DefaultRenderer.DefaultDepthStencilState;
                subContext.BlendState = OperatorPartContext.DefaultRenderer.DefaultBlendState;
                subContext.Viewport = new Viewport(0, 0, SizeX, SizeY, 0.0f, 1.0f);

                subContext.InputLayout = OperatorPartContext.DefaultRenderer.SceneDefaultInputLayout;
                subContext.Effect = OperatorPartContext.DefaultRenderer.SceneDefaultEffect;

                D3DDevice.ImmediateContext.ClearDepthStencilView(_renderTargetDepthView, DepthStencilClearFlags.Depth | DepthStencilClearFlags.Stencil, 1.0f, 0);
                D3DDevice.ImmediateContext.ClearRenderTargetView(_normalsRTV, new SharpDX.Color4(0,0,0,0));
                if (ClearBackground)
                {
                    D3DDevice.ImmediateContext.ClearRenderTargetView(_renderTargetView, new SharpDX.Color4(ColorR, ColorG, ColorB, ColorA));
                }

                Scene.Eval(subContext);

                Changed = false;
            }

            switch ((OutputId) outputIdx)
            {
                case OutputId.Color:
                    context.Image = _renderTargetResource.Texture;
                    context.DepthImage = _renderDepthResource.Texture;
                    break;
                case OutputId.Depth:
                    context.Image = _renderDepthResource.Texture;
                    break;
                case OutputId.Normals:
                    context.Image = _normalsResource.Texture;
                    break;
                case OutputId.Velocity:
                    context.Image = _velocityResource.Texture;
                    break;
            }

            return context;
        }

        Resource _renderTargetResource;
        RenderTargetView _renderTargetView;
        Resource _renderDepthResource;
        DepthStencilView _renderTargetDepthView;
        Resource _normalsResource;
        RenderTargetView _normalsRTV;
        Resource _velocityResource;
        RenderTargetView _velocityRTV;
    }
}

