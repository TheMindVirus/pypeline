using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using System.Windows.Forms;

namespace Framefield.Core.ID093d4344_b67f_41ca_9306_0de805b12468
{
    public class Class_CapsLockedPressed : OperatorPart.Function, Framefield.Core.OperatorPartTraits.ITimeAccessor
    {
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            context.Value = Control.IsKeyLocked(Keys.NumLock) ? 1f : 0f;
            return context;
        }
    }
}


