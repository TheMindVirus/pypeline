//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using

namespace Framefield.Core.ID4b78820a_0035_425b_a0f3_d75ce8b62dfd
{
    public class Class_ReinhardToneMapper : FXImageFunction
    {
        protected override bool NeedsDepth { get { return false; } }

        //>>> _inputids
        private enum InputId
        {
            Code = 0,
            Image = 1,
            MiddleKey = 2,
            LnAverageLuminance = 3,
            MaxLuminance = 4
        }
        //<<< _inputids

        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx)
        {
            return PrepareAndEvalOnChange(context, () =>
            {
                //>>> __params
                var Code = inputs[(int)InputId.Code].Eval(context).Text;
                var Image = inputs[(int)InputId.Image].Eval(context).Image;
                var MiddleKey = inputs[(int)InputId.MiddleKey].Eval(context).Value;
                var LnAverageLuminance = inputs[(int)InputId.LnAverageLuminance].Eval(context).Value;
                var MaxLuminance = inputs[(int)InputId.MaxLuminance].Eval(context).Value;
                //<<< __params

                ClearRenderTarget(context, new Color4(0, 0, 0, 1));

                //>>> _setup
                using (var ImageView = new ShaderResourceView(context.D3DDevice, Image))
                {
                    _effect.GetVariableByName("RenderTargetSize").AsVector().Set(new Vector2(_usedViewport.Width, _usedViewport.Height));
                    _effect.GetVariableByName("Image").AsShaderResource().SetResource(ImageView);
                    _effect.GetVariableByName("MiddleKey").AsScalar().Set(MiddleKey);
                    _effect.GetVariableByName("LnAverageLuminance").AsScalar().Set(LnAverageLuminance);
                    _effect.GetVariableByName("MaxLuminance").AsScalar().Set(MaxLuminance);
                    //<<< _setup

                    var prevBlendState = context.BlendState;
                    context.BlendState = OperatorPartContext.DefaultRenderer.DisabledBlendState;

                    Render(context);

                    context.BlendState = prevBlendState;
                    //>>> _cleanup
                    }
                //<<< _cleanup
            });
        }
    }
}

