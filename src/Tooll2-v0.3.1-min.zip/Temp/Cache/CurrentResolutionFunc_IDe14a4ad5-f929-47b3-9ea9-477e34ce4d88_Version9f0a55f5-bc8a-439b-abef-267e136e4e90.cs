using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;

namespace Framefield.Core.IDe14a4ad5_f929_47b3_9ea9_477e34ce4d88
{
    public class Class_CurrentResolution : OperatorPart.Function, Framefield.Core.OperatorPartTraits.ITimeAccessor
    {
        //>>> _outputids
        private enum OutputId
        {
            Width = 0,
            Height = 1,
            AspectRatio = 2
        }
        //<<< _outputids
        
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) 
        {
            //>>> function
            switch((OutputId)outputIdx) {
                case OutputId.Width:                    
                    context.Value = context.Viewport.Width;
                    break;
                case OutputId.Height:                    
                    context.Value = context.Viewport.Height;
                    break;
                case OutputId.AspectRatio:
//                    context.Value = context.AspectRatio;
                    break;
            }
            
            return context;
            //<<< function
        }
    }
}


