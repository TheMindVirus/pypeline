using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;

namespace Framefield.Core.ID4e1811b4_b017_4508_a7b6_800c8e06282b
{
    public class Class_DrawText : OperatorPart.Function
    {
        public override void Dispose() {
            DisposeFontCache();
//             Utilities.DisposeObj(ref _sprite);
        }

        private void DisposeFontCache() {
//             foreach (var fontEntry in _fontCache) {
//                 fontEntry.Value.Dispose();
//             }
//             _fontCache.Clear();
        }

        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            var Subtree = inputs[0];
            var Text = (string) inputs[1].Eval(context).Text;

            if (inputs[2].Func.Changed)
                DisposeFontCache();

            var Font = (string) inputs[2].Eval(context).Text;
            var FontSize = (float) inputs[3].Eval(context).Value;
            var TextPosX = (float) inputs[4].Eval(context).Value;
            var TextPosY = (float) inputs[5].Eval(context).Value;
            var ColorR = (float) inputs[6].Eval(context).Value;
            var ColorG = (float) inputs[7].Eval(context).Value;
            var ColorB = (float) inputs[8].Eval(context).Value;
            var ColorA = (float) inputs[9].Eval(context).Value;
            var color = new Color4(ColorR, ColorG, ColorB, ColorA);
            var HorAlignment = (float) inputs[10].Eval(context).Value;
            var VerAlignment = (float) inputs[11].Eval(context).Value;

            var viewport = context.Viewport;
            var widthHalf = viewport.Width/2.0f;
            var heightHalf = viewport.Height/2.0f;
            var fontSizeChanged = inputs[3].Func.Changed;
            //var FontSize = inputs[3].Eval(context).Value;
            var fontSizeInPixel = (int) (heightHalf * FontSize);

//             if (_sprite == null)
//                 _sprite = new Sprite(context.D3DDevice, 2);
// 
// 
//             bool newFont = false;
//             Font font;
//             if (!_fontCache.TryGetValue(fontSizeInPixel, out font))
//             {
//                 var fontName = inputs[2].Eval(context).Text;
//                 font = new Font(context.D3DDevice, fontSizeInPixel, fontName);
//                 _fontCache.Add(fontSizeInPixel, font);
//                 newFont = true;
//             }

            bool textInputChanged = inputs[1].Func.Changed;
            //var Text = inputs[1].Eval(context).Text;
//             if (textInputChanged || newFont) {
//                 font.PreloadText(Text);
//             }

            Subtree.Eval(context);

            if (context.D3DDevice != null) {
//                 var size = font.Measure(_sprite, Text, new System.Drawing.Rectangle(0, 0, viewport.Width, viewport.Height), SharpDX.Direct3D11.FontDrawFlags.Center);
//                 //int posX = (int) (viewport.X + widthHalf*TextPosX) - size.Width/2;
//                 //int posY = (int) (viewport.Y + heightHalf*-TextPosY)- size.Height/2;
//                 int posX = (int) ( widthHalf*TextPosX ); // + size.Width/2;
//                 int posY = (int) (viewport.Y + heightHalf*-TextPosY); //- size.Height/2;
//                 FontDrawFlags alignment = (FontDrawFlags) (HorAlignment + VerAlignment);
//                 _sprite.Begin(SharpDX.Direct3D11.SpriteFlags.None);
//                 font.Draw(null, Text, new System.Drawing.Rectangle(posX, posY, viewport.Width, viewport.Height), alignment, color);
// //                font.Draw(null, Text, new System.Drawing.Rectangle(0, 0, viewport.Width, viewport.Height), alignment, color);
//                 _sprite.End();
            }

            return context;
        }

//         Sprite _sprite = null;
//         Dictionary<int, Font> _fontCache = new Dictionary<int,Font>();
    }
}


