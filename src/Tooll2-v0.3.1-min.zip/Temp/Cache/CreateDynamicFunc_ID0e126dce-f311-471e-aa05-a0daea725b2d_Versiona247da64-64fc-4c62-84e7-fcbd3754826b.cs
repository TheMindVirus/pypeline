using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Xml;
using SharpDX;

namespace Framefield.Core.ID0e126dce_f311_471e_aa05_a0daea725b2d
{
    public class Class_CreateDynamic : OperatorPart.Function
    {
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            var FileName = (string) inputs[0].Eval(context).Text;

            dynamic obj = new ExpandoObject();

            XmlDocument doc = new XmlDocument();
            doc.Load(FileName);
            XmlElement root = doc.DocumentElement;

            obj.Title = "bla";
            obj.Items = new List<dynamic>();

            foreach (XmlNode item in root.GetElementsByTagName("item")) {
                var value = item["title"].InnerText;
                obj.Items.Add(value);
            }

            context.Dynamic = obj;
            return context;
        }
    }
}

