//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using


namespace Framefield.Core.IDd74d9d08_0afa_4dba_abc0_ed14adc60054
{
    public class Class_RenderMesh : OperatorPart.Function
    {

        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx)
        {
//            if (!Changed) 
//                return;
            try
            {
                var mesh = inputs[0].Eval(context).Mesh;
                context.Renderer.SetupEffect(context);
                context.Renderer.Render(mesh, context);
            }
            catch (Exception)
            {
                //Logger.Error(this,"error");
            }

            return context;
        }
    }
}


