//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using

using System.Runtime.InteropServices;
using Framefield.Core.Rendering;
using SharpDX.DXGI;
using SharpDX.D3DCompiler;
using Buffer = SharpDX.Direct3D11.Buffer;
using System.CodeDom.Compiler;

namespace Framefield.Core.IDc854e237_d4ea_4009_8436_a51311989ce3
{
    public class Class_CSWithInput : FXSourceCodeFunction
    {

        //>>> _inputids
        private enum InputId
        {
            Code = 0,
            Image = 1
        }
        //<<< _inputids

        public void Dispose()
        {
            Utilities.DisposeObj(ref _uaTexture);
            Utilities.DisposeObj(ref _cs);
            base.Dispose();
        }

        protected bool BuildRenderTarget(OperatorPartContext context)
        {
            if (_uaTexture != null)
            {
            //    return false;
            }

            var uavDesc = new Texture2DDescription
                                  {
                                      BindFlags = BindFlags.ShaderResource | BindFlags.UnorderedAccess,
                                      Format = Format.R8G8B8A8_UNorm,
                                      Width = 1024,
                                      Height = 1024,
                                      MipLevels = 1,
                                      SampleDescription = new SampleDescription(1, 0),
                                      Usage = ResourceUsage.Default,
                                      OptionFlags = ResourceOptionFlags.None,
                                      CpuAccessFlags = CpuAccessFlags.None,
                                      ArraySize = 1
                                  };
            Utilities.DisposeObj(ref _uaTexture);
            _uaTexture = new Texture2D(context.D3DDevice, uavDesc);

            return true;
        }

        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) 
        {
            //>>> _params
            var Code = inputs[(int)InputId.Code].Eval(context).Text;
            var Image = inputs[(int)InputId.Image].Eval(context).Image; // Needs to be checked for null!
            //<<< _params

            //if (_cs == null)
            {
                Utilities.DisposeObj(ref _cs);
                var errors = new CompilerErrorCollection();
                try
                {
                    using (var bytecode = ShaderBytecode.Compile(GetCode(0), "CS", "cs_5_0", ShaderFlags.Debug))
                        _cs = new ComputeShader(D3DDevice.Device, bytecode);
                }
                catch (SharpDX.CompilationException ex)
                {
                    errors = ErrorsFromString(ex.Message);
                    Logger.Error(this,"Fx compile error: {0}", ex.Message);
                }
            }

            BuildRenderTarget(context);

            //_effect.GetVariableByName("RenderTargetSize").AsVector().Set(new Vector2(_usedViewport.Width, _usedViewport.Height));

            using (var imageView = new ShaderResourceView(context.D3DDevice, Image))
            {
                var deviceContext = context.D3DDevice.ImmediateContext;
                using (var uav = new UnorderedAccessView(context.D3DDevice, _uaTexture))
                {
                    deviceContext.ComputeShader.Set(_cs);
                    deviceContext.ComputeShader.SetUnorderedAccessView(0, uav);
                    deviceContext.ComputeShader.SetShaderResource(0, imageView);
                    deviceContext.Dispatch(32, 32, 1);
                }
            }

            context.Image = _uaTexture;

            return context;
        }

        private Texture2D _uaTexture;
        private ComputeShader _cs;
    }
}

