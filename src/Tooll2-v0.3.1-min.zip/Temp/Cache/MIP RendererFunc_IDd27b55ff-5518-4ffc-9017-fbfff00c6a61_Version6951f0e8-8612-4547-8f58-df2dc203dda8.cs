//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using

using System.Runtime.InteropServices;
using Framefield.Core.Rendering;
using SharpDX.DXGI;
using SharpDX.D3DCompiler;
using Buffer = SharpDX.Direct3D11.Buffer;
using System.CodeDom.Compiler;
using System.Diagnostics;

namespace Framefield.Core.IDd27b55ff_5518_4ffc_9017_fbfff00c6a61
{
    public class Class_MIP_Renderer : FXSourceCodeFunction, Framefield.Core.OperatorPartTraits.ITimeAccessor
    {

        //>>> _inputids
        private enum InputId
        {
            Code = 0,
            Volume = 1
        }
        //<<< _inputids


        public override void Dispose()
        {

            Utilities.DisposeObj(ref _volume);
            Utilities.DisposeObj(ref _volumeSRV);

            Utilities.DisposeObj(ref _linearSamplerState);
            Utilities.DisposeObj(ref _constBuffer);

            Utilities.DisposeObj(ref _visuTexture);
            Utilities.DisposeObj(ref _visuTextureUAV);

            Utilities.DisposeObj(ref _csRender);
            base.Dispose();
        }


        [StructLayout(LayoutKind.Explicit, Size = 144)]
        public struct ConstBufferLayout
        {
            [FieldOffset(0)] 
            public Vector4 Dim;
            [FieldOffset(16)] 
            public int width;
            [FieldOffset(20)] 
            public int height;
            [FieldOffset(24)] 
            public int viewSlice;
            [FieldOffset(28)] 
            public int viewOrientation;
            [FieldOffset(32)] 
            public Vector4 mouse;
            [FieldOffset(48)] 
            public Vector4 dragDirection;
            [FieldOffset(64)] 
            public Matrix orientation;
            [FieldOffset(128)] 
            public float zoom;
            [FieldOffset(132)] 
            public int smoky;
        }

        private readonly int SIZE = 128;

        protected bool BuildRenderTarget(OperatorPartContext context)
        {
            if (_visuTexture == null ||
                (int) context.Viewport.Width != _visuTexture.Description.Width ||
                (int) context.Viewport.Height != _visuTexture.Description.Height)
            {
                var uavVisuDesc = new Texture2DDescription
                                      {
                                          BindFlags = BindFlags.ShaderResource | BindFlags.UnorderedAccess,
                                          Format = Format.R8G8B8A8_UNorm,
                                          Width = (int) context.Viewport.Width,
                                          Height = (int) context.Viewport.Height,
                                          MipLevels = 1,
                                          SampleDescription = new SampleDescription(1, 0),
                                          Usage = ResourceUsage.Default,
                                          OptionFlags = ResourceOptionFlags.None,
                                          CpuAccessFlags = CpuAccessFlags.None,
                                          ArraySize = 1
                                      };
                Utilities.DisposeObj(ref _visuTexture);
                Utilities.DisposeObj(ref _visuTextureUAV);
                _visuTexture = new Texture2D(context.D3DDevice, uavVisuDesc);
                _visuTextureUAV = new UnorderedAccessView(context.D3DDevice, _visuTexture);
            }


            // create sampler state
            var samplerDesc = new SamplerStateDescription()
                                  {
                                      Filter = Filter.MinMagMipLinear,
                                      AddressU = TextureAddressMode.Border,
                                      AddressV = TextureAddressMode.Border,
                                      AddressW = TextureAddressMode.Border,
                                      BorderColor = new Color4(0, 0, 0, 0),
                                      MipLodBias = 0,
                                      ComparisonFunction = Comparison.Never,
                                      MaximumAnisotropy = 16,
                                      MinimumLod = 0,
                                      MaximumLod = Single.MaxValue
                                  };
            Utilities.DisposeObj(ref _linearSamplerState);
            _linearSamplerState = new SamplerState(context.D3DDevice, samplerDesc);

            return true;
        }

        static int _counter = 0;

        private void SetupConstBuffer(OperatorPartContext context)
        {
            var mc = new ConstBufferLayout();

            mc.Dim[0] = SIZE;
            mc.Dim[1] = SIZE;
            mc.Dim[2] = SIZE;

            mc.width  = (int) context.Viewport.Width;
            mc.height = (int) context.Viewport.Height;

            mc.viewSlice = SIZE/2;
            mc.viewOrientation = 0;

            mc.mouse[0] = mc.width/2;
            mc.mouse[1] = mc.height/1.1f;
            mc.mouse[2] = SIZE/2;
            mc.mouse[3] = 4 ; // radius in voxels;

            mc.dragDirection[0] = 0;
            mc.dragDirection[1] = (_counter++ % 80 < 20) ? -2 : 0;
            mc.dragDirection[2] = 0;
            mc.orientation = Matrix.Identity;//RotationY(context.Time);
            mc.zoom = 1.2f;
            mc.smoky = 1;

            BaseRenderer.SetupConstBufferForCS(context, mc, ref _constBuffer, 0);
        }

        void RunShader(DeviceContext immediateContext, ComputeShader shader, ShaderResourceView in0, ShaderResourceView in1, ShaderResourceView in2, UnorderedAccessView out0, UnorderedAccessView out1, int dx, int dy, int dz)
        {
            // Set volumes as textures for cached read
            immediateContext.ComputeShader.SetShaderResource(0, in0);
            immediateContext.ComputeShader.SetShaderResource(1, in1);
            immediateContext.ComputeShader.SetShaderResource(2, in2);

            // Set unordered access views for writees
            immediateContext.ComputeShader.SetUnorderedAccessView(0, out0);
            immediateContext.ComputeShader.SetUnorderedAccessView(1, out1);

           // Set compute shader
            immediateContext.ComputeShader.Set(shader);

            // Run compute shader
            immediateContext.Dispatch(dx, dy, dz);

            immediateContext.ComputeShader.SetShaderResource(0, null);
            immediateContext.ComputeShader.SetShaderResource(1, null);
            immediateContext.ComputeShader.SetShaderResource(2, null);
            immediateContext.ComputeShader.SetUnorderedAccessView(0, null);
            immediateContext.ComputeShader.SetUnorderedAccessView(1, null);
        }

        private Stopwatch _stopwatch = new Stopwatch();
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) 
        {
            var Code = inputs[(int)InputId.Code].Eval(context).Text;
//            var Volume = inputs[(int)InputId.Volume].Eval(context).Volume;

            if (_csRender == null)
            {
                Utilities.DisposeObj(ref _csRender);
                var errors = new CompilerErrorCollection();
                try
                {
                    using (var bytecode = ShaderBytecode.Compile(GetCode(0), "CSRender", "cs_5_0", ShaderFlags.Debug))
                        _csRender = new ComputeShader(D3DDevice.Device, bytecode);
                }
                catch (CompilationException ex)
                {
                    errors = ErrorsFromString(ex.Message);
                    Logger.Error(this,"CS compile error: {0}", ex.Message);
                }
            }

            BuildRenderTarget(context);

            //_effect.GetVariableByName("RenderTargetSize").AsVector().Set(new Vector2(_usedViewport.Width, _usedViewport.Height));
//            _stopwatch.Restart();

            var deviceContext = context.D3DDevice.ImmediateContext;

            SetupConstBuffer(context);
            deviceContext.ComputeShader.SetSampler(0, _linearSamplerState);


            deviceContext.PixelShader.SetShaderResource(0, null);

            // render output
            RunShader(deviceContext, _csRender, _volumeSRV, null, null, _visuTextureUAV, null, ((int)context.Viewport.Width + 15) / 16, ((int)context.Viewport.Height + 15) / 16, 1);


            //            _stopwatch.Stop();
            //            Logger.Info(this,"update took: {0}ms", _stopwatch.ElapsedMilliseconds);

            context.Image = _visuTexture;

            return context;
        }

        private Texture2D _visuTexture;
        private UnorderedAccessView _visuTextureUAV;
        
        private Texture3D _volume;
        private ShaderResourceView _volumeSRV;

        private SamplerState _linearSamplerState;
        private Buffer _constBuffer;

        private ComputeShader _csRender;
    }
}

