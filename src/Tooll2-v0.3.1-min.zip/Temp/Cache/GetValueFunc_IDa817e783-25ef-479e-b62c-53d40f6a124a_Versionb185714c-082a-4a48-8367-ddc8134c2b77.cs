using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;

namespace Framefield.Core.IDa817e783_25ef_479e_b62c_53d40f6a124a
{
    public class Class_GetValue : OperatorPart.Function, Framefield.Core.OperatorPartTraits.IVariableAccessor
    {
        public string VariableName {
            get {
                return OperatorPartUtilities.GetInputTextValue(OperatorPart.Connections[0]);
            }
        }

        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            var Name = inputs[0].Eval(context).Text;
            var Default = inputs[1].Eval(context).Value;
            var value = 0.0f;
            if (context.Variables.TryGetValue(Name, out value)) {
                context.Value = value;
            }
            else {
                context.Value = Default;
            }
            return context;
        }
    }
}

