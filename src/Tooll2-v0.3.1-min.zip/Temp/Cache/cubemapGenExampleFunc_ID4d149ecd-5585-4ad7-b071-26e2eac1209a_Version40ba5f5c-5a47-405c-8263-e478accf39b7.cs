//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using
using Framefield.Core.Rendering;
using SharpDX.DXGI;

namespace Framefield.Core.ID4d149ecd_5585_4ad7_b071_26e2eac1209a
{
    public class Class_cubemapGenExample : FXSourceCodeFunction
     {
        //>>> _inputids
        private enum InputId
        {
            Code = 0
        }
        //<<< _inputids

        public override void Dispose()
        {
            Utilities.DisposeObj(ref _prefilteredCubeMap);
            Utilities.DisposeObj(ref _cubeMapRTV);
            Utilities.DisposeObj(ref _rasterizerState);
            base.Dispose();
        }

        bool _firstEval = true;
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx)
        {
            //>>> _params
            var Code = inputs[(int)InputId.Code].Eval(context).Text;
            //<<< _params


            if (_effect == null)
            {
                for (int i = 0; i < NumCodes(); ++i) {
                    Compile(i);
                }
                _firstEval = false;
                Logger.Info(this, "compiled fx");
                Changed = true;
            }
            
            var cubeMapSize = new Vector2(128, 128);

            if (_prefilteredCubeMap == null)
            {
                Logger.Info(this, "create cubemap");
                var cubeMapDesc = new Texture2DDescription
                {
                    BindFlags = BindFlags.ShaderResource | BindFlags.RenderTarget,
                    Format = SharpDX.DXGI.Format.R16G16B16A16_Float,
                    Width = (int)cubeMapSize.X,
                    Height = (int)cubeMapSize.Y,
                    MipLevels = 1,
                    SampleDescription = new SampleDescription(1,0),
                    Usage = ResourceUsage.Default,
                    OptionFlags = ResourceOptionFlags.TextureCube, // | ResourceOptionFlags.GenerateMipMaps,
                    CpuAccessFlags = CpuAccessFlags.None,
                    ArraySize = 6
                };

                _prefilteredCubeMap = new Texture2D(D3DDevice.Device, cubeMapDesc);
                _cubeMapRTV = new RenderTargetView(D3DDevice.Device, _prefilteredCubeMap);
                
                var rastDesc = new RasterizerStateDescription
                                   {
                                       FillMode = FillMode.Solid,
                                       CullMode = CullMode.None,
                                       IsDepthClipEnabled = false
                                   };
                _rasterizerState = new RasterizerState(D3DDevice.Device, rastDesc);    
            }


            var prevEffect = context.Effect;

            var prevRTV = context.RenderTargetView;
            var prevDTV = context.DepthStencilView;


            context.D3DDevice.ImmediateContext.OutputMerger.SetTargets(_cubeMapRTV, null);
            context.D3DDevice.ImmediateContext.OutputMerger.BlendState = OperatorPartContext.DefaultRenderer.DisabledBlendState;
            context.D3DDevice.ImmediateContext.OutputMerger.DepthStencilState = OperatorPartContext.DefaultRenderer.DisabledDepthStencilState;

            var viewport = new ViewportF(0.0f, 0.0f, cubeMapSize.X, cubeMapSize.Y);
            context.D3DDevice.ImmediateContext.Rasterizer.SetViewports(new [] { viewport });
            context.D3DDevice.ImmediateContext.Rasterizer.State = _rasterizerState;
            context.D3DDevice.ImmediateContext.InputAssembler.InputLayout = context.InputLayout;
            context.D3DDevice.ImmediateContext.InputAssembler.PrimitiveTopology = SharpDX.Direct3D.PrimitiveTopology.TriangleList;
            context.D3DDevice.ImmediateContext.InputAssembler.SetVertexBuffers(0, new VertexBufferBinding(null, 0, 0));

            var technique = _effect.GetTechniqueByIndex(0);
            technique.GetPassByIndex(0).Apply(context.D3DDevice.ImmediateContext);
            context.D3DDevice.ImmediateContext.Draw(6, 0);

            context.D3DDevice.ImmediateContext.OutputMerger.SetTargets(context.DepthStencilView, context.RenderTargetView);

            context.Image = _prefilteredCubeMap;
            return context;
        }

        Texture2D _prefilteredCubeMap;
        RenderTargetView _cubeMapRTV;
        RasterizerState _rasterizerState;
    }
}


