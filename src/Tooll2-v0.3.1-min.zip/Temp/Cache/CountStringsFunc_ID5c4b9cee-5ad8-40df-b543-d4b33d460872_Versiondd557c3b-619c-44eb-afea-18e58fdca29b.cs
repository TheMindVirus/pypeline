using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;


namespace Framefield.Core.ID5c4b9cee_5ad8_40df_b543_d4b33d460872
{
    public class Class_CountStrings : OperatorPart.Function
    {
        //>>> _inputids
        private enum InputId
        {
            StringList = 0
        }
        //<<< _inputids



        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            //>>> params
            dynamic StringList = inputs[(int)InputId.StringList].Eval(context).Dynamic;
            
            //<<< params            
            if(StringList == null) {
                Logger.Info(this,"Can't convert incoming structure to Dynamic");
                return context;
            }
            
            context.Value = StringList.Count;
            
            return context;
        }
    }
}

