using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;

namespace Framefield.Core.IDe3db583a_27c4_48a5_a1fe_679eda456a1c
{
    public class Class_GlobalTime : OperatorPart.Function, Framefield.Core.OperatorPartTraits.ITimeAccessor
    {
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) 
        {
            //>>> function

            context.Value = context.GlobalTime;
            return context;
            //<<< function
        }
    }
}


