//>>> _using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.Windows;
//<<< _using

using System.Runtime.InteropServices;
using Framefield.Core.Rendering;
using SharpDX.DXGI;
using SharpDX.D3DCompiler;
using Buffer = SharpDX.Direct3D11.Buffer;
using System.CodeDom.Compiler;
using System.Diagnostics;

namespace Framefield.Core.ID1fa5316f_7a39_43a4_87b1_4fc4f47086c7
{
    public class Class_CSHistogram : FXSourceCodeFunction
    {

        //>>> _inputids
        private enum InputId
        {
            Code = 0,
            Image = 1
        }
        //<<< _inputids

        public void Dispose()
        {
            Utilities.DisposeObj(ref _histoTexture);
            Utilities.DisposeObj(ref _visuTexture);
            Utilities.DisposeObj(ref _csHistoClear);
            Utilities.DisposeObj(ref _csHisto);
            Utilities.DisposeObj(ref _csVisu);
            base.Dispose();
        }

        protected bool BuildRenderTarget(OperatorPartContext context)
        {
            if (_histoTexture != null)
            {
                return false;
            }

            var uavHistoDesc = new Texture2DDescription
                                  {
                                      BindFlags = BindFlags.ShaderResource | BindFlags.UnorderedAccess,
                                      Format = Format.R32_SInt,
                                      Width = 256,
                                      Height = 4,
                                      MipLevels = 1,
                                      SampleDescription = new SampleDescription(1, 0),
                                      Usage = ResourceUsage.Default,
                                      OptionFlags = ResourceOptionFlags.None,
                                      CpuAccessFlags = CpuAccessFlags.None,
                                      ArraySize = 1
                                  };
            Utilities.DisposeObj(ref _histoTexture);
            _histoTexture = new Texture2D(context.D3DDevice, uavHistoDesc);

            var uavVisuDesc = new Texture2DDescription
                                  {
                                      BindFlags = BindFlags.ShaderResource | BindFlags.UnorderedAccess,
                                      Format = Format.R8G8B8A8_UNorm,
                                      Width = 256,
                                      Height = 256,
                                      MipLevels = 1,
                                      SampleDescription = new SampleDescription(1, 0),
                                      Usage = ResourceUsage.Default,
                                      OptionFlags = ResourceOptionFlags.None,
                                      CpuAccessFlags = CpuAccessFlags.None,
                                      ArraySize = 1
                                  };
            Utilities.DisposeObj(ref _visuTexture);
            _visuTexture = new Texture2D(context.D3DDevice, uavVisuDesc);

            return true;
        }

        private Stopwatch _stopwatch = new Stopwatch();
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) 
        {
            //>>> _params
            var Code = inputs[(int)InputId.Code].Eval(context).Text;
            var Image = inputs[(int)InputId.Image].Eval(context).Image; // Needs to be checked for null!
            //<<< _params

            if (_csHisto == null)
            {
                Utilities.DisposeObj(ref _csHistoClear);
                Utilities.DisposeObj(ref _csHisto);
                Utilities.DisposeObj(ref _csVisu);
                var errors = new CompilerErrorCollection();
                try
                {
                    using (var bytecode = ShaderBytecode.Compile(GetCode(0), "CSClearHisto", "cs_5_0", ShaderFlags.Debug))
                        _csHistoClear = new ComputeShader(D3DDevice.Device, bytecode);
                    using (var bytecode = ShaderBytecode.Compile(GetCode(0), "CSHisto", "cs_5_0", ShaderFlags.Debug))
                        _csHisto = new ComputeShader(D3DDevice.Device, bytecode);
                    using (var bytecode = ShaderBytecode.Compile(GetCode(0), "CSVisu", "cs_5_0", ShaderFlags.Debug))
                        _csVisu = new ComputeShader(D3DDevice.Device, bytecode);
                }
                catch (CompilationException ex)
                {
                    errors = ErrorsFromString(ex.Message);
                    Logger.Error(this,"Fx compile error: {0}", ex.Message);
                }
            }

            BuildRenderTarget(context);

            //_effect.GetVariableByName("RenderTargetSize").AsVector().Set(new Vector2(_usedViewport.Width, _usedViewport.Height));
            _stopwatch.Restart();

            var deviceContext = context.D3DDevice.ImmediateContext;
            using (var imageView = new ShaderResourceView(context.D3DDevice, Image))
            using (var uav = new UnorderedAccessView(context.D3DDevice, _histoTexture))
            {
                deviceContext.ComputeShader.Set(_csHistoClear);
                deviceContext.ComputeShader.SetUnorderedAccessView(0, uav);
                deviceContext.Dispatch(16, 1, 1);

                deviceContext.ComputeShader.Set(_csHisto);
                deviceContext.ComputeShader.SetUnorderedAccessView(0, uav);
                deviceContext.ComputeShader.SetShaderResource(0, imageView);
                deviceContext.Dispatch(32, 32, 1);
                deviceContext.ComputeShader.SetUnorderedAccessView(0, null);
                deviceContext.ComputeShader.SetShaderResource(0, null);
            }

            using (var imageView = new ShaderResourceView(context.D3DDevice, _histoTexture))
            using (var uav = new UnorderedAccessView(context.D3DDevice, _visuTexture))
            {
                deviceContext.ComputeShader.Set(_csVisu);
                deviceContext.ComputeShader.SetUnorderedAccessView(1, uav);
                deviceContext.ComputeShader.SetShaderResource(1, imageView);
                deviceContext.Dispatch(32, 32, 1);
                deviceContext.ComputeShader.SetUnorderedAccessView(1, null);
                deviceContext.ComputeShader.SetShaderResource(1, null);
            }
            _stopwatch.Stop();
            Logger.Info(this,"histoupdate took: {0}ms", _stopwatch.ElapsedMilliseconds);

            context.Image = _visuTexture;

            return context;
        }

        private Texture2D _histoTexture;
        private Texture2D _visuTexture;
        private ComputeShader _csHistoClear;
        private ComputeShader _csHisto;
        private ComputeShader _csVisu;
    }
}

