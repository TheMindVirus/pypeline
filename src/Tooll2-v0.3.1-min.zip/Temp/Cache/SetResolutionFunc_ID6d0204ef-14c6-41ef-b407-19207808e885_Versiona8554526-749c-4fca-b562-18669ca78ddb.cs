using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpDX;
using SharpDX.Direct3D11;
using SharpDX.DXGI;

namespace Framefield.Core.ID6d0204ef_14c6_41ef_b407_19207808e885
{
    public class Class_SetResolution : OperatorPart.Function
    {
        public override OperatorPartContext Eval(OperatorPartContext context, List<OperatorPart> inputs, int outputIdx) {
            var Scene = inputs[2];

            int SizeX = (int) inputs[0].Eval(context).Value;
            int SizeY = (int) inputs[1].Eval(context).Value;
            /*
            if (SizeX == 0 || SizeY == 0) {
                SizeX = context.Viewport.Width * (SampleCount > 1 ? 2 : 1);
                SizeY = context.Viewport.Height * (SampleCount > 1 ? 2 : 1);
                //if ((_renderTargetResource != null) && 
                //    (SizeX != _renderTargetResource.Texture.Description.Width || SizeY != _renderTargetResource.Texture.Description.Height)) {
                //    rebuildTarget = true;
                //}
            }*/
            //context.Viewport.Width = 10; //SizeX;
            //context.Viewport.Height = 10; //SizeY;
            
            var oldViewport = context.Viewport;
            context.Viewport = new ViewportF( 0,0, SizeX, SizeY);

            Scene.Eval(context);
            context.Viewport = oldViewport;

            return context;
        }

//        Resource _renderTargetResource;
//        RenderTargetView _renderTargetView;
//        Resource _renderDepthResource;
//        DepthStencilView _renderTargetDepthView;
    }
}

