﻿
using var game = new MonoXNA.Game1();
game.Run();
