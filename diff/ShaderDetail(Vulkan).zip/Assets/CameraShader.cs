using UnityEngine;
using UnityEngine.Rendering;

public class CameraShader : MonoBehaviour
{
    void Start()
    {
        //Camera.main.RenderWithShader(Shader.Find("CameraShader"), "");
        var shader = Shader.Find("Custom/CameraShader");
        //var shader = Shader.Find("Custom/Standard");
        //Camera.main.SetReplacementShader(shader, "");
        Debug.Log(shader);
    }
}
