#pip3 install opencv-python
#pip3 install -U numpy
import cv2, numpy, math
r = 2
g = 1
b = 0
w = 1920
h = 1080
px = 0.0
py = 0.0
pr = 0.0
pg = 0.0
pb = 0.0
a = 255.0
imgcrs = numpy.zeros([h, w, 3])
for x in range(0, w):
    px = x / w
    pr = (2.0 - abs(6.0 * px)) if (px < 0.5) else (2.0 - abs(6.0 * (px - 1.0)))
    pg = 2.0 - abs(6.0 * (px - (1.0 / 3.0)))
    pb = 2.0 - abs(6.0 * (px - (2.0 / 3.0)))
    for y in range(0, h):
        py = 1.0 - (y / h)
        imgcrs[y][x][r] = a * 255.0 if (py <= pr) else 0.0
        imgcrs[y][x][g] = a * 255.0 if (py <= pg) else 0.0
        imgcrs[y][x][b] = a * 255.0 if (py <= pb) else 0.0
cv2.imwrite("crs.png", imgcrs)
print("Done!")
